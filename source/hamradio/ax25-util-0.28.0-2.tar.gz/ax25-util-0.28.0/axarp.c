#include <sys/types.h>
#include <sys/socket.h>
#include <linux/sockios.h>
#include <linux/if.h>
#include <linux/if_arp.h>
#include <linux/ax25.h>
#include <netinet/in.h>
#include <stdio.h>

void main()
{
	char buf[64];
	FILE *f=fopen("/proc/net/arp","r");
	struct arpreq arq;
	struct sockaddr_in *i;
	unsigned char *t;
	int ct=0;
	printf("IP Address            Callsign.\n");
	while(fread(&arq,sizeof(arq),1,f)>0)
	{
		if(arq.arp_ha.sa_family!=ARPHRD_AX25)
			continue;
		t=arq.arp_ha.sa_data;
		i=(struct sockaddr_in *)&arq.arp_pa;
		i=(struct sockaddr_in *)((char *)i-2);
		ct=0;
		printf("%-22s",inet_ntoa(i->sin_addr.s_addr));
		while(ct++<6)
		{
			char x=((*t++)>>1)&0x7F;
			if(x!=' ')
				printf("%c",x);
		}
		if((*t&0x1E)!=0)
			printf("-%d",(*t&0x1E)>>1);
		printf("\n");
	}
	fclose(f);
}		
		