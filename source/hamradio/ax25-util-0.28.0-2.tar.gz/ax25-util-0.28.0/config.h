extern int convert_call(char *name,struct full_sockaddr_ax25 *sax);
extern int convert_call_entry(char *name, char *buf);
extern int convert_call_arglist(char *name[],struct full_sockaddr_ax25 *sax);
extern int config_load_ports(void);
extern int config_num_ports(void);
extern char *config_get_addr(int port);
extern int config_get_window(int port);
extern int config_get_baud(int port);
extern char *config_get_freq(int port);

