#define	FALSE	0
#define	TRUE	1

extern int fd;
extern int interrupted;

/* In call.c */
extern void convert_crlf(char *, int);
extern void convert_lfcr(char *, int);

/* In yapp.c */
extern void cmd_yapp(char *, int);

/* In dostime.c */
extern int yapp2unix(char *);
extern void unix2yapp( int, char *);
