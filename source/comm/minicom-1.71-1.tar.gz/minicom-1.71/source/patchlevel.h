/*
 * patchlevel.h		Defines the version strings
 *			in one central place.
 *
 * Version:		1.71 15-Mar-1995 MvS
 *
 */
#define SCCS_ID "@(#)Minicom V1.71 1995"
#define ST_VERSION "1.71 1995"
#define CR_VERSION "\nMinicom 1.71 Copyright (c) Miquel van Smoorenburg\r\n"
