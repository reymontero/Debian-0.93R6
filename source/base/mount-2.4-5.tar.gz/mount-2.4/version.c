char version[] = "(u)mount: version from util-linux-2.4";
