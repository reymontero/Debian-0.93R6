/*
 * paths.h	Paths of files that init and related utilities need.
 *
 * Version:	@(#) paths.h 1.60 15-Jan-1995
 *
 * Author:	Miquel van Smoorenburg, <miquels@drinkel.ow.org>
 *
 *		This file is part of the sysvinit suite,
 *		Copyright 1991-1995 Miquel van Smoorenburg.
 *
 *		This program is free software; you can redistribute it and/or
 *		modify it under the terms of the GNU General Public License
 *		as published by the Free Software Foundation; either version
 *		2 of the License, or (at your option) any later version.
 */
#define INITLVL		"/var/log/initrunlvl"	/* New runlevel for init */
#define CONSOLE		"/dev/console"		/* Logical system console */
#define SYSTTY		"/dev/systty"		/* Physical system console */
#define SYSDEV		0x0400			/* to mknod() the sysdev */
#define SECURETTY	"/etc/securetty"	/* List of root terminals */
#define SDALLOW		"/etc/shutdown.allow"	/* Users allowed to shutdown */
#define INITTAB		"/etc/inittab"		/* Location of inittab */
#define PWRSTAT		"/var/log/powerstatus"	/* SIGPWR reason (OK/BAD) */
#define INIT		"/sbin/init"		/* Location of init itself. */
#define NOLOGIN		"/etc/nologin"		/* Stop user logging in. */
#define FASTBOOT	"/fastboot"		/* Enable fast boot. */
#define SDPID		"/var/run/shutdown.pid"	/* PID of shutdown program */
#define IOSAVE		"/etc/ioctl.save"	/* termios settings for SU */
#define SHELL		"/bin/sh"		/* Default shell */
#define INITSCRIPT	"/etc/initscript"	/* Initscript. */
#define HALTSCRIPT	"/etc/init.d/halt"	/* Called by "fast" shutdown */
#define REBOOTSCRIPT	"/etc/init.d/reboot"	/* Ditto. */
