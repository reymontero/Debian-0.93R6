read line1

echo read line1 \"$line1\"

exec 4</etc/passwd

exec 5<&0
exec 0<&4

read line2

echo read line2 \"$line2\"

exec 0<&5

read line3

echo read line3 \"$line3\"

exec 0<&4

read line4

echo read line4 \"$line4\"

exec 4<&-
