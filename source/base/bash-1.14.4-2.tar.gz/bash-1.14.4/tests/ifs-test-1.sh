OIFS="$IFS"
IFS=":$IFS"
eval foo="a:b:c"
IFS="$OIFS"
echo $foo
