/*
 * clrunimap.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <linux/kd.h>
#include <sys/ioctl.h>

int
main(int argc, char *argv[]) {
	struct unimapinit advice;
	int fd;

	/* we do not want to read, but only need some fd */
	if ((fd = open("/dev/console", 0)) < 0)
	    fd = 0;

	advice.advised_hashsize = 0;
	advice.advised_hashstep = 0;
	advice.advised_hashlevel = 0;

	if(ioctl(fd, PIO_UNIMAPCLR, &advice)) {
	    perror("PIO_UNIMAPCLR");
	    exit(1);
	}
}
