#! /bin/sh

echo
echo "WARNING! You are attempting to boot an unconfigured base system. You"
echo "need to configure it before proceeding. To do so, you need to reboot"
echo "using your installation disks and select the \"configure\" option"
echo "from the \"expert-mode\" installation menu."
echo
echo "Please make sure that the Debian GNU/Linux Boot Disk is in the boot"
echo -n "floppy drive and press <ENTER> to reboot: "

read input

reboot
