#include <config.h>
#include "version.h"
const char *version_string = "GNU sh-utils 1.12";
