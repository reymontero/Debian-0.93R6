/* Kernel includes */
#include <linux/config.h>
#include <linux/module.h>
#include <linux/version.h>

void
base(int level, char *s)
{
	printk("in base, level %d, string='%s'\n", level, s);
}

static char kernel_version[] = UTS_RELEASE;

int
init_module( void) {
	return 0;
}

void
cleanup_module( void) {
	if (MOD_IN_USE)
		printk("base: busy, remove delayed\n");
}
