#include <linux/module.h>
#include <linux/unistd.h>

extern void load_kernel_symbols(void);
extern struct kernel_sym *ksymtab;
extern int nksyms;
