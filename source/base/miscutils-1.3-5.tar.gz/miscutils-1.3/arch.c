/* arch.c

   Written by Ian Murdock <imurdock@debian.org>. Public domain.

   arch is a simple program that displays machine architecture.  */

#include <stdio.h>
#include <sys/utsname.h>

void
main (void)
{
  struct utsname name;

  
  if (uname (&name) == -1)
    {
      perror ("arch");
      exit (1);
    }
  else
    {
      printf ("%s\n", name.machine);
      exit (0);
    }
}
