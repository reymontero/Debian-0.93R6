#define DPKG_VERSION "0.93.80" /* This line modified by Makefile */
