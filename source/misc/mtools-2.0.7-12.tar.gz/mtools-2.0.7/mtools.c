#include <stdio.h>
#include <string.h>

#define DISPATCH(f,n) if (!strcmp(name,n)) { extern f(); \
  return f(argc,argv); }

int fd = -1;				/* the file descriptor for the device */
int dir_start;				/* starting sector for directory */
int dir_len;				/* length of directory (in sectors) */
int dir_entries;			/* number of directory entries */
int clus_size;				/* cluster size (in sectors) */
char *mcwd;				/* the Current Working Directory */
int fat_error;				/* FAT error detected? */

main(argc,argv)
int argc;
char **argv;
{
    char *name;

    load_devices();
    if (name = strrchr(argv[0],'/')) name++;
    else name = argv[0];
    DISPATCH(mattrib,"mattrib")
    DISPATCH(mcd,"mcd")
    DISPATCH(mcopy,"mcopy")
    DISPATCH(mdel,"mdel")
    DISPATCH(mdir,"mdir")
    DISPATCH(mformat,"mformat")
    DISPATCH(mlabel,"mlabel")
    DISPATCH(mmd,"mmd")
    DISPATCH(mrd,"mrd")
    DISPATCH(mread,"mread")
    DISPATCH(mren,"mren")
    DISPATCH(mtype,"mtype")
    DISPATCH(mwrite,"mwrite")
    fprintf(stderr,"Unknown command %s\n",name);
    return 1;
}
