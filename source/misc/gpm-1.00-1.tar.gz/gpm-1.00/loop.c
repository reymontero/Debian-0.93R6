/*
 * This program is a silly test for the two screen dump-restore ways
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/kd.h>        /* KDGETMODE */
#include <termios.h>       /* winsize */


char buffer[80*50*2+8];

int main (int argc, char **argv)
{
int mode, count, fd;
if (argc!=3) {printf("argc!=3\n");exit(1);}

mode=argv[1][0];
count=atoi(argv[2]);
printf("count is %i\n",count);

fd=open("/dev/console",O_RDWR);
if (fd<0) {printf("can't open\n");exit(1);}


if (mode=='n')
  {
  while(count-->0)
    {
    buffer[0]=8;buffer[1]=0; /* new screendump, fgconsole */

    if (ioctl(fd, TIOCLINUX,buffer)<0)
      {
      perror("ioctl(scrdump)");
      exit(1);
      }
printf("orco\n");sleep(1);
    buffer[0]=9,buffer[1]=0; /* restore, current */
    if (ioctl(fd,TIOCLINUX,buffer)<0)
      {
      perror("ioctl(screstore)");
      exit(1);
      }
    }
  exit(0);
  }
else
  {
  char s[80];
  sprintf(s,"\x1B[%03i;%03iH",0,0);
  while(count-->0)
    {
    buffer[0]=0;buffer[1]=0; /* old screendump, fgconsole */

    if (ioctl(fd, TIOCLINUX,buffer)<0)
      {
      perror("ioctl(scrdump)");
      exit(1);
      }
    write(fd,s,strlen(s));
    write(fd,buffer+2,80*50);
    }
  exit(0);
  }
  
}
