/* gitps.c -- a process viewer/killer utility. */

/* Copyright (C) 1993, 1994, 1995 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* Written by Tudor Hulubei and Andrei Pitis.  */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>

#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#else /* !HAVE_STDLIB_H */
#include "ansi_stdlib.h"
#endif /* !HAVE_STDLIB_H */

#include <sys/types.h>
#include <ctype.h>
#include <limits.h>
#include "file.h"
#include <fcntl.h>
#include <signal.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif /* HAVE_UNISTD_H */

#include <errno.h>

/* Not all systems declare ERRNO in errno.h... and some systems #define it! */
#if !defined (errno)
extern int errno;
#endif /* !errno */

#include "stdc.h"
#include "xstring.h"
#include "xmalloc.h"
#include "tty.h"
#include "window.h"
#include "configure.h"
#include "tilde.h"
#include "misc.h"


int SCREEN_X;
int SCREEN_Y;

#define MAX_KEYS        2048
#define MAX_PROCESSES   1024
#define PS_FIELDS         12


static char *PSFields[PS_FIELDS] =
{
    "TitleForeground",
    "TitleBackground",
    "TitleBrightness",
    "HeaderForeground",
    "HeaderBackground",
    "HeaderBrightness",
    "ScreenForeground",
    "ScreenBackground",
    "ScreenBrightness",
    "StatusForeground",
    "StatusBackground",
    "StatusBrightness"
};

#ifdef HAVE_LINUX
static int PSColors[PS_FIELDS] = 
{
    CYAN, BLUE, ON, CYAN, RED, ON, BLACK, CYAN, OFF, CYAN, BLUE, ON
};
#else   /* !HAVE_LINUX */
static int PSColors[PS_FIELDS] = 
{
    BLACK, WHITE, OFF, WHITE, BLACK, ON, WHITE, BLACK, OFF, BLACK, WHITE, OFF
};
#endif  /* !HAVE_LINUX */

#define TitleForeground                 PSColors[0]
#define TitleBackground                 PSColors[1]
#define TitleBrightness                 PSColors[2]
#define HeaderForeground                PSColors[3]
#define HeaderBackground                PSColors[4]
#define HeaderBrightness                PSColors[5]
#define ScreenForeground                PSColors[6]
#define ScreenBackground                PSColors[7]
#define ScreenBrightness                PSColors[8]
#define StatusForeground                PSColors[9]
#define StatusBackground                PSColors[10]
#define StatusBrightness                PSColors[11]



#ifdef HAVE_LINUX
int AnsiColorSequences = ON;
#else   /* !HAVE_LINUX */
int AnsiColorSequences = OFF;
#endif  /* !HAVE_LINUX */


char cSection[]  = "[GITPS-Color]";
char bwSection[] = "[GITPS-Monochrome]";
int  processes;
int  PID_index;
int  signal_type = 11;  /* index of SIGTERM in signals table */

pid_t pid;
char *home;
char *program;
char *tty_name;
size_t tty_name_len;
char *header_text;
char *TempDirectory;
int   UseLastScreenChar;
int   StartupScrollStep;
char *stdout_log_name = NULL;
char *stderr_log_name = NULL;
char *ps_vect[MAX_PROCESSES];
char *global_buf = NULL;
int first_on_screen, current_process, scroll_step;
window_t *title_win, *header_win, *screen_win, *status_win;
#ifdef HAVE_GCC
static char title_text[] = " "PRODUCT" "VERSION" - Process Viewer/Killer";
#else
static char title_text[] = " GNU Interactive Tools 4.3.7 - Process Viewer/Killer";
#endif /* !HAVE_GCC */
static char *GitPsModeHelp;
static char no_perm[] = "not owner !";
static char no_proc[] = "no such process ! (REFRESH recommended)";


struct SIGNAL
{
    char signame[8];
    int  signal;
};

static struct SIGNAL signals[] =
{
    { "SIGHUP ", SIGHUP  },     /*  0 */
    { "SIGINT ", SIGINT  },     /*  1 */
    { "SIGQUIT", SIGQUIT },     /*  2 */
    { "SIGILL ", SIGILL  },     /*  3 */
    { "SIGFPE ", SIGFPE  },     /*  4 */
    { "SIGKILL", SIGKILL },     /*  5 */
    { "SIGUSR1", SIGUSR1 },     /*  6 */
    { "SIGSEGV", SIGSEGV },     /*  7 */
    { "SIGUSR2", SIGUSR2 },     /*  8 */
    { "SIGPIPE", SIGPIPE },     /*  9 */
    { "SIGALRM", SIGALRM },     /* 10 */
    { "SIGTERM", SIGTERM },     /* 11 */
    { "SIGCHLD", SIGCHLD },     /* 12 */
    { "SIGCONT", SIGCONT },     /* 13 */
    { "SIGSTOP", SIGSTOP },     /* 14 */
    { "SIGTSTP", SIGTSTP },     /* 15 */
    { "SIGABRT", SIGABRT },     /* 16 */
    { "SIGTRAP", SIGTRAP }      /* 17 */
};


#define BUILTIN_OPERATIONS              26


#define BUILTIN_previous_line            0
#define BUILTIN_next_line                1
#define BUILTIN_scroll_down              2
#define BUILTIN_scroll_up                3
#define BUILTIN_beginning_of_list        4
#define BUILTIN_end_of_list              5
#define BUILTIN_next_signal              6
#define BUILTIN_SIGHUP                   7
#define BUILTIN_SIGINT                   8
#define BUILTIN_SIGQUIT                  9
#define BUILTIN_SIGILL                  10
#define BUILTIN_SIGFPE                  11
#define BUILTIN_SIGKILL                 12
#define BUILTIN_SIGUSR1                 13
#define BUILTIN_SIGSEGV                 14
#define BUILTIN_SIGUSR2                 15
#define BUILTIN_SIGPIPE                 16
#define BUILTIN_SIGALRM                 17
#define BUILTIN_SIGTERM                 18
#define BUILTIN_SIGCHLD                 19
#define BUILTIN_SIGCONT                 20
#define BUILTIN_kill_process            21
#define BUILTIN_refresh                 22
#define BUILTIN_exit                    23
#define BUILTIN_hard_refresh            24


#define MAX_BUILTIN_NAME                20

char built_in[BUILTIN_OPERATIONS][MAX_BUILTIN_NAME] =
{
    "previous-line",
    "next-line",
    "scroll-down",
    "scroll-up",
    "beginning-of-list",
    "end-of-list",
    "next-signal",
    "SIGHUP",
    "SIGINT",
    "SIGQUIT",
    "SIGILL",
    "SIGFPE",
    "SIGKILL",
    "SIGUSR1",
    "SIGSEGV",
    "SIGUSR2",
    "SIGPIPE",
    "SIGALRM",
    "SIGTERM",
    "SIGCHLD",
    "SIGCONT",
    "kill-process",
    "refresh",
    "exit",
    "hard-refresh",
};


void
removelog()
{
    if (stdout_log_name) unlink(stdout_log_name);
    if (stderr_log_name) unlink(stderr_log_name);
}


void
settitle()
{
    memset(global_buf, ' ', SCREEN_X);
    memcpy(global_buf, title_text, strlen(title_text));

    tty_colors(TitleBrightness, TitleForeground, TitleBackground);

    window_cursormove_notify(title_win, 0, 0);
    window_write(global_buf, SCREEN_X);
}


void
setheader()
{
    memset(global_buf, ' ', SCREEN_X);
    memcpy(global_buf, header_text, strlen(header_text));

    tty_colors(HeaderBrightness, HeaderForeground, HeaderBackground);

    window_cursormove_notify(header_win, 0, 0);
    window_write(global_buf, SCREEN_X);
}


void
setstatus(what)
   char *what;
{
    memset(global_buf, ' ', SCREEN_X);

    if (what)
        memcpy(global_buf, what, strlen(what));
    else
        memcpy(global_buf, GitPsModeHelp, strlen(GitPsModeHelp));

    tty_colors(StatusBrightness, StatusForeground, StatusBackground);

    window_cursormove_notify(status_win, 0, 0);
    window_write(global_buf, SCREEN_X - (sizeof(signals[0].signame) - 1) - 1);
}


void
setsignal()
{
    int len = sizeof(signals[0].signame) - 1;

    tty_colors(StatusBrightness, StatusForeground, StatusBackground);

    window_cursormove_notify(status_win, 0, SCREEN_X - len - 1);
    window_write(signals[signal_type].signame, len);

    if (UseLastScreenChar)
        window_putch(' ');
}


void
free_ps_list()
{
    int i;

    for (i = 0; i < MAX_PROCESSES; i++)
        if (ps_vect[i])
        {
            xfree(ps_vect[i]);
            ps_vect[i] = NULL;
        }
}


char *
read_ps_line(ps_output, line)
    FILE *ps_output;
    char *line;
{
    int c;
    char *ok;
    size_t lastchar;

    ok = fgets(line, SCREEN_X + 1, ps_output);

    if (line[lastchar = strlen(line) - 1] == '\n')
        line[lastchar] = 0;
    else
        while ((c = fgetc(ps_output)) != '\n' && c != EOF);

    return ok;
}


int
get_PID_index(ps_output)
    FILE *ps_output;
{
    int i;
    char *h = header_text;

    if (read_ps_line(ps_output, header_text) == NULL)
        return -1;

    if (strstr(header_text, "PID") == NULL)
        return -1;

    for (i = 0; ; i++)
    {
        while (isspace(*h))
            h++;

        if (memcmp(h, "PID", 3) == 0)
            return i;

        while (!isspace(*h))
            h++;
    }
}


int
kill_process(process_index)
    int process_index;
{
    int i;
    char pidstr[32];
    char *p = ps_vect[process_index];

    if (p == NULL)
        return 0;

    for (i = 0; i < PID_index; i++)
    {
        while (isspace(*p)) p++;
        if (memcmp(p, "PID", 3) == 0) return i;
        while (!isspace(*p)) p++;
    }

    i = 0;
    while (isspace(*p)) p++;
    while (!isspace(*p)) pidstr[i++] = *p++;
    pidstr[i] = 0;
    return !kill(atoi(pidstr), signals[signal_type].signal);
}


void
build_ps_list(ps_output)
    FILE *ps_output;
{
    int i = 0;

    do
        ps_vect[i] = xmalloc(SCREEN_X + 1);
    while (read_ps_line(ps_output, ps_vect[i++]));

    xfree(ps_vect[--i]);
    ps_vect[i] = NULL;
    processes = i;
}


void
update_process(process, update_color)
    int process, update_color;
{
    memset(global_buf, ' ', SCREEN_X);
    memcpy(global_buf, ps_vect[process], strlen(ps_vect[process]));

    if (update_color)
    {
        tty_brightness(ScreenBrightness);

        if (process == current_process)
        {
            tty_foreground(ScreenBackground);
            tty_background(ScreenForeground);
        }
        else
        {
            tty_foreground(ScreenForeground);
            tty_background(ScreenBackground);
        }
    }

    window_cursormove_notify(screen_win, process - first_on_screen, 0);
    window_write(global_buf, SCREEN_X);
}


void
update_all()
{
    int i;

    tty_colors(ScreenBrightness, ScreenForeground, ScreenBackground);

    tty_cursor(OFF);

    window_cursormove(screen_win, 0, 0);

    for (i = first_on_screen;
         i < processes && (i - first_on_screen < SCREEN_Y - 3); i++)
            if (i != current_process)
                update_process(i, OFF);
            else
                window_cursormove_notify(screen_win, i - first_on_screen, 0);

    update_process(current_process, ON);

    tty_colors(ScreenBrightness, ScreenForeground, ScreenBackground);

    memset(global_buf, ' ', SCREEN_X);

    for (; i - first_on_screen < SCREEN_Y - 3; i++)
    {
        window_cursormove_notify(screen_win, i - first_on_screen, 0);
        window_write(global_buf, SCREEN_X);
    }

    window_cursormove(screen_win, current_process-first_on_screen, SCREEN_X-1);
    tty_cursor(ON);
}


void
clean_up()
{
    tty_exit();
    removelog();
}


void
fatal(postmsg)
    char *postmsg;
{
    clean_up();
    fprintf(stderr, "%s: fatal error: %s.\n", program, postmsg);
    exit(1);    
}


int
ps(args)
    char *args;
{
    char *ps_cmd;
    FILE *stdout_log, *stderr_log;

    close(1);
    close(2);
    stdout_log = fopen(stdout_log_name, "w");
    stderr_log = fopen(stderr_log_name, "w");

    ps_cmd = xmalloc(16 + (args ? strlen(args) : 0) + 1);

    if (args)
        sprintf(ps_cmd, "ps %s", args);
    else
        sprintf(ps_cmd, "ps");

    if (system(ps_cmd))
    {
        fclose(stderr_log);
        fclose(stdout_log);
        open(tty_name, O_RDWR);
        open(tty_name, O_RDWR);
        fprintf(stderr, "%s: invalid command line.\n", program);
        return 0;
    }

    xfree(ps_cmd);
    fclose(stderr_log);
    fclose(stdout_log);
    open(tty_name, O_RDWR);
    open(tty_name, O_RDWR);
    return 1;
}


RETSIGTYPE
panic(signum)
    int signum;
{
    fatal_signal(signum);
}


int
read_keys(keys)
    int keys;
{
    char *contents;
    char key_seq[80];
    int i, j, need_convertion;


    for (i = keys; i < MAX_KEYS; i++)
    {
        configuration_getvarinfo(key_seq, &contents, 1, NO_SEEK);

        if (*key_seq == 0)
            break;

        if (*key_seq != '^')
        {
            char *key_seq_ptr = tty_get_symbol_key_seq(key_seq);

            if (!(need_convertion = key_seq_ptr == NULL))
                strcpy(key_seq, key_seq_ptr);
        }
        else
            need_convertion = 1;

        if (contents == NULL)
            continue;

        for (j = 0; j < BUILTIN_OPERATIONS; j++)
            if (strcmp(contents, built_in[j]) == 0)
                break;

        if (j < BUILTIN_OPERATIONS)
        {
            if (!need_convertion || tty_key_convert(key_seq))
                tty_key_list_insert(key_seq, (void *)(long)j);
        }
        else
            fprintf(stderr, "%s: invalid built-in operation: %s.\n",
                    program, contents);
    }

    return i;
}


int
main(argc, argv)
    int argc;
    char *argv[];
{
    long key;
    tty_key_t *ks;
    FILE *stdout_log;
    int repeat_count;
    char *tmp, *data = NULL;
    int first_time = 1, keys;
    int need_update, need_update_all, old_current_process;


    program = argv[0];
    pid     = getpid();

    home = getenv("HOME");
    if (home == NULL)
        home = ".";

    get_tty_name();
    get_login_name();

    tty_get_capabilities();
    tty_kbdinit(TTY_FULL_INPUT);

    signal(SIGTERM, panic);
    signal(SIGINT , panic);
    signal(SIGQUIT, panic);
    signal(SIGSEGV, panic);
    signal(SIGHUP,  panic);

    signal(SIGILL,  SIG_IGN);
    signal(SIGTRAP, SIG_IGN);
    signal(SIGABRT, SIG_IGN);
    signal(SIGUSR1, SIG_IGN);
    signal(SIGUSR2, SIG_IGN);
    signal(SIGTSTP, SIG_IGN);
    signal(SIGCONT, SIG_IGN);
    signal(SIGALRM, SIG_IGN);
    signal(SIGPIPE, SIG_IGN);
    signal(SIGFPE,  SIG_IGN);

    common_configuration_init();
    use_section("[GITPS-Keys]");
    keys = read_keys(0);
    configuration_end();

    specific_configuration_init();

    tty_get_exit_colors();

    tty_get_size(&SCREEN_X, &SCREEN_Y);
    tty_startup();

    use_section("[Setup]");

    configuration_getvarinfo("TempDirectory", &data, 1, DO_SEEK);
    TempDirectory = data ? tilde_expand(data) : "/tmp";

    AnsiColorSequences = get_flag_var("AnsiColorSequences", OFF);

    UseLastScreenChar  = get_flag_var("UseLastScreenChar", OFF);

    StartupScrollStep  = get_int_var("StartupScrollStep", (SCREEN_Y - 3) / 2);

    if (StartupScrollStep <= 0 || StartupScrollStep >= (SCREEN_Y - 3) - 1)
        StartupScrollStep = (SCREEN_Y - 3) / 2;

    scroll_step = StartupScrollStep;


    use_section("[GITPS-Setup]");

    GitPsModeHelp = get_string_var("GitPsModeHelp", "");


    use_section(AnsiColorSequences ? cSection : bwSection);

    get_colorset_var(PSColors, PSFields, PS_FIELDS);


    use_section("[GITPS-Keys]");

    keys = read_keys(keys);

    if (keys == MAX_KEYS)
        fprintf(stderr, "%s: too many key sequences; only %d are allowed.\n",
                program, MAX_KEYS);

    configuration_end();

#ifndef HAVE_LONG_FILE_NAMES
    fprintf(stderr, "%s: warning: your system doesn't support long file names.",
            program);
#endif /* !HAVE_LONG_FILE_NAMES */

    stdout_log_name = xmalloc(32 + strlen(TempDirectory) + 1);
    stderr_log_name = xmalloc(32 + strlen(TempDirectory) + 1);
    sprintf(stdout_log_name, "%s/gitps.1.%d", TempDirectory, (int)pid);
    sprintf(stderr_log_name, "%s/gitps.2.%d", TempDirectory, (int)pid);

    global_buf  = xmalloc(SCREEN_X + 1);

    header_text = xmalloc(SCREEN_X + 1);

    title_win  = window_init(0, 0,            1,            SCREEN_X);
    header_win = window_init(0, 1,            1,            SCREEN_X);
    screen_win = window_init(0, 2,            SCREEN_Y - 3, SCREEN_X);
    status_win = window_init(0, SCREEN_Y - 1, 1,            SCREEN_X);

    tty_set_mode(TTY_NONCANONIC);

    first_on_screen = current_process = 0;

restart:

    if (ps(argc > 1 ? argv[1] : NULL) == 0)
    {
        removelog();
        goto end;
    }

    stdout_log = fopen(stdout_log_name, "r");
    removelog();

    if ((PID_index = get_PID_index(stdout_log)) == -1)
        goto end;

    free_ps_list();
    build_ps_list(stdout_log);
    fclose(stdout_log);

    if (first_time)
    {
        tty_colors(ScreenBrightness, ScreenForeground, ScreenBackground);
        tty_clear();
        first_time = 0;
    }

    settitle();
    setstatus(NULL);
    setsignal();
    setheader();

    current_process = min(current_process, processes - 1);

    update_all();

    while (1)
    {
        ks  = tty_get_key(&repeat_count);
        key = (long)ks->aux_data;

        switch (key)
        {
            case BUILTIN_previous_line:

                need_update_all = need_update = 0;

                while (repeat_count--)
                {
                    if (current_process != 0)
                        current_process--;
                    else
                        break;

                    if (current_process + 1 == first_on_screen)
                    {
                        first_on_screen = max(0, first_on_screen -
                                              scroll_step);
                        need_update_all = 1;
                    }
                    else
                    {
                        if (!need_update)
                            update_process(current_process + 1, ON);

                        need_update = 1;
                    }
                }

                if (need_update_all)
                    update_all();
                else
                    if (need_update)
                        update_process(current_process, ON);
                break;

            case BUILTIN_next_line:

                need_update_all = need_update = 0;

                while (repeat_count--)
                {
                    if (current_process < processes - 1)
                        current_process++;
                    else
                        break;

                    if (current_process - first_on_screen >= SCREEN_Y - 3)
                    {
                        first_on_screen = min(first_on_screen +
                                              scroll_step,
                                              processes - 1 -
                                              (SCREEN_Y - 3) + 1);
                        need_update_all = 1;
                        continue;
                    }

                    if (!need_update)
                        update_process(current_process - 1, ON);

                    need_update = 1;
                }

                if (need_update_all)
                    update_all();
                else
                    if (need_update)
                        update_process(current_process, ON);
                break;

            case BUILTIN_scroll_down:

                if (current_process == 0)
                    break;

                old_current_process = current_process;

                if (current_process < SCREEN_Y - 3)
                    current_process = first_on_screen = 0;
                else
                {
                    current_process -= SCREEN_Y - 3;
                    first_on_screen = max(0, first_on_screen - (SCREEN_Y - 3));
                }

                if (processes > SCREEN_Y - 3)
                    update_all();
                else
                {
                    update_process(old_current_process, ON);
                    update_process(current_process, ON);
                }

                break;

            case BUILTIN_scroll_up:

                if (current_process == processes - 1)
                    break;

                old_current_process = current_process;

                if (processes - 1 - first_on_screen < SCREEN_Y - 3)
                    current_process = processes - 1;
                else
                    if (processes - 1 - current_process < SCREEN_Y - 3)
                    {
                        current_process = processes - 1;
                        first_on_screen = processes - 1 - (SCREEN_Y - 3) + 1;
                    }
                    else
                    {
                        current_process += SCREEN_Y - 3;
                        first_on_screen = min(first_on_screen + SCREEN_Y - 3,
                                              (processes - 1) -
                                              (SCREEN_Y - 3) + 1);
                    }

                if (processes > SCREEN_Y - 3)
                    update_all();
                else
                {
                    update_process(old_current_process, ON);
                    update_process(current_process, ON);
                }

                break;

            case BUILTIN_beginning_of_list:

                if (current_process == 0)
                    break;

                current_process = first_on_screen = 0;
                update_all();
                break;

            case BUILTIN_end_of_list:

                if (current_process == processes - 1)
                    break;

                current_process = processes - 1;
                first_on_screen = max(0, (processes - 1) - (SCREEN_Y - 3) + 1);
                update_all();
                break;

            case BUILTIN_next_signal:

                signal_type++;
                signal_type %= sizeof(signals) / sizeof(struct SIGNAL);
                setsignal();
                break;

            case BUILTIN_SIGHUP : signal_type =  0; setsignal(); break;
            case BUILTIN_SIGINT : signal_type =  1; setsignal(); break;
            case BUILTIN_SIGQUIT: signal_type =  2; setsignal(); break;
            case BUILTIN_SIGILL : signal_type =  3; setsignal(); break;
            case BUILTIN_SIGFPE : signal_type =  4; setsignal(); break;
            case BUILTIN_SIGKILL: signal_type =  5; setsignal(); break;
            case BUILTIN_SIGUSR1: signal_type =  6; setsignal(); break;
            case BUILTIN_SIGSEGV: signal_type =  7; setsignal(); break;
            case BUILTIN_SIGUSR2: signal_type =  8; setsignal(); break;
            case BUILTIN_SIGPIPE: signal_type =  9; setsignal(); break;
            case BUILTIN_SIGALRM: signal_type = 10; setsignal(); break;
            case BUILTIN_SIGTERM: signal_type = 11; setsignal(); break;
            case BUILTIN_SIGCHLD: signal_type = 12; setsignal(); break;
            case BUILTIN_SIGCONT: signal_type = 13; setsignal(); break;

            case BUILTIN_hard_refresh:

                first_time = 1;

            case BUILTIN_refresh:

                goto restart;

            case BUILTIN_exit:

                goto end;

            case BUILTIN_kill_process:

                if (!kill_process(current_process))
                {
                    tty_beep();
                    memset(global_buf, ' ', SCREEN_X);
                    tmp = xmalloc(16 + strlen((errno==EPERM)?no_perm:no_proc));
                    sprintf(tmp, "Error: %s", (errno==EPERM)?no_perm:no_proc);
                    setstatus(tmp);
                    xfree(tmp);
                    errno = 0;
                    tty_get_key(NULL);
                    setstatus(NULL);
                    setsignal();
                }
                break;
        }
    }

  end:

    clean_up();
    return 0;
}
