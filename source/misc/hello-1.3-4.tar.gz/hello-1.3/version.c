char version[] = "GNU Hello, version 1.3";
