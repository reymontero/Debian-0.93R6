/* Copyright (c) 1994 Sanjay Ghemawat */
#ifndef _MISC_H
#define _MISC_H

/* Support routines. */

extern char* copy_string(char const* str);
// effects - Return a newly allocated copy of "str".

#endif /* _MISC_H */
