/* Copyright (c) 1994 Sanjay Ghemawat */
#include <string.h>
#include "basic.h"
#include "misc.h"

char* copy_string(char const* str) {
    char* out = new char[strlen(str)+1];
    strcpy(out, str);
    return out;
}
