/* Copyright (c) 1993 by Sanjay Ghemawat */
#ifndef _ARRAYS_H
#define _ARRAYS_H

#include "Array.h"

declareArray(charArray,char)
declareArray(intArray,int)
declareArray(pointerArray,void*)

#endif /* _ARRAYS_H */
