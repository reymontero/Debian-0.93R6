/* Copyright (c) 1993 by Sanjay Ghemawat */
#ifndef _VERSION_H
#define _VERSION_H

/*
 * Calendar file version.
 */
static const int VersionMajor = 1;
static const int VersionMinor = 7;

#endif /* _VERSION_H */
