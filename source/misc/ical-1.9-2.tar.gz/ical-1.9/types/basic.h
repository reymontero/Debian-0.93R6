/* Copyright (c) 1994 Sanjay Ghemawat */
#ifndef _BASIC_H
#define _BASIC_H

#include <stdlib.h>
#include "mdebug.h"

/* For compatibility purposes.... */
#define bool bool_type
typedef unsigned char bool;

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#endif /* _BASIC_H */
