#define main tcl_main
#include "copies/tclMain.c"

