#include <tk.h>

#if ((TK_MAJOR_VERSION == 3) && (TK_MINOR_VERSION <= 3))

/* Tk_CreateMainWindow takes only three arguments */

/* A wrapper proc that strips out the extra argument */
static Tk_Window My_CreateMainWindow(interp, screenName, baseName, className)
    Tcl_Interp* interp;
    char* screenName;
    char* baseName;
    char* className;
{
    return (Tk_CreateMainWindow(interp, screenName, baseName));
}

#define Tk_CreateMainWindow My_CreateMainWindow
#endif

#define main tk_main
#define tcl_RcFileName tk_RcFileName
#include "copies/tkMain.c"
