#include <stdio.h>
#include <time.h>

main(argc, argv)
    int    argc;
    char **argv;
{
    struct tm *t;
    time_t     ltime;

    time(&ltime);
    t = localtime(&ltime);
    printf("char datestamp[]=\"%02d-%s-%d\";\n", t->tm_mday, 
	    (t->tm_mon == 0) ? "Jan" : 
	     (t->tm_mon == 1) ? "Feb" : 
	      (t->tm_mon == 2) ? "Mar" : 
	       (t->tm_mon == 3) ? "Apr" : 
		(t->tm_mon == 4) ? "May" : 
		 (t->tm_mon == 5) ? "Jun" : 
		  (t->tm_mon == 6) ? "Jul" : 
		   (t->tm_mon == 7) ? "Aug" : 
		    (t->tm_mon == 8) ? "Sep" : 
		     (t->tm_mon == 9) ? "Oct" : 
		      (t->tm_mon == 10) ? "Nov" : 
		       (t->tm_mon == 11) ? "Dec" : "UKN",
	    1900 + t->tm_year);
    exit(0);
}
