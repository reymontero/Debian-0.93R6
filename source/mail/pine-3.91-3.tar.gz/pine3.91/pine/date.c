char datestamp[]="Sat May 13 16:46:42 CDT 1995";
