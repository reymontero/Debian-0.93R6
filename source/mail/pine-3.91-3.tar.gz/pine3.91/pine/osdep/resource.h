//{{NO_DEPENDENCIES}}
// App Studio generated include file.
// Used by MSWIN.RC
//
#define IDD_OK                          1
#define ABOUTDLGBOX                     100
#define IDM_SETFONT                     103
#define IDM_EDIT_CUT                    105
#define PINEACCELL                      105
#define IDM_EDIT_COPY                   106
#define IDM_EDIT_PASTE                  107
#define IDM_EDIT_CANCEL_PASTE           109
#define IDM_HELP                        110
#define IDM_EDIT_COPY_APPEND            111
#define IDM_FILE_EXIT                   112
#define IDM_ABOUT                       0x104
#define PINEMENU                        300
#define PINEICON                        400
#define PINEBITMAP                      500
#define IDD_ABOUTICON                   0x210
#define IDD_VERSION                     0x212
#define IDD_BYLINE                      0x213
#define IDS_BYLINE                      773
#define IDS_APPNAME                     774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         113
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
