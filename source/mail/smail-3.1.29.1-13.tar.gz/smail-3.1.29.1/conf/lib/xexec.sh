:
# @(#) $Id: xexec.sh,v 1.3 1992/09/06 04:39:25 tron Exp $

echo "	"$*
$*
