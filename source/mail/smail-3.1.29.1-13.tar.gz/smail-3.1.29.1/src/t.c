/*
 * drivertab.c:
 *	define the available director, router, transport and lookup
 *	drivers for use by smail.
 *
 * THIS FILE IS GENERATED AUTOMATICALLY BY THE SCRIPT mkdrivtab.sh FROM
 * THE DRIVER CONFIGURATION FILE ../conf/driver/arpa-network
 * MAKE CHANGES TO THE DRIVER CONF FILE AND REBUILD RATHER THAN EDITING
 * THIS FILE DIRECTLY.
 */

#include <stdio.h>
#include "defs.h"
#include "smail.h"
#include "addr.h"
#include "direct.h"
#include "route.h"
#include "transport.h"

extern struct addr *dtd_aliasinclude();
extern void dtv_aliasinclude();
extern char *dtb_aliasinclude();
extern struct addr *dtd_forwardinclude();
extern void dtv_forwardinclude();
extern char *dtb_forwardinclude();
extern struct addr *dtd_genericinclude();
extern void dtv_genericinclude();
extern char *dtb_genericinclude();
extern struct addr *dtd_aliasfile();
extern void dtv_aliasfile();
extern char *dtb_aliasfile();
extern struct addr *dtd_forwardfile();
extern void dtv_forwardfile();
extern char *dtb_forwardfile();
extern struct addr *dtd_user();
extern void dtv_user();
extern char *dtb_user();
extern struct addr *dtd_smartuser();
extern void dtv_smartuser();
extern char *dtb_smartuser();
extern void rtd_pathalias();
extern void rtv_pathalias();
extern char *rtb_pathalias();
extern void rtc_uuname();
extern void rtd_uuname();
extern void rtv_uuname();
extern void rtf_uuname();
extern char *rtb_uuname();
extern void rtd_smarthost();
extern void rtv_smarthost();
extern char *rtb_smarthost();
extern void rtd_reroute();
extern void rtv_reroute();
extern char *rtb_reroute();
extern void rtd_queryprogram();
extern void rtv_queryprogram();
extern char *rtb_queryprogram();
extern void rtd_gethostbyname();
extern void rtv_gethostbyname();
extern char *rtb_gethostbyname();
extern void rtd_gethostbyaddr();
extern void rtv_gethostbyaddr();
extern char *rtb_gethostbyaddr();
extern void rtd_bind();
extern void rtv_bind();
extern char *rtb_bind();
extern void tpd_pipe();
extern char *tpb_pipe();
extern void tpd_appendfile();
extern char *tpb_appendfile();
extern void tpd_smtp();
extern char *tpb_smtp();
extern void tpd_tcpsmtp();
extern char *tpb_tcpsmtp();
transport library	smtplib.c smtplib.h
struct direct_driver direct_drivers[] = {
    { "aliasinclude",NULL,dtd_aliasinclude,dtv_aliasinclude,NULL,dtb_aliasinclude },
    { "forwardinclude",NULL,dtd_forwardinclude,dtv_forwardinclude,NULL,dtb_forwardinclude },
    { "genericinclude",NULL,dtd_genericinclude,dtv_genericinclude,NULL,dtb_genericinclude },
    { "aliasfile",NULL,dtd_aliasfile,dtv_aliasfile,NULL,dtb_aliasfile },
    { "forwardfile",NULL,dtd_forwardfile,dtv_forwardfile,NULL,dtb_forwardfile },
    { "user",NULL,dtd_user,dtv_user,NULL,dtb_user },
    { "smartuser",NULL,dtd_smartuser,dtv_smartuser,NULL,dtb_smartuser },
    { NULL },
}; 
 
struct route_driver route_drivers[] = {
    { "pathalias",NULL,rtd_pathalias,rtv_pathalias,NULL,rtb_pathalias },
    { "uuname",rtc_uuname,rtd_uuname,rtv_uuname,rtf_uuname,rtb_uuname },
    { "smarthost",NULL,rtd_smarthost,rtv_smarthost,NULL,rtb_smarthost },
    { "reroute",NULL,rtd_reroute,rtv_reroute,NULL,rtb_reroute },
    { "queryprogram",NULL,rtd_queryprogram,rtv_queryprogram,NULL,rtb_queryprogram },
    { "gethostbyname",NULL,rtd_gethostbyname,rtv_gethostbyname,NULL,rtb_gethostbyname },
    { "gethostbyaddr",NULL,rtd_gethostbyaddr,rtv_gethostbyaddr,NULL,rtb_gethostbyaddr },
    { "bind",NULL,rtd_bind,rtv_bind,NULL,rtb_bind },
    { NULL },
}; 
 
struct transport_driver transport_drivers[] = {
    { "pipe",NULL,tpd_pipe,NULL,tpb_pipe },
    { "appendfile",NULL,tpd_appendfile,NULL,tpb_appendfile },
    { "smtp",NULL,tpd_smtp,NULL,tpb_smtp },
    { "tcpsmtp",NULL,tpd_tcpsmtp,NULL,tpb_tcpsmtp },
    { NULL },
}; 
 
