/* @(#) $Id: smartuser.h,v 1.3 1992/07/11 11:48:44 tron Exp $ */

/*
 *    Copyright (C) 1987, 1988 Ronald S. Karr and Landon Curt Noll
 *    Copyright (C) 1992  Ronald S. Karr
 * 
 * See the file COPYING, distributed with smail, for restriction
 * and warranty information.
 */

/*
 * smartuser.h:
 *	interface file for the smartuser driver.
 */

/* boolean attributes for director.flags field */
#define SMARTUSER_WELLFORMED	0x00010000

/* private information from director file entry */
struct smartuser_private {
    char *new_user;			/* template for new address */
};
