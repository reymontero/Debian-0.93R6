/* formatdef.c - some defines for sbr/formatsbr.c */
#ifndef	lint
static char ident[] = "@(#)$Id: formatdef.c,v 1.3 1992/12/15 00:20:22 jromine Exp $";
#endif	/* lint */
#include "../h/addrsbr.h"

int	fmt_norm = AD_NAME;
