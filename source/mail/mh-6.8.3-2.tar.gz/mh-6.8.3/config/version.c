char *version = "@(#)MH 6.8.3 #3[UCI] (lestat) of Tue Feb 28 22:37:21 EST 1995";
