/* s_fastmail.h created from s_fastmail.us by gencat on Sat Oct  3 18:34:11 EDT 1992 */

#define FastmailSet	0x12
#define FastmailCantFindFile	0x1
#define FastmailCouldntOpenTempFile	0x2
#define FastmailMailingTo	0x3
#define FastmailUsage	0x4
