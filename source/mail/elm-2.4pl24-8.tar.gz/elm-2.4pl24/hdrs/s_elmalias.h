/* s_elmalias.h created from s_elmalias.us by gencat on Sun Apr 11 22:03:05 EDT 1993 */

#define ElmaliasSet	0x4
#define ElmaliasUsage	0x1
#define ElmaliasOutOfMemory	0x2
#define ElmaliasCannotSpecifyExpand	0x3
#define ElmaliasUnknownAlias	0x4
#define ElmaliasCannotDetermineHome	0x5
#define ElmaliasIllegalFmtChar	0x6
#define ElmaliasTypePerson	0x7
#define ElmaliasTypeGroup	0x8
#define ElmaliasTypeUnknown	0x9
