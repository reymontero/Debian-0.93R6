/* s_elmrc.h created from s_elmrc.us by gencat on Fri Mar 11 16:18:48 EST 1994 */

#define ElmrcSet	0x1
#define ElmrcExpandHome	0x1
#define ElmrcOpenElmrc	0x2
#define ElmrcExpandShell	0x3
#define ElmrcSavingWithoutComments	0x4
#define ElmrcCantSaveConfig	0x5
#define ElmrcOptionsSavedIn	0x6
#define ElmrcOptionsFile	0x7
#define ElmrcSavedAutoFor	0x8
#define ElmrcSavedAuto	0x9
