/*
 * Author:      William Chia-Wei Cheng (william@cs.ucla.edu)
 *
 * Copyright (C) 1990-1995, William Cheng.
 *
 * Permission limited to the use, copy, display, distribute without
 * charging for a fee, and produce derivative works of "tgif" and
 * its documentation for not-for-profit purpose is hereby granted by
 * the Author, provided that the above copyright notice appears in
 * all copies made of "tgif" and that both the copyright notice
 * and this permission notice appear in supporting documentation,
 * and that the name of the Author not be used in advertising or
 * publicity pertaining to distribution of the software without
 * specific, written prior permission.  The Author makes no
 * representations about the suitability of this software for any
 * purpose.  It is provided "as is" without express or implied
 * warranty.  All other rights (including, but not limited to, the
 * right to sell "tgif", the right to sell derivative works of
 * "tgif", and the right to distribute "tgif" for a fee) are
 * reserved by the Author.
 *
 * THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS,
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
 * LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
 * NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
#ifndef lint
static char RCSid[] =
      "@(#)$Header: /u/multimedia/william/X11/TGIF2/RCS/poly.c,v 2.117 1995/07/10 05:48:15 william Exp $";
#endif

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include "const.h"
#include "types.h"

#include "attr.e"
#include "auxtext.e"
#include "choice.e"
#include "cmd.e"
#include "color.e"
#include "cursor.e"
#include "dialog.e"
#include "drawing.e"
#include "dup.e"
#include "file.e"
#include "grid.e"
#include "mainloop.e"
#include "msg.e"
#include "obj.e"
#include "pattern.e"
#ifndef _NO_EXTERN
#include "poly.e"
#endif
#include "polygon.e"
#include "ps.e"
#include "raster.e"
#include "rect.e"
#include "ruler.e"
#include "select.e"
#include "setup.e"
#include "spline.e"
#include "stretch.e"
#include "xpixmap.e"

#define RETREAT (0.8)

int	polyDrawn = FALSE;

/* short	widthOfLine[] = { 0, 3,  6,  0 }; */
/* short	arrowHeadH[]  = { 3, 5,  10, 3 }; */
/* short	arrowHeadW[]  = { 8, 12, 22, 8 }; */

short	origWidthOfLine[] = { 1, 2,  3,  4,  5,  6,  7 };
short	origArrowHeadH[]  = { 3, 4,  5,  6,  7,  8,  9 };
short	origArrowHeadW[]  = { 8, 10, 12, 14, 18, 20, 22 };

short	* curWidthOfLine=NULL;
short	* curArrowHeadH=NULL;
short	* curArrowHeadW=NULL;

int	drawPolyToEndInANode=0;
char	drawPolyFirstNodeName[MAXSTRING+1];
char	drawPolyLastNodeName[MAXSTRING+1];

struct ObjRec *drawPolyHighlightedNode=NULL;

static struct PtRec	* lastPtPtr=NULL;

XPoint	* MakePolyVertex (XOff, YOff, NumVs, Vs)
   int			XOff, YOff, NumVs;
   register XPoint	* Vs;
{
   register XPoint	* v;
   register int		i;
   int			real_x_off, real_y_off;

   real_x_off = (zoomedIn ? XOff : (XOff>>zoomScale)<<zoomScale);
   real_y_off = (zoomedIn ? YOff : (YOff>>zoomScale)<<zoomScale);

   v = (XPoint *) calloc (NumVs+1, sizeof(XPoint));
   if (v == NULL) FailAllocMessage ();
   for (i = 0; i < NumVs; i++)
   {
      v[i].x = ZOOMED_SIZE(Vs[i].x-real_x_off);
      v[i].y = ZOOMED_SIZE(Vs[i].y-real_y_off);
   }
   return (v);
}

void CalcPolyBBox (ObjPtr)
   struct ObjRec *ObjPtr;
{
   register int x, y;
   struct PolyRec *poly_ptr=ObjPtr->detail.p;
   int style=poly_ptr->style, W=poly_ptr->width;
   int AW=poly_ptr->aw, AH=poly_ptr->ah;
   int ltx=ObjPtr->obbox.ltx, lty=ObjPtr->obbox.lty;
   int rbx=ObjPtr->obbox.rbx, rby=ObjPtr->obbox.rby;
   int dx, dy;
   double len, sin, cos, w, h;
   int num_pts;
   XPoint *v;
   int retracted_arrow=(RetractedArrowAttr(ObjPtr) ||
         AutoRetractedArrowAttr(ObjPtr, TRUE));

   num_pts = (poly_ptr->curved==LT_INTSPLINE ? poly_ptr->intn : poly_ptr->n);
   v = (poly_ptr->curved==LT_INTSPLINE ? poly_ptr->intvlist : poly_ptr->vlist);
   dx = v[1].x - v[0].x;
   dy = v[1].y - v[0].y;
   if ((style & LS_LEFT) && (dx != 0 || dy != 0))
   {
      len = (double)sqrt((double)(((double)dx)*((double)dx) +
            ((double)dy)*((double)dy)));
      sin = ((double)dy) / len;
      cos = ((double)dx) / len;

      w = (double)AW; h = (double)AH;

      x = round(v[0].x + w*cos - h*sin);
      y = round(v[0].y + w*sin + h*cos);
      if (x < ltx) ltx = x; if (y < lty) lty = y;
      if (x > rbx) rbx = x; if (y > rby) rby = y;

      x = round(v[0].x + w*cos + h*sin);
      y = round(v[0].y + w*sin - h*cos);
      if (x < ltx) ltx = x; if (y < lty) lty = y;
      if (x > rbx) rbx = x; if (y > rby) rby = y;

      w = ((double)AW)*RETREAT; h = ((double)W)/2.0;

      x = round(v[0].x + w*cos - h*sin);
      y = round(v[0].y + w*sin + h*cos);
      if (x < ltx) ltx = x; if (y < lty) lty = y;
      if (x > rbx) rbx = x; if (y > rby) rby = y;

      x = round(v[0].x + w*cos + h*sin);
      y = round(v[0].y + w*sin - h*cos);
      if (x < ltx) ltx = x; if (y < lty) lty = y;
      if (x > rbx) rbx = x; if (y > rby) rby = y;
   }

   dx = v[num_pts-1].x - v[num_pts-2].x;
   dy = v[num_pts-1].y - v[num_pts-2].y;
   if ((style & LS_RIGHT) && (dx != 0 || dy != 0))
   {
      len = (double)sqrt((double)(((double)dx)*((double)dx) +
            ((double)dy)*((double)dy)));
      sin = ((double)dy) / len;
      cos = ((double)dx) / len;

      w = (double)AW; h = (double)AH;

      x = round(v[num_pts-1].x - w*cos + h*sin);
      y = round(v[num_pts-1].y - w*sin - h*cos);
      if (x < ltx) ltx = x; if (y < lty) lty = y;
      if (x > rbx) rbx = x; if (y > rby) rby = y;

      x = round(v[num_pts-1].x - w*cos - h*sin);
      y = round(v[num_pts-1].y - w*sin + h*cos);
      if (x < ltx) ltx = x; if (y < lty) lty = y;
      if (x > rbx) rbx = x; if (y > rby) rby = y;
   }

   if (retracted_arrow) {
      int i;

      for (i=1; i < num_pts; i++) {
         x = v[i].x; y = v[i].y;
         if (x-AH < ltx) ltx = x-AH; if (y-AH < lty) lty = y-AH;
         if (x+AH > rbx) rbx = x+AH; if (y+AH > rby) rby = y+AH;
      }
   }
   ObjPtr->bbox.ltx = min(ltx, ObjPtr->obbox.ltx-W/2);
   ObjPtr->bbox.lty = min(lty, ObjPtr->obbox.lty-W/2);
   ObjPtr->bbox.rbx = max(rbx, ObjPtr->obbox.rbx+W/2);
   ObjPtr->bbox.rby = max(rby, ObjPtr->obbox.rby+W/2);
}

void UpdPolyBBox (ObjPtr, NumPts, V)
   struct ObjRec	* ObjPtr;
   int			NumPts;
   XPoint		* V;
{
   register int	i;
   int		ltx, lty, rbx, rby;

   ltx = rbx = V[0].x;
   lty = rby = V[0].y;

   for (i = 1; i < NumPts; i++)
   {
      if (V[i].x < ltx) ltx = V[i].x; if (V[i].y < lty) lty = V[i].y;
      if (V[i].x > rbx) rbx = V[i].x; if (V[i].y > rby) rby = V[i].y;
   }

   ObjPtr->x = ltx;
   ObjPtr->y = lty;
   ObjPtr->obbox.ltx = ltx;
   ObjPtr->obbox.lty = lty;
   ObjPtr->obbox.rbx = rbx;
   ObjPtr->obbox.rby = rby;
   AdjObjBBox (ObjPtr);
}

#define CREATE_RELATIVE (FALSE)
#define CREATE_ABSOLUTE (TRUE)

static
void CreatePolyObj (NumPts, CreateAbsolute)
   int	NumPts;
   int	CreateAbsolute;
{
   struct PtRec		* pt_ptr, * next_pt;
   struct PolyRec	* poly_ptr;
   struct ObjRec	* obj_ptr;
   register int		i;
   XPoint		* v;
   int			ltx, lty, rbx, rby;
   char			* smooth=NULL;

   poly_ptr = (struct PolyRec *) calloc (1, sizeof(struct PolyRec));
   poly_ptr->n = NumPts;
   v = (XPoint *) calloc (NumPts+1, sizeof(XPoint));
   if (v == NULL) FailAllocMessage ();
   if (curSpline != LT_INTSPLINE)
   {
      smooth = (char *) calloc (NumPts+1, sizeof(char));
      if (smooth == NULL) FailAllocMessage ();
   }
   pt_ptr = lastPtPtr;
   ltx = rbx = pt_ptr->x;
   lty = rby = pt_ptr->y;
   for (i = NumPts-1; i >= 0; i--, lastPtPtr = next_pt)
   {
      next_pt = lastPtPtr->next;
      v[i].x = CreateAbsolute ? lastPtPtr->x : ABS_X(lastPtPtr->x);
      v[i].y = CreateAbsolute ? lastPtPtr->y : ABS_Y(lastPtPtr->y);
      if (curSpline != LT_INTSPLINE)
      {
         if (lastPtPtr->x < ltx) ltx = lastPtPtr->x;
         if (lastPtPtr->y < lty) lty = lastPtPtr->y;
         if (lastPtPtr->x > rbx) rbx = lastPtPtr->x;
         if (lastPtPtr->y > rby) rby = lastPtPtr->y;
         if (curSpline == LT_STRAIGHT)
            smooth[i] = FALSE;
         else
            smooth[i] = (i != 0 && i != NumPts-1);
      }
      cfree (lastPtPtr);
   }

   poly_ptr->vlist = v;
   poly_ptr->smooth = smooth;
   poly_ptr->svlist = poly_ptr->asvlist = poly_ptr->intvlist = NULL;
   poly_ptr->style = lineStyle;
   poly_ptr->width = curWidthOfLine[lineWidth];
   poly_ptr->aw = curArrowHeadW[lineWidth];
   poly_ptr->ah = curArrowHeadH[lineWidth];
   poly_ptr->pen = penPat;
   poly_ptr->curved = curSpline;
   poly_ptr->fill = objFill;
   poly_ptr->dash = curDash;
   obj_ptr = (struct ObjRec *) calloc (1, sizeof(struct ObjRec));
   obj_ptr->color = colorIndex;
   obj_ptr->type = OBJ_POLY;
   if (CreateAbsolute)
   {
      obj_ptr->obbox.ltx = obj_ptr->x = ltx;
      obj_ptr->obbox.lty = obj_ptr->y = lty;
      obj_ptr->obbox.rbx = rbx;
      obj_ptr->obbox.rby = rby;
   }
   else
   {
      obj_ptr->obbox.ltx = obj_ptr->x = ABS_X(ltx);
      obj_ptr->obbox.lty = obj_ptr->y = ABS_Y(lty);
      obj_ptr->obbox.rbx = ABS_X(rbx);
      obj_ptr->obbox.rby = ABS_Y(rby);
   }
   obj_ptr->id = objId++;
   obj_ptr->dirty = FALSE;
   obj_ptr->rotation = 0;
   obj_ptr->locked = FALSE;
   obj_ptr->fattr = obj_ptr->lattr = NULL;
   obj_ptr->detail.p = poly_ptr;
   AdjObjSplineVs (obj_ptr);
   if (curSpline != LT_INTSPLINE)
      UpdPolyBBox (obj_ptr, poly_ptr->n, poly_ptr->vlist);
   else
      UpdPolyBBox (obj_ptr, poly_ptr->intn, poly_ptr->intvlist);
   AdjObjBBox (obj_ptr);
   AddObj (NULL, topObj, obj_ptr);
}

static XComposeStatus	c_stat;

static
void ContinuePoly (OrigX, OrigY)
   int 	OrigX, OrigY;
   /* OrigX and OrigY are screen coordinates (scaled and translated). */
   /* OrigX and OrigY are also on grid. */
{
   register int		i;
   XGCValues		values;
   XEvent		input, ev;
   XButtonEvent		* button_ev;
   XMotionEvent		* motion_ev;
   int			xor_pixel, abort=FALSE;
   int 			end_x, end_y, grid_x, grid_y, done=FALSE, num_pts=1;
   int			last_x=OrigX, last_y=OrigY, n=2, sn=0, max_n=40, intn=0;
   int			ltx=OrigX, lty=OrigY, rbx=OrigX, rby=OrigY;
   int			one_line_status=FALSE;
   char			status_buf[MAX_STATUS_BTNS+1][MAXSTRING+1];
   char			buf[80], w_buf[80], h_buf[80], x_buf[80], y_buf[80];
   struct PtRec		* pt_ptr;
   XPoint		* v=NULL, * sv=NULL, * cntrlv=NULL;

   xor_pixel = xorColorPixels[colorIndex];

   values.foreground = xor_pixel;
   values.function = GXxor;
   values.fill_style = FillSolid;
#ifdef NO_THIN_LINE
   values.line_width = 1;
#else
   values.line_width = 0;
#endif
   values.line_style = LineSolid;

   XChangeGC (mainDisplay, drawGC,
         GCForeground | GCFunction | GCFillStyle | GCLineWidth | GCLineStyle,
         &values);

   grid_x = end_x = OrigX;
   grid_y = end_y = OrigY;
   if (curSpline != LT_STRAIGHT && splineRubberband)
   {
      v = (XPoint *) calloc (max_n+1, sizeof (XPoint));
      if (v == NULL) FailAllocMessage ();
      v[0].x = v[1].x = v[2].x = ABS_X(OrigX);
      v[0].y = v[1].y = v[2].y = ABS_Y(OrigY);
      switch (curSpline)
      {
         case LT_SPLINE:
            sv = MakeSplinePolyVertex (&sn, drawOrigX, drawOrigY, n, v);
            break;
         case LT_INTSPLINE:
            sv = MakeIntSplinePolyVertex (&sn, &intn, &cntrlv,
                  drawOrigX, drawOrigY, n, v);
            for (i=0; i < sn; i++)
            {
               if (sv[i].x < ltx) ltx = sv[i].x;
               if (sv[i].y < lty) lty = sv[i].y;
               if (sv[i].x > rbx) rbx = sv[i].x;
               if (sv[i].y > rby) rby = sv[i].y;
            }
            break;
      }
   }
   SaveStatusStrings ();
   if (curChoice == FREEHAND)
   {
      Msg ("Release button to terminate freehand.");
      PixelToMeasurementUnit(x_buf, ABS_X(grid_x));
      PixelToMeasurementUnit(y_buf, ABS_Y(grid_y));
      sprintf (buf, "%s%s", x_buf, y_buf);
      StartShowMeasureCursor (grid_x, grid_y, buf, TRUE);
      XGrabPointer (mainDisplay, drawWindow, FALSE,
            PointerMotionMask | ButtonReleaseMask,
            GrabModeAsync, GrabModeAsync, None, handCursor, CurrentTime);
   }
   else
   {
      SetMouseStatus ("Add a vertex", "Add last vertex", "Add last vertex");
      Msg ("Click middle or right button to end poly.");
      PixelToMeasurementUnit(w_buf, 0);
      PixelToMeasurementUnit(h_buf, 0);
      PixelToMeasurementUnit(x_buf, ABS_X(grid_x));
      PixelToMeasurementUnit(y_buf, ABS_Y(grid_y));
      sprintf (buf, "%sx%s%s%s", w_buf, h_buf, x_buf, y_buf);
      StartShowMeasureCursor (grid_x, grid_y, buf, TRUE);
      XGrabPointer (mainDisplay, drawWindow, FALSE,
            PointerMotionMask | ButtonPressMask,
            GrabModeAsync, GrabModeAsync, None, handCursor, CurrentTime);
   }
   if (drawPolyToEndInANode > 0) {
      *drawPolyLastNodeName = '\0';
      drawPolyHighlightedNode = NULL;
      SaveStatusStringsIntoBuf(status_buf, &one_line_status);
      values.line_width = 3;
      XChangeGC(mainDisplay, revGrayGC, GCLineWidth, &values);
   }
   while (!done)
   {
      XNextEvent (mainDisplay, &input);

      if (input.type == Expose || input.type == VisibilityNotify)
         ExposeEventHandler (&input, TRUE);
      else if (input.type == MotionNotify)
      {
         if (curChoice == FREEHAND)
         {
            PixelToMeasurementUnit(x_buf, ABS_X(grid_x));
            PixelToMeasurementUnit(y_buf, ABS_Y(grid_y));
            sprintf (buf, "%s%s", x_buf, y_buf);
         }
         else
         {
            PixelToMeasurementUnit(w_buf, ABS_SIZE(abs(grid_x-OrigX)));
            PixelToMeasurementUnit(h_buf, ABS_SIZE(abs(grid_y-OrigY)));
            PixelToMeasurementUnit(x_buf, ABS_X(grid_x));
            PixelToMeasurementUnit(y_buf, ABS_Y(grid_y));
            sprintf (buf, "%sx%s%s%s", w_buf, h_buf, x_buf, y_buf);
         }
         ShowMeasureCursor (grid_x, grid_y, buf, TRUE);
         if (curSpline != LT_STRAIGHT && splineRubberband)
         {
#ifdef HP_LINE_BUG
            if (sn == 2)
            {
               XPoint hp_sv[3];

               hp_sv[0].x = sv[0].x; hp_sv[0].y = sv[0].y;
               hp_sv[1].x = sv[0].x; hp_sv[1].y = sv[0].y;
               hp_sv[2].x = sv[1].x; hp_sv[2].y = sv[1].y;
               XDrawLines (mainDisplay, drawWindow, drawGC, hp_sv, 3,
                     CoordModeOrigin);
            }
            else
               XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                     CoordModeOrigin);
#else
            XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                  CoordModeOrigin);
#endif
         }
         else
            XDrawLine (mainDisplay, drawWindow, drawGC, OrigX, OrigY, grid_x,
                  grid_y);
         motion_ev = &(input.xmotion);
         end_x = motion_ev->x;
         end_y = motion_ev->y;
         if (curChoice == FREEHAND)
         {
            grid_x = end_x;
            grid_y = end_y;
            MarkRulers (grid_x, grid_y);
            if (curSpline != LT_STRAIGHT && splineRubberband)
            {
               if (sv != NULL) cfree (sv);
               v[n-1].x = v[n].x = ABS_X(grid_x);
               v[n-1].y = v[n].y = ABS_Y(grid_y);
               switch (curSpline)
               {
                  case LT_SPLINE:
                     sv = MakeSplinePolyVertex (&sn,drawOrigX,drawOrigY,n,v);
                     break;
                  case LT_INTSPLINE:
                     if (cntrlv != NULL) cfree (cntrlv);
                     sv = MakeIntSplinePolyVertex (&sn, &intn, &cntrlv,
                           drawOrigX, drawOrigY, n, v);
                     for (i=0; i < sn; i++)
                     {
                        if (sv[i].x < ltx) ltx = sv[i].x;
                        if (sv[i].y < lty) lty = sv[i].y;
                        if (sv[i].x > rbx) rbx = sv[i].x;
                        if (sv[i].y > rby) rby = sv[i].y;
                     }
                     break;
               }
#ifdef HP_LINE_BUG
               if (sn == 2)
               {
                  XPoint hp_sv[3];

                  hp_sv[0].x = sv[0].x; hp_sv[0].y = sv[0].y;
                  hp_sv[1].x = sv[0].x; hp_sv[1].y = sv[0].y;
                  hp_sv[2].x = sv[1].x; hp_sv[2].y = sv[1].y;
                  XDrawLines (mainDisplay, drawWindow, drawGC, hp_sv, 3,
                        CoordModeOrigin);
               }
               else
                  XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                        CoordModeOrigin);
#else
               XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                     CoordModeOrigin);
#endif
            }
            else
               XDrawLine (mainDisplay, drawWindow, drawGC, OrigX, OrigY, grid_x,
                     grid_y);
            while (XCheckMaskEvent (mainDisplay, PointerMotionMask, &ev)) ;

            if (grid_x != last_x || grid_y != last_y)
            {
               num_pts++;
               pt_ptr = (struct PtRec *) calloc (1, sizeof(struct PtRec));
               pt_ptr->next = lastPtPtr;
               lastPtPtr = pt_ptr;
               pt_ptr->x = last_x = grid_x;
               pt_ptr->y = last_y = grid_y;
               if (curSpline != LT_STRAIGHT && splineRubberband)
               {
                  if (n >= max_n-2)
                  {
                     max_n += 40;
                     v = (XPoint *) realloc (v, sizeof(XPoint)*max_n+1);
                     if (v == NULL) FailAllocMessage ();
                  }
#ifdef HP_LINE_BUG
                  if (sn == 2)
                  {
                     XPoint hp_sv[3];

                     hp_sv[0].x = sv[0].x; hp_sv[0].y = sv[0].y;
                     hp_sv[1].x = sv[0].x; hp_sv[1].y = sv[0].y;
                     hp_sv[2].x = sv[1].x; hp_sv[2].y = sv[1].y;
                     XDrawLines (mainDisplay, drawWindow, drawGC, hp_sv, 3,
                           CoordModeOrigin);
                  }
                  else
                     XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                           CoordModeOrigin);
#else
                  XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                        CoordModeOrigin);
#endif
                  if (sv != NULL) cfree (sv);
                  v[n].x = v[n+1].x = ABS_X(grid_x);
                  v[n].y = v[n+1].y = ABS_Y(grid_y);
                  n++;
                  switch (curSpline)
                  {
                     case LT_SPLINE:
                        sv = MakeSplinePolyVertex (&sn,drawOrigX,drawOrigY,n,v);
                        break;
                     case LT_INTSPLINE:
                        if (cntrlv != NULL) cfree (cntrlv);
                        sv = MakeIntSplinePolyVertex (&sn, &intn, &cntrlv,
                              drawOrigX, drawOrigY, n, v);
                        for (i=0; i < sn; i++)
                        {
                           if (sv[i].x < ltx) ltx = sv[i].x;
                           if (sv[i].y < lty) lty = sv[i].y;
                           if (sv[i].x > rbx) rbx = sv[i].x;
                           if (sv[i].y > rby) rby = sv[i].y;
                        }
                        break;
                  }
#ifdef HP_LINE_BUG
                  if (sn == 2)
                  {
                     XPoint hp_sv[3];

                     hp_sv[0].x = sv[0].x; hp_sv[0].y = sv[0].y;
                     hp_sv[1].x = sv[0].x; hp_sv[1].y = sv[0].y;
                     hp_sv[2].x = sv[1].x; hp_sv[2].y = sv[1].y;
                     XDrawLines (mainDisplay, drawWindow, drawGC, hp_sv, 3,
                           CoordModeOrigin);
                  }
                  else
                     XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                           CoordModeOrigin);
#else
                  XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                        CoordModeOrigin);
#endif
               }
            }
            OrigX = grid_x; OrigY = grid_y;
            PixelToMeasurementUnit(x_buf, ABS_X(grid_x));
            PixelToMeasurementUnit(y_buf, ABS_Y(grid_y));
            sprintf (buf, "%s%s", x_buf, y_buf);
            ShowMeasureCursor (grid_x, grid_y, buf, TRUE);
         }
         else
         {
            if (drawPolyToEndInANode > 0) {
               int need_to_highlight=FALSE, something_changed=FALSE;
               struct ObjRec *owner_obj=NULL, *obj_ptr, *obj_under_cursor=NULL;
               struct AttrRec *attr_ptr;

               *drawPolyLastNodeName = '\0';
               obj_ptr = FindAnObj(end_x, end_y, &owner_obj, &obj_under_cursor,
                     drawPolyLastNodeName);
               if (drawPolyHighlightedNode != NULL) {
                  if (obj_under_cursor != drawPolyHighlightedNode) {
                     /* un-highlight */
                     SelBox(drawWindow, revGrayGC,
                           OFFSET_X(drawPolyHighlightedNode->bbox.ltx)-2,
                           OFFSET_Y(drawPolyHighlightedNode->bbox.lty)-2,
                           OFFSET_X(drawPolyHighlightedNode->bbox.rbx)+2,
                           OFFSET_Y(drawPolyHighlightedNode->bbox.rby)+2);
                     if (obj_under_cursor != NULL &&
                           (attr_ptr=FindAttrWithName(obj_under_cursor, "type=",
                           NULL)) != NULL && strcmp(attr_ptr->s, "port")==0) {
                        drawPolyHighlightedNode = obj_under_cursor;
                     } else {
                        drawPolyHighlightedNode = NULL;
                     }
                     if (drawPolyHighlightedNode != NULL) {
                        need_to_highlight = TRUE;
                     }
                     something_changed = TRUE;
                  }
               } else {
                  if (obj_under_cursor != NULL) {
                     if ((attr_ptr=FindAttrWithName(obj_under_cursor, "type=",
                           NULL)) != NULL && strcmp(attr_ptr->s, "port")==0) {
                        drawPolyHighlightedNode = obj_under_cursor;
                     } else {
                        drawPolyHighlightedNode = NULL;
                     }
                     if (drawPolyHighlightedNode != NULL) {
                        need_to_highlight = TRUE;
                        something_changed = TRUE;
                     }
                  }
               }
               if (need_to_highlight) {
                  SelBox(drawWindow, revGrayGC,
                        OFFSET_X(drawPolyHighlightedNode->bbox.ltx)-2,
                        OFFSET_Y(drawPolyHighlightedNode->bbox.lty)-2,
                        OFFSET_X(drawPolyHighlightedNode->bbox.rbx)+2,
                        OFFSET_Y(drawPolyHighlightedNode->bbox.rby)+2);
               }
               if (something_changed) {
                  if (*drawPolyLastNodeName != '\0') {
                     SetStringStatus(drawPolyLastNodeName);
                  } else {
                     RestoreStatusStringsFromBuf (status_buf, one_line_status);
                  }
               }
               if (drawPolyHighlightedNode != NULL) {
                  grid_x = OFFSET_X((drawPolyHighlightedNode->obbox.ltx +
                        drawPolyHighlightedNode->obbox.rbx)>>1);
                  grid_y = OFFSET_Y((drawPolyHighlightedNode->obbox.lty +
                        drawPolyHighlightedNode->obbox.rby)>>1);
               } else {
                  GridXY (end_x, end_y, &grid_x, &grid_y);
               }
            } else {
               GridXY (end_x, end_y, &grid_x, &grid_y);
            }
            MarkRulers (grid_x, grid_y);
            if (curSpline != LT_STRAIGHT && splineRubberband)
            {
               if (sv != NULL) cfree (sv);
               v[n-1].x = v[n].x = ABS_X(grid_x);
               v[n-1].y = v[n].y = ABS_Y(grid_y);
               switch (curSpline)
               {
                  case LT_SPLINE:
                     sv = MakeSplinePolyVertex (&sn,drawOrigX,drawOrigY,n,v);
                     break;
                  case LT_INTSPLINE:
                     cfree (cntrlv);
                     sv = MakeIntSplinePolyVertex (&sn, &intn, &cntrlv,
                           drawOrigX, drawOrigY, n, v);
                     for (i=0; i < sn; i++)
                     {
                        if (sv[i].x < ltx) ltx = sv[i].x;
                        if (sv[i].y < lty) lty = sv[i].y;
                        if (sv[i].x > rbx) rbx = sv[i].x;
                        if (sv[i].y > rby) rby = sv[i].y;
                     }
                     break;
               }
#ifdef HP_LINE_BUG
               if (sn == 2)
               {
                  XPoint hp_sv[3];

                  hp_sv[0].x = sv[0].x; hp_sv[0].y = sv[0].y;
                  hp_sv[1].x = sv[0].x; hp_sv[1].y = sv[0].y;
                  hp_sv[2].x = sv[1].x; hp_sv[2].y = sv[1].y;
                  XDrawLines (mainDisplay, drawWindow, drawGC, hp_sv, 3,
                        CoordModeOrigin);
               }
               else
                  XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                        CoordModeOrigin);
#else
               XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                     CoordModeOrigin);
#endif
            }
            else
               XDrawLine (mainDisplay, drawWindow, drawGC, OrigX, OrigY, grid_x,
                     grid_y);
            PixelToMeasurementUnit(w_buf, ABS_SIZE(abs(grid_x-OrigX)));
            PixelToMeasurementUnit(h_buf, ABS_SIZE(abs(grid_y-OrigY)));
            PixelToMeasurementUnit(x_buf, ABS_X(grid_x));
            PixelToMeasurementUnit(y_buf, ABS_Y(grid_y));
            sprintf (buf, "%sx%s%s%s", w_buf, h_buf, x_buf, y_buf);
            ShowMeasureCursor (grid_x, grid_y, buf, TRUE);
            while (XCheckMaskEvent (mainDisplay, PointerMotionMask, &ev)) ;
         }
      }
      else if (input.type == ButtonPress && curChoice != FREEHAND)
      {
         PixelToMeasurementUnit(w_buf, ABS_SIZE(abs(grid_x-OrigX)));
         PixelToMeasurementUnit(h_buf, ABS_SIZE(abs(grid_y-OrigY)));
         PixelToMeasurementUnit(x_buf, ABS_X(grid_x));
         PixelToMeasurementUnit(y_buf, ABS_Y(grid_y));
         sprintf (buf, "%sx%s%s%s", w_buf, h_buf, x_buf, y_buf);
         EndShowMeasureCursor (grid_x, grid_y, buf, TRUE);

         button_ev = &(input.xbutton);

         end_x = button_ev->x;
         end_y = button_ev->y;
         if (drawPolyHighlightedNode != NULL) {
            grid_x = OFFSET_X((drawPolyHighlightedNode->obbox.ltx +
                  drawPolyHighlightedNode->obbox.rbx)>>1);
            grid_y = OFFSET_Y((drawPolyHighlightedNode->obbox.lty +
                  drawPolyHighlightedNode->obbox.rby)>>1);
         } else {
            GridXY (end_x, end_y, &grid_x, &grid_y);
         }
         if (grid_x != last_x || grid_y != last_y)
         {
            num_pts++;
            pt_ptr = (struct PtRec *) calloc (1, sizeof(struct PtRec));
            pt_ptr->next = lastPtPtr;
            lastPtPtr = pt_ptr;
            pt_ptr->x = last_x = grid_x;
            pt_ptr->y = last_y = grid_y;
            if (curSpline != LT_STRAIGHT && splineRubberband)
            {
               if (n >= max_n-2)
               {
                  max_n += 40;
                  v = (XPoint *) realloc (v, sizeof(XPoint)*max_n+1);
                  if (v == NULL) FailAllocMessage ();
               }
#ifdef HP_LINE_BUG
               if (sn == 2)
               {
                  XPoint hp_sv[3];

                  hp_sv[0].x = sv[0].x; hp_sv[0].y = sv[0].y;
                  hp_sv[1].x = sv[0].x; hp_sv[1].y = sv[0].y;
                  hp_sv[2].x = sv[1].x; hp_sv[2].y = sv[1].y;
                  XDrawLines (mainDisplay, drawWindow, drawGC, hp_sv, 3,
                        CoordModeOrigin);
               }
               else
                  XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                        CoordModeOrigin);
#else
               XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                     CoordModeOrigin);
#endif
               if (sv != NULL) cfree (sv);
               v[n].x = v[n+1].x = ABS_X(grid_x);
               v[n].y = v[n+1].y = ABS_Y(grid_y);
               n++;
               switch (curSpline)
               {
                  case LT_SPLINE:
                     sv = MakeSplinePolyVertex (&sn,drawOrigX,drawOrigY,n,v);
                     break;
                  case LT_INTSPLINE:
                     if (cntrlv != NULL) cfree (cntrlv);
                     sv = MakeIntSplinePolyVertex (&sn, &intn, &cntrlv,
                           drawOrigX, drawOrigY, n, v);
                     for (i=0; i < sn; i++)
                     {
                        if (sv[i].x < ltx) ltx = sv[i].x;
                        if (sv[i].y < lty) lty = sv[i].y;
                        if (sv[i].x > rbx) rbx = sv[i].x;
                        if (sv[i].y > rby) rby = sv[i].y;
                     }
                     break;
               }
#ifdef HP_LINE_BUG
               if (sn == 2)
               {
                  XPoint hp_sv[3];

                  hp_sv[0].x = sv[0].x; hp_sv[0].y = sv[0].y;
                  hp_sv[1].x = sv[0].x; hp_sv[1].y = sv[0].y;
                  hp_sv[2].x = sv[1].x; hp_sv[2].y = sv[1].y;
                  XDrawLines (mainDisplay, drawWindow, drawGC, hp_sv, 3,
                        CoordModeOrigin);
               }
               else
                  XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                        CoordModeOrigin);
#else
               XDrawLines (mainDisplay, drawWindow, drawGC, sv, sn,
                     CoordModeOrigin);
#endif
            }
         }

         switch (button_ev->button)
         {
            case Button1:
               OrigX = grid_x; OrigY = grid_y;
               PixelToMeasurementUnit(w_buf, 0);
               PixelToMeasurementUnit(h_buf, 0);
               PixelToMeasurementUnit(x_buf, ABS_X(grid_x));
               PixelToMeasurementUnit(y_buf, ABS_Y(grid_y));
               sprintf (buf, "%sx%s%s%s", w_buf, h_buf, x_buf, y_buf);
               StartShowMeasureCursor (grid_x, grid_y, buf, TRUE);
               break;
            case Button2: done = TRUE; break;
            case Button3: done = TRUE; break;
         }
      }
      else if (input.type == ButtonRelease && curChoice == FREEHAND)
      {
         PixelToMeasurementUnit(x_buf, ABS_X(grid_x));
         PixelToMeasurementUnit(y_buf, ABS_Y(grid_y));
         sprintf (buf, "%s%s", x_buf, y_buf);
         EndShowMeasureCursor (grid_x, grid_y, buf, TRUE);

         button_ev = &(input.xbutton);

         if (grid_x != last_x || grid_y != last_y)
         {
            num_pts++;
            pt_ptr = (struct PtRec *) calloc (1, sizeof(struct PtRec));
            pt_ptr->next = lastPtPtr;
            lastPtPtr = pt_ptr;
            pt_ptr->x = last_x = grid_x;
            pt_ptr->y = last_y = grid_y;
         }
         done = TRUE;
      }
      else if (input.type == KeyPress)
      {
         KeySym	key_sym;
         char	s[80];

         XLookupString (&(input.xkey), s, 80-1, &key_sym, &c_stat);
         TranslateKeys (s, &key_sym);
         if (s[0] == '\033' && (key_sym & 0xff) == '\033')
         {
            if (curChoice == FREEHAND)
            {
               PixelToMeasurementUnit(x_buf, ABS_X(grid_x));
               PixelToMeasurementUnit(y_buf, ABS_Y(grid_y));
               sprintf (buf, "%s%s", x_buf, y_buf);
            }
            else
            {
               PixelToMeasurementUnit(w_buf, ABS_SIZE(abs(grid_x-OrigX)));
               PixelToMeasurementUnit(h_buf, ABS_SIZE(abs(grid_y-OrigY)));
               PixelToMeasurementUnit(x_buf, ABS_X(grid_x));
               PixelToMeasurementUnit(y_buf, ABS_Y(grid_y));
               sprintf (buf, "%sx%s%s%s", w_buf, h_buf, x_buf, y_buf);
            }
            EndShowMeasureCursor (grid_x, grid_y, buf, TRUE);
            abort = TRUE;
            done = TRUE;
         }
      }
   }
   if (drawPolyHighlightedNode != NULL) {
      SelBox(drawWindow, revGrayGC,
            OFFSET_X(drawPolyHighlightedNode->bbox.ltx)-2,
            OFFSET_Y(drawPolyHighlightedNode->bbox.lty)-2,
            OFFSET_X(drawPolyHighlightedNode->bbox.rbx)+2,
            OFFSET_Y(drawPolyHighlightedNode->bbox.rby)+2);
      drawPolyHighlightedNode = NULL;
   }
   XUngrabPointer (mainDisplay, CurrentTime);
   if (drawPolyToEndInANode > 0) {
      values.line_width = 1;
      XChangeGC(mainDisplay, revGrayGC, GCLineWidth, &values);
      RestoreStatusStringsFromBuf(status_buf, one_line_status);
   }
   RestoreStatusStrings ();
   SetMouseStatus (NULL, NULL, NULL);
   Msg ("");

   if (curSpline != LT_STRAIGHT && splineRubberband)
   {
      cfree (v); cfree (sv);
      if (curSpline == LT_INTSPLINE && cntrlv != NULL) cfree (cntrlv);
   }

   if (!abort && num_pts > 1)
   {
      CreatePolyObj (num_pts, CREATE_RELATIVE);
      RecordNewObjCmd ();
      RedrawAnArea (botObj, topObj->bbox.ltx-GRID_ABS_SIZE(1),
            topObj->bbox.lty-GRID_ABS_SIZE(1),
            topObj->bbox.rbx+GRID_ABS_SIZE(1),
            topObj->bbox.rby+GRID_ABS_SIZE(1));
      polyDrawn = TRUE;
      SetFileModified (TRUE);
   }
   else
   {
      struct PtRec	* pt_ptr, * next_pt;

      if (curSpline != LT_INTSPLINE)
      {
         ltx = rbx = grid_x;
         lty = rby = grid_y;
      }
      for (pt_ptr=lastPtPtr; pt_ptr != NULL; pt_ptr=next_pt)
      {
         next_pt = pt_ptr->next;
         if (curSpline != LT_INTSPLINE)
         {
            if (pt_ptr->x < ltx) ltx = pt_ptr->x;
            if (pt_ptr->y < lty) lty = pt_ptr->y;
            if (pt_ptr->x > rbx) rbx = pt_ptr->x;
            if (pt_ptr->y > rby) rby = pt_ptr->y;
         }
         cfree (pt_ptr);
      }
      RedrawAnArea (botObj, ABS_X(ltx)-GRID_ABS_SIZE(1),
            ABS_Y(lty)-GRID_ABS_SIZE(1), ABS_X(rbx)+GRID_ABS_SIZE(1),
            ABS_Y(rby)+GRID_ABS_SIZE(1));
      lastPtPtr = NULL;
      polyDrawn = FALSE;
   }
   if (drawPolyToEndInANode == 2 && !polyDrawn) {
      drawPolyToEndInANode = (-1);
   }
}

void DrawPoly (input)
   XEvent	* input;
{
   int		mouse_x, mouse_y, grid_x, grid_y;
   XButtonEvent	* button_ev;

   if (input->type != ButtonPress) return;

   button_ev = &(input->xbutton);
   if (button_ev->button == Button1)
   {
      mouse_x = input->xbutton.x;
      mouse_y = input->xbutton.y;
      if (drawPolyToEndInANode > 0 || curChoice == FREEHAND) {
         if (drawPolyHighlightedNode != NULL) {
            grid_x = OFFSET_X((drawPolyHighlightedNode->obbox.ltx +
                  drawPolyHighlightedNode->obbox.rbx)>>1);
            grid_y = OFFSET_Y((drawPolyHighlightedNode->obbox.lty +
                  drawPolyHighlightedNode->obbox.rby)>>1);
            SelBox(drawWindow, revGrayGC,
                  OFFSET_X(drawPolyHighlightedNode->bbox.ltx)-2,
                  OFFSET_Y(drawPolyHighlightedNode->bbox.lty)-2,
                  OFFSET_X(drawPolyHighlightedNode->bbox.rbx)+2,
                  OFFSET_Y(drawPolyHighlightedNode->bbox.rby)+2);
            drawPolyHighlightedNode = NULL;
         } else {
            grid_x = mouse_x;
            grid_y = mouse_y;
         }
      } else {
         GridXY (mouse_x, mouse_y, &grid_x, &grid_y);
      }
      lastPtPtr = (struct PtRec *) calloc (1, sizeof(struct PtRec));
      lastPtPtr->x = grid_x;
      lastPtPtr->y = grid_y;
      lastPtPtr->next = NULL;
      ContinuePoly (grid_x, grid_y);
   } 
}

void InputPolyPts ()
{
   char			inbuf[MAXSTRING+1];
   int			more_poly=FALSE, num_polys=0;
   int			started_composite=FALSE;
   struct ObjRec	* saved_top_obj=topObj;

   MakeQuiescent ();
   XSync (mainDisplay, False);
   do
   {
      int		len, ok=TRUE, num_pts=0, eof=TRUE;
      struct PtRec	* pt_ptr;

      more_poly = FALSE;
      lastPtPtr = NULL;
      printf ("Please input pairs of points: ");
      printf ("(terminate with \"<Cntrl>d<CR>\" or \".<CR>\", ");
      printf ("continue to next poly with \";<CR>\")\n");
      printf ("> ");
      fflush (stdout);
      while (ok && fgets (inbuf, MAXSTRING, stdin) != NULL)
      {
         if (strcmp (inbuf, ";\n") == 0)
         {
            more_poly = TRUE;
            eof = FALSE;
            break;
         }
         if (strcmp (inbuf, ".\n") == 0) { eof = FALSE; break; }
         len = strlen (inbuf);
         if (len > 0)
         {
            char * c_ptr=strtok(inbuf," ,\t\n"), * c_ptr1=NULL;
   
            if (c_ptr != NULL)
               c_ptr1 = strtok(NULL," ,\t\n");
            if (c_ptr1 != NULL)
               while (strchr (" ,\t\n", *c_ptr1)) c_ptr1++;
            while (c_ptr != NULL && c_ptr1 != NULL)
            {
               num_pts++;
               pt_ptr = (struct PtRec *)calloc(1,sizeof(struct PtRec));
               pt_ptr->next = lastPtPtr;
               if (sscanf (c_ptr, "%d", &pt_ptr->x) != 1 ||
                     sscanf (c_ptr1, "%d", &pt_ptr->y) != 1)
               {
                  ok = FALSE;
                  MsgBox ("Error reading integer for poly points.",
                        TOOL_NAME, INFO_MB);
                  XSync (mainDisplay, False);
                  break;
               }
               lastPtPtr = pt_ptr;
               c_ptr = strtok(NULL," ,\t\n");
               if (c_ptr != NULL)
                  c_ptr1 = strtok(NULL," ,\t\n");
               if (c_ptr1 != NULL)
                  while (strchr (" ,\t\n", *c_ptr1)) c_ptr1++;
            }
            if (c_ptr != NULL)
            {
               ok = FALSE;
               MsgBox ("Error reading integer for poly points.",
                     TOOL_NAME, INFO_MB);
               XSync (mainDisplay, False);
            }
         }
         printf ("> ");
         fflush (stdout);
      }
      printf ("\n");
      if (eof) rewind (stdin);
      if (ok && num_pts > 1)
      {
         num_polys++;
         CreatePolyObj (num_pts, CREATE_ABSOLUTE);
         if (more_poly || num_polys > 1)
         {
            if (num_polys <= 1)
            {
               StartCompositeCmd ();
               started_composite = TRUE;
            }
            RecordNewObjCmd ();
            DrawObj (drawWindow, topObj);
         }
         else
         {
            RecordNewObjCmd ();
            RedrawAnArea (botObj, topObj->bbox.ltx-GRID_ABS_SIZE(1),
                  topObj->bbox.lty-GRID_ABS_SIZE(1),
                  topObj->bbox.rbx+GRID_ABS_SIZE(1),
                  topObj->bbox.rby+GRID_ABS_SIZE(1));
            SelectTopObj ();
            SetFileModified (TRUE);
            justDupped = FALSE;
         }
      }
      if (ok && num_pts <= 1)
      {
         MsgBox ("Too few points.", TOOL_NAME, INFO_MB);
         XSync (mainDisplay, False);
      }
      for ( ; lastPtPtr != NULL; lastPtPtr=pt_ptr)
      {
         pt_ptr = lastPtPtr->next;
         cfree (pt_ptr);
      }
   } while (more_poly);
   if (num_polys > 1 || started_composite)
   {
      SelectAndHighLightNewObjects (saved_top_obj);
      GroupSelObj ();
      EndCompositeCmd ();

      SetFileModified (TRUE);
      justDupped = FALSE;
   }
}

static
void DumpArrow (FP, TailV, HeadV, ArrowW, ArrowH, Pen, ColorIndex)
   FILE		* FP;
   XPoint	TailV, HeadV;
   int		ArrowW, ArrowH, Pen, ColorIndex;
{
   int		i, dx, dy;
   struct BBRec	bbox;
   XPoint	v[2];
   double	len, sin, cos;

   dx = HeadV.x - TailV.x;
   dy = HeadV.y - TailV.y;

   if (dx == 0 && dy == 0) return;

   fprintf (FP, "gsave\n");

   if (colorDump)
   {
      len = (double)sqrt((double)(((double)dx)*((double)dx) +
            ((double)dy)*((double)dy)));
      sin = ((double)dy) / len;
      cos = ((double)dx) / len;

      v[0].x = round(HeadV.x - ArrowW*cos + ArrowH*sin);
      v[0].y = round(HeadV.y - ArrowW*sin - ArrowH*cos);
      v[1].x = round(HeadV.x - ArrowW*cos - ArrowH*sin);
      v[1].y = round(HeadV.y - ArrowW*sin + ArrowH*cos);

      bbox.ltx = bbox.rbx = HeadV.x;
      bbox.lty = bbox.rby = HeadV.y;

      for (i = 0; i < 2; i++)
      {
         if (v[i].x < bbox.ltx) bbox.ltx = v[i].x;
         if (v[i].y < bbox.lty) bbox.lty = v[i].y;
         if (v[i].x > bbox.rbx) bbox.rbx = v[i].x;
         if (v[i].y > bbox.rby) bbox.rby = v[i].y;
      }
      if (preDumpSetup) PSUseArrow();
      fprintf (FP, "   newpath\n");
      fprintf (FP, "      %1d %1d %1d %1d %1d %1d tgifarrowtip\n",
            HeadV.x, HeadV.y, ArrowW, ArrowH, dx, dy);
      fprintf (FP, "   1 setgray closepath fill\n");
      DumpRGBColorLine(FP, ColorIndex, 3, TRUE);
   }
   else
   {
      switch (Pen)
      {
         case SOLIDPAT: break;
         case BACKPAT: break;
         default:
            GrayCheck (Pen);
            if (useGray)
               fprintf (FP, "   %s setgray\n", GrayStr(Pen));
            else
            {
               if (preDumpSetup) PSUseBWPattern();
               fprintf (FP, "   pat%1d %s\n", Pen, patternStr);
            }
            break;
      }
   }

   if (!(colorDump && Pen==BACKPAT))
   {
      if (preDumpSetup) PSUseArrow();
      fprintf (FP, "   newpath\n");
      fprintf (FP, "      %1d %1d %1d %1d %1d %1d tgifarrowtip\n",
            HeadV.x, HeadV.y, ArrowW, ArrowH, dx, dy);
   }

   if (colorDump)
   {
      switch (Pen)
      {
         case SOLIDPAT: fprintf (FP, "   closepath fill\n"); break;
         case BACKPAT: break;
         default:
            if (preDumpSetup) PSUseColorPattern();
            fprintf (FP, "   closepath eoclip newpath\n");
            DumpPatFill (FP, Pen, 8, bbox, "   ");
            break;
      }
   }
   else
   {
      switch (Pen)
      {
         case SOLIDPAT: fprintf (FP, "   closepath fill\n"); break;
         case BACKPAT: fprintf (FP, "   closepath 1 setgray fill\n"); break;
         default: fprintf (FP, "   closepath fill\n"); break;
      }
   }
   fprintf (FP, "grestore\n");
}

static
void DumpPolyPath (FP, ObjPtr, Vs, NumPts, Smooth, Style, Width, ArrowWidth,
      ArrowHeight, Pen, Fill, Curved, Dash, Indent)
   FILE				* FP;
   register struct ObjRec	* ObjPtr;
   XPoint			* Vs;
   int				NumPts, Style, Width, ArrowWidth, ArrowHeight;
   int				Pen, Fill, Curved, Dash, Indent;
   char				* Smooth;
{
   register int	i, dx, dy;
   int		w, aw, retracted_arrow, color_index=ObjPtr->color;

   retracted_arrow = (RetractedArrowAttr(ObjPtr) ||
         AutoRetractedArrowAttr(ObjPtr, TRUE));
   w = Width;
   aw = ArrowWidth;

   if (Fill == (-1) && Pen != (-1))
   {  /* dumping the pen */
      if (Width != 1)
      {
         for (i=0; i < Indent+3; i++) fprintf (FP, " ");
         fprintf (FP, "%1d setlinewidth\n", w);
      }
      if (Dash != 0)
      {
         for (i=0; i < Indent+3; i++) fprintf (FP, " ");
         fprintf (FP, "[");
         for (i = 0; i < dashListLength[Dash]-1; i++)
            fprintf (FP, "%1d ", (int)(dashList[Dash][i]));
         fprintf (FP, "%1d] 0 setdash\n",
               (int)(dashList[Dash][dashListLength[Dash]-1]));
      }
   }
   else if (Fill != (-1) && Pen == (-1))
   {  /* dumping the fill */
      if (Fill > BACKPAT)
      {
         for (i=0; i < Indent; i++) fprintf (FP, " ");
         fprintf (FP, "gsave\n");
         if (!colorDump)
         {
            GrayCheck (Fill);
            for (i=0; i < Indent+3; i++) fprintf (FP, " ");
            if (useGray)
               fprintf(FP, "%s setgray\n", GrayStr(Fill));
            else
            {
               if (preDumpSetup) PSUseBWPattern();
               fprintf(FP, "pat%1d %s\n", Fill, patternStr);
            }
         }
         else
         {
            DumpPolyPath (FP, ObjPtr, Vs, NumPts, Smooth, LS_PLAIN, Width,
                  ArrowWidth, ArrowHeight, (-1), BACKPAT, Curved, Dash, Indent);
         }
      }
   }
   for (i=0; i < Indent+3; i++) fprintf (FP, " ");
   fprintf (FP, "newpath\n");
   for (i=0; i < Indent+3; i++) fprintf (FP, " ");
   fprintf (FP, "   %1d %1d moveto\n", Vs[0].x, Vs[0].y);
   if (Style & LS_LEFT)
   {
      dx = Vs[1].x - Vs[0].x;
      dy = Vs[1].y - Vs[0].y;
      if (dx != 0 || dy != 0)
      {
         if (!retracted_arrow) {
            for (i=0; i < Indent+6; i++) fprintf (FP, " ");
            fprintf (FP, "%1d %1d atan dup cos %1d mul exch sin %1d %s\n",
                  dy, dx, aw, aw, "mul rmoveto");
         }
      }
   }
   if (Style & LS_RIGHT)
   {
      if (Curved == LT_INTSPLINE)
         DumpCurvedPolyPoints (FP, NumPts, Vs, Indent+6);
      else
         DumpMultiCurvedPolyPoints (FP, Smooth, Style, Curved, NumPts, Vs,
               Indent+6);

      dx = Vs[NumPts-1].x - Vs[NumPts-2].x;
      dy = Vs[NumPts-1].y - Vs[NumPts-2].y;
      if (dx != 0 || dy != 0)
      {
         if (retracted_arrow) {
            for (i=0; i < Indent+6; i++) fprintf (FP, " ");
            fprintf (FP, "%1d %1d", Vs[NumPts-1].x, Vs[NumPts-1].y);
         } else {
            for (i=0; i < Indent+6; i++) fprintf (FP, " ");
            fprintf (FP, "%1d %1d atan dup cos %1d mul %1d exch sub\n",
                  dy, dx, aw, Vs[NumPts-1].x);
            for (i=0; i < Indent+6; i++) fprintf (FP, " ");
            fprintf (FP, "exch sin %1d mul %1d exch sub",
                  aw, Vs[NumPts-1].y);
         }
         switch (Curved)
         {
            case LT_STRAIGHT:
            case LT_SPLINE:
               if (NumPts <= 2 || (Smooth != NULL && !Smooth[NumPts-2]))
                  fprintf (FP, " lineto");
               else
                  fprintf (FP, " curveto");
               break;
            case LT_INTSPLINE:
               if (NumPts <= 2)
                  fprintf (FP, " lineto");
               else
                  fprintf (FP, " curveto");
               break;
         }
      }
      fprintf (FP, "\n");
   }
   else if (Curved == LT_INTSPLINE)
   {
      DumpCurvedPolyPoints (FP, NumPts, Vs, Indent+6);
      if (NumPts <= 2)
      {
         for (i=0; i < Indent+6; i++) fprintf (FP, " ");
         fprintf (FP, "%1d %1d lineto\n",Vs[NumPts-1].x,Vs[NumPts-1].y);
      }
      else
      {
         for (i=0; i < Indent+6; i++) fprintf (FP, " ");
         fprintf (FP, "%1d %1d curveto\n",Vs[NumPts-1].x,Vs[NumPts-1].y);
      }
   }
   else
      DumpMultiCurvedPolyPoints (FP, Smooth, Style, Curved, NumPts, Vs,
            Indent+6);

   if (Fill == (-1) && Pen != (-1))
   {  /* dumping the pen */
      for (i=0; i < Indent+3; i++) fprintf (FP, " ");
      switch (Pen)
      {
         case SOLIDPAT: fprintf (FP, "stroke\n"); break;
         case BACKPAT: fprintf (FP, "1 setgray stroke\n"); break;
         default:
            if (colorDump)
            {
               if (preDumpSetup) PSUseColorPattern();
               fprintf (FP, "flattenpath strokepath clip newpath\n");
               for (i=0; i < Indent+3; i++) fprintf (FP, " ");
               DumpPatFill (FP, Pen, 8, ObjPtr->bbox, "");
            }
            else
            {
               GrayCheck (Pen);
               if (useGray)
                  fprintf (FP, "%s setgray\n", GrayStr(Pen));
               else
               {
                  if (preDumpSetup) PSUseBWPattern();
                  fprintf (FP, "pat%1d %s\n", Pen, patternStr);
               }
               for (i=0; i < Indent+3; i++) fprintf (FP, " ");
               fprintf (FP, "stroke\n");
            }
            break;
      }
      if (Dash != 0)
      {
         for (i=0; i < Indent+3; i++) fprintf (FP, " ");
         fprintf (FP, "[] 0 setdash\n");
      }
      if (Width != 1)
      {
         for (i=0; i < Indent+3; i++) fprintf (FP, " ");
         fprintf (FP, "1 setlinewidth\n");
      }
   }
   else if (Fill != (-1) && Pen == (-1))
   {  /* dumping the fill */
      for (i=0; i < Indent+3; i++) fprintf (FP, " ");
      switch (Fill)
      {
         case SOLIDPAT:
            fprintf (FP, "closepath eofill\n");
            break;
         case BACKPAT:
            fprintf (FP, "closepath 1 setgray eofill\n");
            for (i=0; i < Indent+3; i++) fprintf (FP, " ");
            if (colorDump)
               DumpRGBColorLine(FP, color_index, 0, TRUE);
            else
               fprintf (FP, "0 setgray\n");
            break;
         default:
            if (colorDump)
            {
               if (preDumpSetup) PSUseColorPattern();
               fprintf (FP, "closepath eoclip newpath\n");
               for (i=0; i < Indent+3; i++) fprintf (FP, " ");
               DumpPatFill (FP, Fill, 8, ObjPtr->bbox, "");
            }
            else
               fprintf (FP, "closepath eofill\n");
            for (i=0; i < Indent; i++) fprintf (FP, " ");
            fprintf (FP, "grestore\n");
            break;
      }
   }
}

void DumpPolyObj (FP, ObjPtr)
   FILE				* FP;
   register struct ObjRec	* ObjPtr;
{
   XPoint	* v, * intv;
   int		num_pts, fill, pen, width, curved, dash, color_index, style;
   int		aw, ah, rotation, intn, retracted_arrow;
   char		* smooth;

   fill = ObjPtr->detail.p->fill;
   width = ObjPtr->detail.p->width;
   aw = ObjPtr->detail.p->aw;
   ah = ObjPtr->detail.p->ah;
   pen = ObjPtr->detail.p->pen;
   style = ObjPtr->detail.p->style;
   curved = ObjPtr->detail.p->curved;
   dash = ObjPtr->detail.p->dash;
   rotation = ObjPtr->rotation;
   v = ObjPtr->detail.p->vlist;
   num_pts = ObjPtr->detail.p->n;
   smooth = ObjPtr->detail.p->smooth;
   intv = ObjPtr->detail.p->intvlist;
   intn = ObjPtr->detail.p->intn;

   if (fill == NONEPAT && pen == NONEPAT) return;

   fprintf (FP, "%% POLY/OPEN-SPLINE\n");
   color_index = ObjPtr->color;
   if (colorDump)
      DumpRGBColorLine(FP, color_index, 0, TRUE);
   else
      fprintf (FP, "0 setgray\n");

   if (fill != NONEPAT && num_pts > 2)
   {
      if (curved != LT_INTSPLINE)
         DumpPolyPath (FP, ObjPtr, v, num_pts, smooth, LS_PLAIN, width, aw, ah,
               (-1), fill, curved, dash, (fill > BACKPAT ? 0 : (-3)));
      else
         DumpPolyPath (FP, ObjPtr, intv, intn, smooth, LS_PLAIN, width, aw, ah,
               (-1), fill, curved, dash, (fill > BACKPAT ? 0 : (-3)));
   }

   if (pen == NONEPAT) { fprintf (FP, "\n"); return; }

   fprintf (FP, "gsave\n");

   if (colorDump && pen > BACKPAT)
   {
      if (curved != LT_INTSPLINE)
         DumpPolyPath (FP, ObjPtr, v, num_pts, smooth, style, width, aw, ah,
               BACKPAT, (-1), curved, 0, 0);
      else
         DumpPolyPath (FP, ObjPtr, intv, intn, smooth, style, width, aw, ah,
               BACKPAT, (-1), curved, 0, 0);
      if (colorDump)
         DumpRGBColorLine(FP, color_index, 3, TRUE);
   }
   if (curved != LT_INTSPLINE)
      DumpPolyPath (FP, ObjPtr, v, num_pts, smooth, style, width, aw, ah,
            pen, (-1), curved, dash, 0);
   else
      DumpPolyPath (FP, ObjPtr, intv, intn, smooth, style, width, aw, ah,
            pen, (-1), curved, dash, 0);

   fprintf (FP, "grestore\n");

   retracted_arrow = (RetractedArrowAttr(ObjPtr) ||
         AutoRetractedArrowAttr(ObjPtr, TRUE));

   if (curved != LT_INTSPLINE)
   {
      switch (style)
      {
         case LS_PLAIN: break;
         case LS_LEFT:
            if (retracted_arrow) {
               DumpArrow (FP, v[2], v[1], aw, ah, pen, color_index);
            } else {
               DumpArrow (FP, v[1], v[0], aw, ah, pen, color_index);
            }
            break;
         case LS_RIGHT:
            if (retracted_arrow) {
               DumpArrow (FP,v[num_pts-3],v[num_pts-2],aw,ah,pen,color_index);
            } else {
               DumpArrow (FP,v[num_pts-2],v[num_pts-1],aw,ah,pen,color_index);
            }
            break;
         case LS_DOUBLE:
            if (retracted_arrow) {
               DumpArrow (FP, v[2], v[1], aw, ah, pen, color_index);
               DumpArrow (FP,v[num_pts-3],v[num_pts-2],aw,ah,pen,color_index);
            } else {
               DumpArrow (FP, v[1], v[0], aw, ah, pen, color_index);
               DumpArrow (FP,v[num_pts-2],v[num_pts-1],aw,ah,pen,color_index);
            }
            break;
      }
   }
   else
   {
      switch (style)
      {
         case LS_PLAIN: break;
         case LS_LEFT:
            if (retracted_arrow) {
               DumpArrow (FP, intv[2], v[1], aw, ah, pen, color_index);
            } else {
               DumpArrow (FP, intv[1], intv[0], aw, ah, pen, color_index);
            }
            break;
         case LS_RIGHT:
            if (retracted_arrow) {
               DumpArrow (FP,intv[intn-3],v[num_pts-2],aw,ah,pen,color_index);
            } else {
               DumpArrow (FP,intv[intn-2],intv[intn-1],aw,ah,pen,color_index);
            }
            break;
         case LS_DOUBLE:
            if (retracted_arrow) {
               DumpArrow (FP, intv[2], v[1], aw, ah, pen, color_index);
               DumpArrow (FP,intv[intn-3],v[num_pts-2],aw,ah,pen,color_index);
            } else {
               DumpArrow (FP, intv[1], intv[0], aw, ah, pen, color_index);
               DumpArrow (FP,intv[intn-2],intv[intn-1],aw,ah,pen,color_index);
            }
            break;
      }
   }
   fprintf (FP, "\n");
}

void DrawPolyObj (Win, XOff, YOff, ObjPtr)
   Window		Win;
   int			XOff, YOff;
   struct ObjRec	* ObjPtr;
{
   register struct PolyRec	* poly_ptr = ObjPtr->detail.p;
   XPoint			* v, tmp_v[4];
   XPoint			v0, v1, vnminus2, vnminus1;
   int				pen, width, pixel, fill, n, dash;
   int				real_x_off, real_y_off;
   int				style, aw, ah, num_pts;
   int				left_dx, left_dy, right_dx, right_dy;
   int				retracted_arrow=FALSE;
   double			len, sin, cos;
   XGCValues			values;

   n = poly_ptr->n;
   fill = poly_ptr->fill;
   width = poly_ptr->width;
   aw = poly_ptr->aw;
   ah = poly_ptr->ah;
   pen = poly_ptr->pen;
   style = poly_ptr->style;
   dash = poly_ptr->dash;
   pixel = colorPixels[ObjPtr->color];

   if (fill == NONEPAT && pen == NONEPAT) return;

   real_x_off = (zoomedIn ? XOff : (XOff>>zoomScale)<<zoomScale);
   real_y_off = (zoomedIn ? YOff : (YOff>>zoomScale)<<zoomScale);

   v = poly_ptr->svlist;
   num_pts = poly_ptr->sn;

   v[num_pts].x = v[0].x; v[num_pts].y = v[0].y;

   if (fill != NONEPAT)
   {
      values.foreground = (fill == BACKPAT) ? myBgPixel : pixel;
      values.function = GXcopy;
      values.fill_style = FillOpaqueStippled;
      values.stipple = patPixmap[fill];
      XChangeGC (mainDisplay, drawGC,
            GCForeground | GCFunction | GCFillStyle | GCStipple, &values);
      XFillPolygon (mainDisplay, Win, drawGC, v, num_pts+1, Complex,
            CoordModeOrigin);
   }

   if (pen == NONEPAT) return;

   retracted_arrow = (RetractedArrowAttr(ObjPtr) ||
         AutoRetractedArrowAttr(ObjPtr, TRUE));

   if (poly_ptr->curved != LT_INTSPLINE)
   {
      if (retracted_arrow) {
         v0.x = ZOOMED_SIZE(poly_ptr->vlist[1].x-real_x_off);
         v0.y = ZOOMED_SIZE(poly_ptr->vlist[1].y-real_y_off);
         v1.x = ZOOMED_SIZE(poly_ptr->vlist[2].x-real_x_off);
         v1.y = ZOOMED_SIZE(poly_ptr->vlist[2].y-real_y_off);
         vnminus2.x = ZOOMED_SIZE(poly_ptr->vlist[n-3].x-real_x_off);
         vnminus2.y = ZOOMED_SIZE(poly_ptr->vlist[n-3].y-real_y_off);
         vnminus1.x = ZOOMED_SIZE(poly_ptr->vlist[n-2].x-real_x_off);
         vnminus1.y = ZOOMED_SIZE(poly_ptr->vlist[n-2].y-real_y_off);
      } else {
         v0.x = ZOOMED_SIZE(poly_ptr->vlist[0].x-real_x_off);
         v0.y = ZOOMED_SIZE(poly_ptr->vlist[0].y-real_y_off);
         v1.x = ZOOMED_SIZE(poly_ptr->vlist[1].x-real_x_off);
         v1.y = ZOOMED_SIZE(poly_ptr->vlist[1].y-real_y_off);
         vnminus2.x = ZOOMED_SIZE(poly_ptr->vlist[n-2].x-real_x_off);
         vnminus2.y = ZOOMED_SIZE(poly_ptr->vlist[n-2].y-real_y_off);
         vnminus1.x = ZOOMED_SIZE(poly_ptr->vlist[n-1].x-real_x_off);
         vnminus1.y = ZOOMED_SIZE(poly_ptr->vlist[n-1].y-real_y_off);
      }
   }
   else
   {
      int	intn=poly_ptr->intn;
      XPoint	* intvlist=poly_ptr->intvlist;

      if (retracted_arrow) {
         int n=poly_ptr->n;
         XPoint *v=poly_ptr->vlist;

         v0.x = ZOOMED_SIZE(v[1].x-real_x_off);
         v0.y = ZOOMED_SIZE(v[1].y-real_y_off);
         v1.x = ZOOMED_SIZE(intvlist[2].x-real_x_off);
         v1.y = ZOOMED_SIZE(intvlist[2].y-real_y_off);
         vnminus2.x = ZOOMED_SIZE(intvlist[intn-3].x-real_x_off);
         vnminus2.y = ZOOMED_SIZE(intvlist[intn-3].y-real_y_off);
         vnminus1.x = ZOOMED_SIZE(v[n-2].x-real_x_off);
         vnminus1.y = ZOOMED_SIZE(v[n-2].y-real_y_off);
      } else {
         v0.x = ZOOMED_SIZE(intvlist[0].x-real_x_off);
         v0.y = ZOOMED_SIZE(intvlist[0].y-real_y_off);
         v1.x = ZOOMED_SIZE(intvlist[1].x-real_x_off);
         v1.y = ZOOMED_SIZE(intvlist[1].y-real_y_off);
         vnminus2.x = ZOOMED_SIZE(intvlist[intn-2].x-real_x_off);
         vnminus2.y = ZOOMED_SIZE(intvlist[intn-2].y-real_y_off);
         vnminus1.x = ZOOMED_SIZE(intvlist[intn-1].x-real_x_off);
         vnminus1.y = ZOOMED_SIZE(intvlist[intn-1].y-real_y_off);
      }
   }

   aw = ZOOMED_SIZE(aw); if (aw == 0) aw = 1;
   ah = ZOOMED_SIZE(ah); if (ah == 0) ah = 1;

   values.foreground = (pen == BACKPAT) ? myBgPixel : pixel;
   values.function = GXcopy;
   values.fill_style = FillOpaqueStippled;
   values.stipple = patPixmap[pen];
   values.line_width = ZOOMED_SIZE(width);
#ifdef NO_THIN_LINE
   if (values.line_width < 1) values.line_width = 1;
#endif
   values.join_style = JoinBevel;
   if (dash != 0)
   {
      XSetDashes (mainDisplay, drawGC, 0, dashList[dash],
            dashListLength[dash]);
      values.line_style = LineOnOffDash;
   }
   else
      values.line_style = LineSolid;
   XChangeGC (mainDisplay, drawGC,
         GCForeground | GCFunction | GCFillStyle | GCStipple | GCLineWidth |
         GCLineStyle | GCJoinStyle, &values);

   left_dx = v1.x - v0.x;
   left_dy = v1.y - v0.y;

   if ((style & LS_LEFT) && (left_dx != 0 || left_dy != 0))
   {  /* adjust the first point */
      len = (double)sqrt((double)(((double)left_dx)*((double)left_dx) +
            ((double)left_dy)*((double)left_dy)));
      sin = ((double)left_dy)/len;
      cos = ((double)left_dx)/len;

      tmp_v[0].x = tmp_v[3].x = v0.x;
      tmp_v[0].y = tmp_v[3].y = v0.y;
      tmp_v[1].x = round(v0.x + aw*cos - ah*sin);
      tmp_v[1].y = round(v0.y + aw*sin + ah*cos);
      tmp_v[2].x = round(v0.x + aw*cos + ah*sin);
      tmp_v[2].y = round(v0.y + aw*sin - ah*cos);

      XFillPolygon (mainDisplay, Win, drawGC, tmp_v, 4, Convex,
            CoordModeOrigin);
   }

   right_dx = vnminus1.x - vnminus2.x;
   right_dy = vnminus1.y - vnminus2.y;

   if ((style & LS_RIGHT) && (right_dx != 0 || right_dy != 0))
   {  /* adjust the last point */
      len = (double)sqrt((double)(((double)right_dx)*((double)right_dx) +
            ((double)right_dy)*((double)right_dy)));
      sin = ((double)right_dy)/len;
      cos = ((double)right_dx)/len;

      tmp_v[0].x = tmp_v[3].x = vnminus1.x;
      tmp_v[0].y = tmp_v[3].y = vnminus1.y;
      tmp_v[1].x = round(vnminus1.x - aw*cos + ah*sin);
      tmp_v[1].y = round(vnminus1.y - aw*sin - ah*cos);
      tmp_v[2].x = round(vnminus1.x - aw*cos - ah*sin);
      tmp_v[2].y = round(vnminus1.y - aw*sin + ah*cos);

      XFillPolygon (mainDisplay, Win, drawGC, tmp_v, 4, Convex,
            CoordModeOrigin);
   }

   if (style != LS_PLAIN)
   {
#ifdef HP_LINE_BUG
      if (poly_ptr->asn == 2)
      {
         XPoint hp_sv[3];

         hp_sv[0].x=poly_ptr->asvlist[0].x; hp_sv[0].y=poly_ptr->asvlist[0].y;
         hp_sv[1].x=poly_ptr->asvlist[0].x; hp_sv[1].y=poly_ptr->asvlist[0].y;
         hp_sv[2].x=poly_ptr->asvlist[1].x; hp_sv[2].y=poly_ptr->asvlist[1].y;
         XDrawLines (mainDisplay, Win, drawGC, hp_sv, 3, CoordModeOrigin);
      }
      else
         XDrawLines (mainDisplay, Win, drawGC, poly_ptr->asvlist, poly_ptr->asn,
               CoordModeOrigin);
#else
      XDrawLines (mainDisplay, Win, drawGC, poly_ptr->asvlist, poly_ptr->asn,
            CoordModeOrigin);
#endif
   }
   else
   {
#ifdef HP_LINE_BUG
      if (num_pts == 2)
      {
         XPoint hp_sv[3];

         hp_sv[0].x = v[0].x; hp_sv[0].y = v[0].y;
         hp_sv[1].x = v[0].x; hp_sv[1].y = v[0].y;
         hp_sv[2].x = v[1].x; hp_sv[2].y = v[1].y;
         XDrawLines (mainDisplay, Win, drawGC, hp_sv, 3, CoordModeOrigin);
      }
      else
         XDrawLines (mainDisplay, Win, drawGC, v, num_pts, CoordModeOrigin);
#else
      XDrawLines (mainDisplay, Win, drawGC, v, num_pts, CoordModeOrigin);
#endif
   }
}

static char	hexValue[] = "0123456789abcdef";

void SaveSmoothHinge (FP, Curved, NumPts, Smooth)
   FILE	* FP;
   int	Curved, NumPts;
   char	* Smooth;
{
   register int	nibble_count=0, bit_count=0, data=0, j;

   if (Curved == LT_INTSPLINE || Smooth == NULL) return;

   for (j = 0; j < NumPts; j++)
   {
      data = (Smooth[j] ? (data<<1) | 1 : (data<<1));

      if (++bit_count == 4)
      {
         if (nibble_count++ == 64)
         {
            nibble_count = 1;
            if (fprintf (FP, "\n     ") == EOF) writeFileFailed = TRUE;
         }
         if (fprintf (FP, "%c", hexValue[data]) == EOF)
            writeFileFailed = TRUE;
         bit_count = 0;
         data = 0;
      }
   }
   if ((NumPts & 0x3) != 0)
   {
      data <<= (4 - (NumPts & 0x3));
      if (nibble_count++ == 64)
      {
         nibble_count = 1;
         if (fprintf (FP, "\n     ") == EOF) writeFileFailed = TRUE;
      }
      if (fprintf (FP, "%c", hexValue[data]) == EOF) writeFileFailed = TRUE;
   }
}

void SavePolyObj (FP, ObjPtr)
   FILE			* FP;
   struct ObjRec	* ObjPtr;
{
   register int		i, n;
   int			count;
   struct PolyRec	* poly_ptr = ObjPtr->detail.p;

   n = poly_ptr->n;
   if (fprintf (FP, "poly('%s',%1d,[\n\t",
         colorMenuItems[ObjPtr->color], poly_ptr->n) == EOF)
      writeFileFailed = TRUE;
   for (i = 0, count = 0; i < n-1; i++)
   {
      if (fprintf (FP, "%1d,%1d,", poly_ptr->vlist[i].x,
            poly_ptr->vlist[i].y) == EOF)
         writeFileFailed = TRUE;
      if (++count == 8)
      {
         count = 0;
         if (fprintf (FP, "\n\t") == EOF) writeFileFailed = TRUE;
      }
   }
   if (fprintf (FP, "%1d,%1d],", poly_ptr->vlist[n-1].x,
         poly_ptr->vlist[n-1].y) == EOF)
      writeFileFailed = TRUE;

   if (fprintf (FP, "%1d,%1d,%1d,%1d,%1d,%1d,%1d,%1d,%1d,%1d,%1d,",
         poly_ptr->style, poly_ptr->width, poly_ptr->pen, ObjPtr->id,
         poly_ptr->curved, poly_ptr->fill, poly_ptr->dash, ObjPtr->rotation,
         poly_ptr->aw, poly_ptr->ah, ObjPtr->locked) == EOF)
      writeFileFailed = TRUE;
   if (fprintf (FP, "\n    \"") == EOF) writeFileFailed = TRUE;
   SaveSmoothHinge (FP, poly_ptr->curved, poly_ptr->n, poly_ptr->smooth);
   if (fprintf (FP, "\",") == EOF) writeFileFailed = TRUE;
   SaveAttrs (FP, ObjPtr->lattr);
   if (fprintf (FP, ")") == EOF) writeFileFailed = TRUE;
}

int ReadSmoothHinge (FP, Curved, NumPts, Smooth)
   FILE	* FP;
   int	Curved, NumPts;
   char	* Smooth;
{
   int	num_nibbles=NumPts>>2, nibble_count=0, bit_count=0, j, k;
   char	* c_ptr, inbuf[MAXSTRING+1], msg[MAXSTRING];

   if ((NumPts & 0x3) != 0) num_nibbles++;
   fgets (inbuf, MAXSTRING, FP);
   scanLineNum++;
   if (Curved == LT_INTSPLINE || Smooth == NULL) return (TRUE);
   if ((c_ptr = strchr (inbuf, '"')) == NULL)
   {
      (void) sprintf (msg, "%s, %d:  Invalid smooth/hinge spec for a poly.",
            scanFileName, scanLineNum);
      if (PRTGIF)
         fprintf (stderr, "%s\n", msg);
      else
         Msg (msg);
      return (FALSE);
   }
   c_ptr++;
   for (j = 0; j < num_nibbles; j++)
   {
      int	data=0;

      if (nibble_count++ == 64)
      {
         fgets (inbuf, MAXSTRING, FP);
         scanLineNum++;
         for (c_ptr=inbuf; *c_ptr == ' '; c_ptr++) ;
         nibble_count = 1;
      }
      if (*c_ptr >= '0' && *c_ptr <= '9')
         data = (int)(*c_ptr++) - (int)('0');
      else if (*c_ptr >= 'a' && *c_ptr <= 'f')
         data = (int)(*c_ptr++) - (int)('a') + 10;
      for (k = 0; k < 4; k++)
      {
         if (bit_count++ == NumPts) break;

         Smooth[(j<<2)+k] = (data & (1<<(3-k)) ? TRUE : FALSE);
      }
   }
   return (TRUE);
}

#define GETVALUE(val,name) ScanValue("%d", &(val), name, "poly")

void ReadPolyObj (FP, Inbuf, ObjPtr)
   FILE			* FP;
   char			* Inbuf;
   struct ObjRec	* * ObjPtr;
{
   register int		i;
   struct PolyRec	* poly_ptr;
   XPoint		* v;
   char			color_str[40], * s, inbuf[MAXSTRING+1], msg[MAXSTRING];
   int			num_pts, ltx=0, lty=0, rbx=0, rby=0, x, y, id=0;
   int			initialized, rotation, count, new_alloc;
   int			style, width=0, pen, curved, fill, dash, locked=FALSE;
   int			aw=origArrowHeadW[6], ah=origArrowHeadH[6];
   char			* smooth=NULL;

   *ObjPtr = NULL;

   s = FindChar ((int)'(', Inbuf);
   s = ParseStr (s, (int)',', color_str, sizeof(color_str));

   InitScan (s, "\t\n, []");

   if (GETVALUE (num_pts, "number of points") == INVALID)
      return;

   if (num_pts <= 0)
   {
      (void) sprintf (msg, "%s, %d:  Invalid number of points in poly",
            scanFileName, scanLineNum);
      if (PRTGIF)
         fprintf (stderr, "%s\n", msg);
      else
         Msg (msg);
      return;
   }

   * ObjPtr = (struct ObjRec *) calloc (1, sizeof(struct ObjRec));
   poly_ptr = (struct PolyRec *) calloc (1, sizeof(struct PolyRec));

   if (num_pts == 1)
   {
      v = (XPoint *) calloc (4, sizeof(XPoint));
      if (v == NULL) FailAllocMessage ();
      smooth = (char *) calloc (4, sizeof(char));
      if (smooth == NULL) FailAllocMessage ();
   }
   else
   {
      v = (XPoint *) calloc (num_pts+1, sizeof(XPoint));
      if (v == NULL) FailAllocMessage ();
      smooth = (char *) calloc (num_pts+1, sizeof(char));
      if (smooth == NULL) FailAllocMessage ();
   }

   initialized = FALSE;

   if (fileVersion <= 13)
   {
      for (i = 0; i < num_pts; i++)
      {
         if (GETVALUE (x, "x") == INVALID || GETVALUE (y, "y") == INVALID)
         {
            cfree (*ObjPtr);
            cfree (poly_ptr);
            cfree (v);
            *ObjPtr = NULL;
            return;
         }
         v[i].x = x; v[i].y = y;
         if (!initialized)
         {
            initialized = TRUE;
            ltx = rbx = x; lty = rby = y;
         }
         else
         {
            if (x < ltx) ltx = x; if (y < lty) lty = y;
            if (x > rbx) rbx = x; if (y > rby) rby = y;
         }
      }
   }
   else
   {
      fgets (inbuf, MAXSTRING, FP);
      scanLineNum++;
      s = inbuf;
      InitScan (s, "\t\n, []");
      for (i = 0, count = 0; i < num_pts; i++)
      {
         if (GETVALUE (x, "x") == INVALID || GETVALUE (y, "y") == INVALID)
         {
            cfree (*ObjPtr);
            cfree (poly_ptr);
            cfree (v);
            *ObjPtr = NULL;
            return;
         }
         v[i].x = x; v[i].y = y;
         if (!initialized)
         {
            initialized = TRUE;
            ltx = rbx = x; lty = rby = y;
         }
         else
         {
            if (x < ltx) ltx = x; if (y < lty) lty = y;
            if (x > rbx) rbx = x; if (y > rby) rby = y;
         }
         if (++count == 8 && i != num_pts-1)
         {
            count = 0;
            fgets (inbuf, MAXSTRING, FP);
            scanLineNum++;
            s = inbuf;
            InitScan (s, "\t\n, []");
         }
      }
   }

   if (num_pts == 1)
   {
      sprintf (msg, "%s (%1d,%1d) converted to double point poly.",
            "Single point poly", v[0].x, v[0].y);
      if (PRTGIF)
         fprintf (stderr, "%s\n", msg);
      else
         Msg (msg);
      v[1].x = v[0].x;
      v[1].y = v[0].y;
      num_pts = 2;
   }

   poly_ptr->n = num_pts;

   dash = 0;
   rotation = 0;
   if (fileVersion == INVALID)
   {
      if (GETVALUE (style,    "style") == INVALID ||
          GETVALUE (width,    "width") == INVALID ||
          GETVALUE (pen,      "pen") == INVALID)
      {
         cfree (*ObjPtr);
         cfree (poly_ptr);
         cfree (v);
         *ObjPtr = NULL;
         return;
      }
      id = objId++;
      fill = NONEPAT;
      if (width == LINE_CURVED)
      {
         width = 0;
         curved = TRUE;
      }
      else
         curved = FALSE;
      switch (width)
      {
         case 1: width = 3; break;
         case 2: width = 6; break;
      }
   }
   else if (fileVersion <= 3)
   {
      if (GETVALUE (style,    "style") == INVALID ||
          GETVALUE (width,    "width") == INVALID ||
          GETVALUE (pen,      "pen") == INVALID ||
          GETVALUE (id,       "id") == INVALID)
      {
         cfree (*ObjPtr);
         cfree (poly_ptr);
         cfree (v);
         *ObjPtr = NULL;
         return;
      }
      if (id >= objId) objId = id+1;
      fill = NONEPAT;
      if (width == LINE_CURVED)
      {
         width = 0;
         curved = TRUE;
      }
      else
         curved = FALSE;
      switch (width)
      {
         case 1: width = 3; break;
         case 2: width = 6; break;
      }
   }
   else if (fileVersion <= 4)
   {
      if (GETVALUE (style,    "style") == INVALID ||
          GETVALUE (width,    "width") == INVALID ||
          GETVALUE (pen,      "pen") == INVALID ||
          GETVALUE (id,       "id") == INVALID ||
          GETVALUE (curved,   "curved") == INVALID)
      {
         cfree (*ObjPtr);
         cfree (poly_ptr);
         cfree (v);
         *ObjPtr = NULL;
         return;
      }
      if (id >= objId) objId = id+1;
      fill = NONEPAT;
      switch (width)
      {
         case 1: width = 3; break;
         case 2: width = 6; break;
      }
   }
   else if (fileVersion <= 5)
   {
      if (GETVALUE (style,    "style") == INVALID ||
          GETVALUE (width,    "width") == INVALID ||
          GETVALUE (pen,      "pen") == INVALID ||
          GETVALUE (id,       "id") == INVALID ||
          GETVALUE (curved,   "curved") == INVALID ||
          GETVALUE (fill,     "fill") == INVALID)
      {
         cfree (*ObjPtr);
         cfree (poly_ptr);
         cfree (v);
         *ObjPtr = NULL;
         return;
      }
      if (id >= objId) objId = id+1;
      switch (width)
      {
         case 1: width = 3; break;
         case 2: width = 6; break;
      }
   }
   else if (fileVersion <= 8)
   {
      if (GETVALUE (style,    "style") == INVALID ||
          GETVALUE (width,    "width") == INVALID ||
          GETVALUE (pen,      "pen") == INVALID ||
          GETVALUE (id,       "id") == INVALID ||
          GETVALUE (curved,   "curved") == INVALID ||
          GETVALUE (fill,     "fill") == INVALID)
      {
         cfree (*ObjPtr);
         cfree (poly_ptr);
         cfree (v);
         *ObjPtr = NULL;
         return;
      }
      if (id >= objId) objId = id+1;
   }
   else if (fileVersion <= 13)
   {
      if (GETVALUE (style,    "style") == INVALID ||
          GETVALUE (width,    "width") == INVALID ||
          GETVALUE (pen,      "pen") == INVALID ||
          GETVALUE (id,       "id") == INVALID ||
          GETVALUE (curved,   "curved") == INVALID ||
          GETVALUE (fill,     "fill") == INVALID ||
          GETVALUE (dash,     "dash") == INVALID)
      {
         cfree (*ObjPtr);
         cfree (poly_ptr);
         cfree (v);
         *ObjPtr = NULL;
         return;
      }
      if (id >= objId) objId = id+1;
   }
   else if (fileVersion <= 16)
   {
      if (GETVALUE (style,    "style") == INVALID ||
          GETVALUE (width,    "width") == INVALID ||
          GETVALUE (pen,      "pen") == INVALID ||
          GETVALUE (id,       "id") == INVALID ||
          GETVALUE (curved,   "curved") == INVALID ||
          GETVALUE (fill,     "fill") == INVALID ||
          GETVALUE (dash,     "dash") == INVALID ||
          GETVALUE (rotation, "rotation") == INVALID)
      {
         cfree (*ObjPtr);
         cfree (poly_ptr);
         cfree (v);
         *ObjPtr = NULL;
         return;
      }
      if (id >= objId) objId = id+1;
   }
   else if (fileVersion <= 25)
   {
      if (GETVALUE (style,    "style") == INVALID ||
          GETVALUE (width,    "width") == INVALID ||
          GETVALUE (pen,      "pen") == INVALID ||
          GETVALUE (id,       "id") == INVALID ||
          GETVALUE (curved,   "curved") == INVALID ||
          GETVALUE (fill,     "fill") == INVALID ||
          GETVALUE (dash,     "dash") == INVALID ||
          GETVALUE (rotation, "rotation") == INVALID ||
          GETVALUE (aw,       "arrow head width") == INVALID ||
          GETVALUE (ah,       "arrow head height") == INVALID)
      {
         cfree (*ObjPtr);
         cfree (poly_ptr);
         cfree (v);
         *ObjPtr = NULL;
         return;
      }
      if (id >= objId) objId = id+1;
   }
   else
   {
      if (GETVALUE (style,    "style") == INVALID ||
          GETVALUE (width,    "width") == INVALID ||
          GETVALUE (pen,      "pen") == INVALID ||
          GETVALUE (id,       "id") == INVALID ||
          GETVALUE (curved,   "curved") == INVALID ||
          GETVALUE (fill,     "fill") == INVALID ||
          GETVALUE (dash,     "dash") == INVALID ||
          GETVALUE (rotation, "rotation") == INVALID ||
          GETVALUE (aw,       "arrow head width") == INVALID ||
          GETVALUE (ah,       "arrow head height") == INVALID ||
          GETVALUE (locked,   "locked") == INVALID)
      {
         cfree (*ObjPtr);
         cfree (poly_ptr);
         cfree (v);
         *ObjPtr = NULL;
         return;
      }
      if (id >= objId) objId = id+1;
   }

   if (fileVersion <= 16 && width <= 6)
   {
      aw = origArrowHeadW[width];
      ah = origArrowHeadH[width];
      width = origWidthOfLine[width];
   }
   if (curved == LT_INTSPLINE && smooth != NULL)
   {
      cfree (smooth);
      smooth = NULL;
   }
   if (fileVersion <= 30)
   {
      switch (curved)
      {
         case LT_STRAIGHT:
            for (i=0; i < num_pts; i++) smooth[i] = FALSE;
            break;
         case LT_SPLINE:
            smooth[0] = smooth[num_pts-1] = FALSE;
            for (i=1; i < num_pts-1; i++) smooth[i] = TRUE;
            break;
      }
   }
   else if (!ReadSmoothHinge (FP, curved, num_pts, smooth))
      return;

   fill = UpgradePenFill (fill);
   pen = UpgradePenFill (pen);

   poly_ptr->style = style;
   poly_ptr->width = width;
   poly_ptr->aw = aw;
   poly_ptr->ah = ah;
   poly_ptr->pen = pen;
   poly_ptr->curved = curved;
   poly_ptr->fill = fill;
   poly_ptr->dash = dash;

   poly_ptr->vlist = v;
   poly_ptr->smooth = smooth;
   poly_ptr->svlist = poly_ptr->asvlist = poly_ptr->intvlist = NULL;

   (*ObjPtr)->x = ltx;
   (*ObjPtr)->y = lty;
   (*ObjPtr)->color = QuickFindColorIndex (color_str, &new_alloc, TRUE);
   (*ObjPtr)->dirty = FALSE;
   (*ObjPtr)->id = id;
   (*ObjPtr)->rotation = rotation;
   (*ObjPtr)->locked = locked;
   (*ObjPtr)->type = OBJ_POLY;
   (*ObjPtr)->obbox.ltx = ltx;
   (*ObjPtr)->obbox.lty = lty;
   (*ObjPtr)->obbox.rbx = rbx;
   (*ObjPtr)->obbox.rby = rby;
   (*ObjPtr)->detail.p = poly_ptr;
   AdjObjSplineVs (*ObjPtr);
   if (poly_ptr->curved != LT_INTSPLINE)
      UpdPolyBBox (*ObjPtr, poly_ptr->n, poly_ptr->vlist);
   else
      UpdPolyBBox (*ObjPtr, poly_ptr->intn, poly_ptr->intvlist);
}

void FreePolyObj (ObjPtr)
   struct ObjRec	* ObjPtr;
{
   if (ObjPtr->detail.p->svlist != NULL) cfree (ObjPtr->detail.p->svlist);
   if (ObjPtr->detail.p->asvlist != NULL) cfree (ObjPtr->detail.p->asvlist);
   if (ObjPtr->detail.p->intvlist != NULL) cfree (ObjPtr->detail.p->intvlist);
   cfree (ObjPtr->detail.p->vlist);
   if (ObjPtr->detail.p->smooth != NULL) cfree (ObjPtr->detail.p->smooth);
   cfree (ObjPtr->detail.p);
   cfree (ObjPtr);
}
