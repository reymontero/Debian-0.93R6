/* Hand edited by M. Weller by from an original XPM file */
#define fish_monster_w	33
#define fish_monster_h	33
/* width height ncolors chars_per_pixel */
static unsigned char fish_monster233[] = { 0x00, 0xf1, 0xf4, 0x07, 0xff, 0xc0 };
static unsigned short fish_monster555[] = { 0x0000, 0x125f, 0x431c, 0x7c00, 0x7fff, 0x001f};
static unsigned short fish_monster565[] = { 0x0000, 0x249f, 0x861c, 0xf800, 0xffff, 0x001f};
static unsigned int fish_monster888[] = {
	 0x00000000,
	 0x002900ff,
	 0x0080e0e0,
	 0x00ff0000,
	 0x00ffffff,
	 0x000000ff };

/* pixels */
static char *fish_monster =
"dddddddddddd```dddddd``ddddddd``d"
"ddddddddddd`eee``dddd`e``ddd``e`d"
"ddddddd``````aaee`ddd`e`e```e`e`d"
"ddddd```bbbbb```ee`dd`aae`e`eab`d"
"dddd`ddd`bb```bb``e`dd``aaeaa``dd"
"ddd`dd```b`dd``bbb``dddd`bbb`dddd"
"dd``dd```b`d```bbbb`ddddd`b`ddddd"
"dd`b````bbb```bbbbbb`dddd`b`ddddd"
"d`bbbbbbbbbbbbbbbbbbb`dd`bb`ddddd"
"d`````bbb````bbbbbbbbb``bbbb`dddd"
"`ccccc```cccc``bbbbbbbbbbbbb`dddd"
"`cccccccccccccc`bbbbbbbbbbbb`dddd"
"d````ccccc````cc`bbbbbbbbbbbb`ddd"
"d`d`d`````d`d``cc`bbbbbbbbbbb`ddd"
"d`d`d`d`d`d`d```c`bbbbb``bbbb`ddd"
"dd`d``d`d```````cc`bbbbba`bbb`ddd"
"dddddd```````````c`bbbb`ae`bb`ddd"
"dddddd```````````c`bbbba`e`bb`ddd"
"ddd`dd```````````c`bbb`ae``b`dddd"
"dd`d`````````````c`b`aa`ee`b`dddd"
"dd`d`d`d`````d``cc`bb`ee``bb`dddd"
"d````d`d`d`d`d`cc`bbbb```bb`ddddd"
"`ccc`````d`d``ccc`bbbbbbbbb`ddddd"
"`cccccccc```cccc`bbbbbbbbbb`ddddd"
"d```ccccccccccc`bbbbbbbbbb`dddddd"
"dd`b````ccccc``bbbbbbbbbbb`dddddd"
"dd`bbbbb`````bbbbbbbbbbbb`ddddddd"
"ddd`bbbbbbbbbbbbbbbbbbbb`dddddddd"
"dddd`bbbbbbbbbbbbbbbbb``ddddddddd"
"ddddd``bbbbbbbbbbbbb``ddddddddddd"
"ddddddd```bbbbbbb```ddddddddddddd"
"dddddddddd```````dddddddddddddddd"
"ddddddddddddddddddddddddddddddddd" ;
