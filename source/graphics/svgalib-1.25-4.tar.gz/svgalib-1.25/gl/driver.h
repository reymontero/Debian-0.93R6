
int driver8_setpixel(int, int, int);
int driver8_getpixel(int, int);
int driver8_hline(int, int, int, int);
int driver8_fillbox(int, int, int, int, int);
int driver8_putbox(int, int, int, int, void *, int);
int driver8_getbox(int, int, int, int, void *, int);
int driver8_putboxmask(int, int, int, int, void *);
int driver8_putboxpart(int, int, int, int, int, int, void *, int, int);
int driver8_getboxpart(int, int, int, int, int, int, void *, int, int);
int driver8_copybox(int, int, int, int, int, int);

int driver16_setpixel(int, int, int);
int driver16_getpixel(int, int);
int driver16_hline(int, int, int, int);
int driver16_fillbox(int, int, int, int, int);
int driver16_putbox(int, int, int, int, void *, int);
int driver16_getbox(int, int, int, int, void *, int);
int driver16_putboxmask(int, int, int, int, void *);
int driver16_putboxpart(int, int, int, int, int, int, void *, int, int);
int driver16_getboxpart(int, int, int, int, int, int, void *, int, int);
int driver16_copybox(int, int, int, int, int, int);

int driver24_setpixel(int, int, int);
int driver24_getpixel(int, int);
int driver24_hline(int, int, int, int);
int driver24_fillbox(int, int, int, int, int);
int driver24_putbox(int, int, int, int, void *, int);
int driver24_getbox(int, int, int, int, void *, int);
int driver24_putboxmask(int, int, int, int, void *);
int driver24_putboxpart(int, int, int, int, int, int, void *, int, int);
int driver24_getboxpart(int, int, int, int, int, int, void *, int, int);
int driver24_copybox(int, int, int, int, int, int);
int driver24_putbox32(int, int, int, int, void *, int);

int driver32_setpixel(int, int, int);
int driver32_getpixel(int, int);
int driver32_hline(int, int, int, int);
int driver32_fillbox(int, int, int, int, int);
int driver32_putbox(int, int, int, int, void *, int);
int driver32_getbox(int, int, int, int, void *, int);
int driver32_putboxmask(int, int, int, int, void *);
int driver32_putboxpart(int, int, int, int, int, int, void *, int, int);
int driver32_getboxpart(int, int, int, int, int, int, void *, int, int);
int driver32_copybox(int, int, int, int, int, int);

int driver8p_setpixel(int, int, int);
int driver8p_getpixel(int, int);
int driver8p_hline(int, int, int, int);
int driver8p_fillbox(int, int, int, int, int);
int driver8p_putbox(int, int, int, int, void *, int);
int driver8p_getbox(int, int, int, int, void *, int);
int driver8p_putboxmask(int, int, int, int, void *);
int driver8p_putboxpart(int, int, int, int, int, int, void *, int, int);
int driver8p_getboxpart(int, int, int, int, int, int, void *, int, int);
int driver8p_copybox(int, int, int, int, int, int);

int driver16p_setpixel(int, int, int);
int driver16p_getpixel(int, int);
int driver16p_hline(int, int, int, int);
int driver16p_fillbox(int, int, int, int, int);
int driver16p_putbox(int, int, int, int, void *, int);
int driver16p_getbox(int, int, int, int, void *, int);
int driver16p_putboxmask(int, int, int, int, void *);
int driver16p_putboxpart(int, int, int, int, int, int, void *, int, int);
int driver16p_getboxpart(int, int, int, int, int, int, void *, int, int);
int driver16p_copybox(int, int, int, int, int, int);

int driver24p_setpixel(int, int, int);
int driver24p_getpixel(int, int);
int driver24p_hline(int, int, int, int);
int driver24p_fillbox(int, int, int, int, int);
int driver24p_putbox(int, int, int, int, void *, int);
int driver24p_getbox(int, int, int, int, void *, int);
int driver24p_putboxmask(int, int, int, int, void *);
int driver24p_putboxpart(int, int, int, int, int, int, void *, int, int);
int driver24p_getboxpart(int, int, int, int, int, int, void *, int, int);
int driver24p_copybox(int, int, int, int, int, int);

int driver32p_setpixel(int, int, int);
int driver32p_getpixel(int, int);
int driver32p_hline(int, int, int, int);
int driver32p_fillbox(int, int, int, int, int);
int driver32p_putbox(int, int, int, int, void *, int);
int driver32p_getbox(int, int, int, int, void *, int);
int driver32p_putboxmask(int, int, int, int, void *);
int driver32p_putboxpart(int, int, int, int, int, int, void *, int, int);
int driver32p_getboxpart(int, int, int, int, int, int, void *, int, int);
int driver32p_copybox(int, int, int, int, int, int);

int driver8a_fillbox(int, int, int, int, int);
int driver8a_copybox(int, int, int, int, int, int);

int driverplanar256_nothing();
int driverplanar256_putbox();

int driverplanar16_nothing();

/* Generic functions */

int driver_setread( GraphicsContext *gc, int i, void **vp );
int driver_setwrite( GraphicsContext *gc, int i, void **vp );
