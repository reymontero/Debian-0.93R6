/* $Id: patchlevel.h,v 1.10 1994/06/09 01:51:10 paulus Exp $ */
#define	PATCHLEVEL	2

#define VERSION	"2.1"
#define DATE	"9 June 94"
