/*
 * filter.c - Packet filtering for diald.
 *
 * Copyright (c) 1994, 1995 Eric Schenk.
 * All rights reserved. Please see the file LICENSE which should be
 * distributed with this software for terms of use.
 */

#include "diald.h"

/*
 * Open up the various files we use to monitor network activity.
 */
void filter_setup()
{
    /* get two socket to the INET kernel */ 
    /* We need two sockets because some (recent) versions of the kernel
     * won't forward packets back to the socket that sent the packet.
     */

    if ((fwdfd = socket(AF_INET, SOCK_PACKET, htons(ETH_P_ALL))) < 0) {
        syslog(LOG_ERR, "Could not get socket to do packet forwarding: %m");
        die(1);
    }
    if ((snoopfd = socket(AF_INET, SOCK_PACKET, htons(ETH_P_ALL))) < 0) {
        syslog(LOG_ERR, "Could not get socket to do packet monitoring: %m");
        die(1);
    }
}

/*
 * Set up the idle filter mechanism for a connected link.
 */
void idle_filter_init()
{
    if (mode == MODE_SLIP) {
	sprintf(snoop_dev,"sl%d",link_iface);
    } else {
	sprintf(snoop_dev,"ppp%d",link_iface);
    }
    if (debug) syslog(LOG_INFO,"Changed snoop device to %s",snoop_dev);
    txtotal = rxtotal = 0;
}

/*
 * Point the idle filter to proxy link.
 */
void idle_filter_proxy()
{
    sprintf(snoop_dev,"sl%d",proxy_iface);
    if (debug) syslog(LOG_INFO,"Changed snoop device to %s",snoop_dev);
}

/*
 * We got a packet on the snooping socket.
 * Read the packet. Return 1 if the packet means the link should be up 0
 * otherwise. At the same time record the packet in the idle filter structure.
 */
void filter_read()
{
    struct sockaddr from;
    int from_len = sizeof(struct sockaddr);
    int len;

    if ((len = recvfrom(snoopfd,packet,4096,0,&from,&from_len)) > 0) {
	if (strcmp(snoop_dev,from.sa_data) == 0) {
#ifdef UNSAFE_ROUTING
	    /* If we are doing unsafe routing, then we cannot count
             * the transmitted packets on the forwarding side of the
	     * transitter (since there is none!), so we attempt to
	     * count them here. However, we can only tell packets
	     * that are leaving our interface from this machine,
	     * forwarded packets all get counted as received bytes.
	     */
	    if (((struct iphdr *)packet)->saddr == local_addr)
		txtotal += len;
	    else
#endif
	    rxtotal += len;
            if ((ntohs(((struct iphdr *)packet)->frag_off) & 0x1fff) == 0) {
	        /* Mark passage of first packet */
	        if (check_firewall(fwunit,packet,len) && state == STATE_UP)
	            state_timeout = -1;
	    }
	}
    }
}

void flush_timeout_queue()
{
    struct firewall_req req;
    req.unit = fwunit;
    ctl_firewall(IP_FW_QFLUSH,&req);
}

void interface_up()
{
    struct firewall_req req;
    req.unit = fwunit;
    ctl_firewall(IP_FW_UP,&req);
}

void interface_down()
{
    struct firewall_req req;
    req.unit = fwunit;
    ctl_firewall(IP_FW_DOWN,&req);
}

int queue_empty()
{
    struct firewall_req req;
    req.unit = fwunit;
    return ctl_firewall(IP_FW_QCHECK,&req);
}

void print_filter_queue(int sig)
{
    struct firewall_req req;
    syslog(LOG_INFO,"User requested dump of firewall queue.");
    syslog(LOG_INFO,"--------------------------------------");
    req.unit = fwunit;
    ctl_firewall(IP_FW_PCONN,&req);
    syslog(LOG_INFO,"--------------------------------------");
}

void monitor_queue()
{
    struct firewall_req req;
    req.unit = fwunit;
    ctl_firewall(IP_FW_MCONN,&req);
}
