char version[] = "Version wu-2.4(3) Sun Mar 26 23:22:15 MET DST 1995";
