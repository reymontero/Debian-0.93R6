
#ifndef MAXHOSTNAMELEN
#define MAXHOSTNAMELEN	64
#endif


extern char *community;
extern struct sockaddr_in address;
extern int reqid;
extern int sd;

extern void intpr ();
extern void rt_stats ();
extern void routepr ();
