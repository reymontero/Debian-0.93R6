#!/bin/sh
MANDIR=$1

echo Installing man pages in $MANDIR

mkdir $MANDIR
mkdir $MANDIR/man1
mkdir $MANDIR/man5
mkdir $MANDIR/man8
mkdir $MANDIR/man7
cp ../docs/*.1 $MANDIR/man1
cp ../docs/*.5 $MANDIR/man5
cp ../docs/*.8 $MANDIR/man8
cp ../docs/*.7 $MANDIR/man7
chmod 0644 $MANDIR/man1/smbstatus.1
chmod 0644 $MANDIR/man1/smbclient.1
chmod 0644 $MANDIR/man1/smbrun.1
chmod 0644 $MANDIR/man1/testparm.1
chmod 0644 $MANDIR/man1/testprns.1
chmod 0644 $MANDIR/man1/smbtar.1
chmod 0644 $MANDIR/man5/smb.conf.5
chmod 0644 $MANDIR/man7/samba.7
chmod 0644 $MANDIR/man8/smbd.8
chmod 0644 $MANDIR/man8/nmbd.8

exit 0

