/*
** On Exit:
**	<0	Failed, this will cause the httpd to exit
**	>=0 	ok
*/
PUBLIC int HTUserInit NOPARAMS;
