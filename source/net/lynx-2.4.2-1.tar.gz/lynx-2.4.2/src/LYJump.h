
#ifndef LYJUMP_H
#define LYJUMP_H

extern char *LYJump NOPARAMS;

#endif /* LYJUMP_H */

