
#ifndef LYCHARSETS_H
#define LYCHARSETS_H

extern int current_char_set;
extern char *LYchar_set_names[];

#endif /* LYCHARSETS_H */
