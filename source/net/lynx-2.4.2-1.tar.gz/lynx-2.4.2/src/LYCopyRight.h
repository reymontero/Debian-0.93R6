/********  string for the copyright notice  ********/
#ifndef LYCOPYRIGHT_H
#define LYCOPYRIGHT_H

static char copyright[] = { 
		"@(#)          (C) Copyright 1992,1993,1994 University of Kansas \n" };

#endif /* LYCOPYRIGHT_H */
