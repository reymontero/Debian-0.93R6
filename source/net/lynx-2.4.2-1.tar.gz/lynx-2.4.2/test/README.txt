ISO_LATIN1_test.html is for testing the translation of HTML entities
with the character sets that are selectable via the 'o'ptions menu.

Any other files in this directory do not represent a test suite.  They
are used during program testing to track down odd and mysterious bugs.
