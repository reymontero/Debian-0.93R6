$set 10  #arcnet

$ #_none Original Message:([NONE SET])
# [PAS DEFINI]

$ #_debug1 Original Message:(in_arcnet(%s): invalid arcnet address!\n)
# in_arcnet(%s): adresse arcnet incorrecte !\n

$ #_debug2 Original Message:(in_arcnet(%s): invalid arcnet address!\n)
# in_arcnet(%s): adresse arcnet incorrecte !\n

$ #_debug3 Original Message:(in_arcnet(%s): trailing : ignored!\n)
# in_arcnet(%s): ignore le reste !\n

$ #_debug4 Original Message:(in_arcnet(%s): trailing junk!\n)
# in_arcnet(%s): d�truit le reste !\n

$ #_arcnet Original Message:(1.5Mbps ARCnet)
# ARCnet � 1.5Mbps

