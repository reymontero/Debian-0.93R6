$set 15  #ipx

$ #_none Original Message:([NONE SET])
# [PAS DEFINI]

$ #_ipx Original Message:(IPX)
# IPX

