$set 14  #inet

$ #_debug1 Original Message:(rresolve: unsupport address family %d !\n)
# rresolve: famille d'adresse pas support�e %d !\n

$ #_none Original Message:([NONE SET])
# [PAS DEFINI]

$ #_darpa Original Message:(DARPA Internet)
# DARPA Internet

