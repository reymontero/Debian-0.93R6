$set 11  #ax25

$ #_none Original Message:([NONE SET])
# [PAS DEFINI]

$ #_debug1 Original Message:(Invalid callsign)
# Donn�e incorrecte

$ #_debug2 Original Message:(Callsign too long)
# Donn�e trop longue

$ #_hw Original Message:(AMPR AX.25)
# AMPR AX.25

$ #_ax25 Original Message:(AMPR AX.25)
# AMPR AX.25

