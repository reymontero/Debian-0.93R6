$set 15  #ipx

$ #_none Original Message:([NONE SET])
# [NONE SET]

$ #_ipx Original Message:(IPX)
# IPX

