$set 16  #loopback

$ #_none Original Message:([NONE SET])
# [NONE SET]

$ #_unspec Original Message:(UNSPEC)
# UNSPEC

$ #_loop Original Message:(Local Loopback)
# Local Loopback

