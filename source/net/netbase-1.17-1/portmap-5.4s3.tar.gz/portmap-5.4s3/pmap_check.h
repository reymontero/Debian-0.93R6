/* @(#) pmap_check.h 1.3 93/11/21 16:18:53 */

extern int from_local();
extern void check_startup();
extern int check_default();
extern int check_setunset();
extern int check_privileged_port();
extern int check_callit();
extern int verboselog;
extern int allow_severity;
extern int deny_severity;
