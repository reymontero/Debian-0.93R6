/*
 * version file for ntpdate
 */
char * Version = "ntpdate version=3.4x (beta multicast); Thu Sep 28 22:07:57 WST 1995 (1)";
