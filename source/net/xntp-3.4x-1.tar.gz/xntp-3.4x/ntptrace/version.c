/*
 * version file for ntptrace
 */
char * Version = "ntptrace version=3.4x (beta multicast); Thu Sep 28 22:08:16 WST 1995 (1)";
