/*
 * version file for xntpdc
 */
char * Version = "xntpdc version=3.4x (beta multicast); Thu Sep 28 22:06:16 WST 1995 (1)";
