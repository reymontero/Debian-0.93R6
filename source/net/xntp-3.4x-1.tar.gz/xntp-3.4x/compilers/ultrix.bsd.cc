COMPILER= cc -Olimit 800

