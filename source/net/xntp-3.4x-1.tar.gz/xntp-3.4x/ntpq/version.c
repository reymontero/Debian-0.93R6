/*
 * version file for ntpq
 */
char * Version = "ntpq version=3.4x (beta multicast); Thu Sep 28 22:07:31 WST 1995 (1)";
