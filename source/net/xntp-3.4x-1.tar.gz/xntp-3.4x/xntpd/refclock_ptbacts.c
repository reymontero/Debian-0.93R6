/*
 * crude hack to avoid hard links in distribution
 * and keep only one ACTS type source for different
 * ACTS refclocks
 */
#ifdef PTBACTS
#define KEEPPTBACTS
#undef ACTS
#include "refclock_acts.c"
#endif
