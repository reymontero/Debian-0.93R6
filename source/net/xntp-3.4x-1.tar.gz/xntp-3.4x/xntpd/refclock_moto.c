#if defined(REFCLOCK) && defined(NMEA)
#endif
