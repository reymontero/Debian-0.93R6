/*
 * version file for xntpd
 */
char * Version = "xntpd version=3.4x (beta multicast); Thu Sep 28 22:05:05 WST 1995 (1)";
