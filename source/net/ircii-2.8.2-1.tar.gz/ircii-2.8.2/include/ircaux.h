/*
 * ircaux.h: header file for ircaux.c 
 *
 * Written By Michael Sandrof
 *
 * Copyright(c) 1990 
 *
 * See the COPYRIGHT file, or do a HELP IRCII COPYRIGHT 
 *
 * @(#)$Id: ircaux.h,v 1.7 1995/01/02 13:31:44 mrg stable $
 */

#ifndef _IRCAUX_H_
#define _IRCAUX_H_

#include <stdio.h>

extern	char	*check_nickname();
extern	char	*next_arg();
extern	char	*new_next_arg();
extern	char	*expand_twiddle();
extern	char	*upper();
extern	char	*sindex();
extern	char	*rfgets();
extern	char	*path_search();
extern	char	*double_quote();
extern	char	*new_malloc();
extern	char	*new_realloc();
extern	void	malloc_strcpy();
extern	void	malloc_strcat();
extern	void	new_free();
extern	void	wait_new_free();
extern	FILE	*zcat();
extern	int	is_number();
extern	int	my_stricmp _((char *, char *));
extern	int	my_strnicmp _((char *, char *, int));
extern	int	scanstr _((char *, char *));
extern	void	really_free();
extern	void	strmcpy();
extern	void	strmcat();

#endif /* _IRCAUX_H_ */
