/*
 * log.h: header for log.c 
 *
 * Written By Michael Sandrof
 *
 * Copyright(c) 1990 
 *
 * See the COPYRIGHT file, or do a HELP IRCII COPYRIGHT 
 *
 * @(#)$Id: log.h,v 1.4 1994/07/02 02:38:10 mrg stable $
 */

#ifndef _LOG_H_
#define _LOG_H_

extern	FILE	*do_log();
extern	void	logger();
extern	void	set_log_file();
extern	void	add_to_log();

#endif /* _LOG_H_ */
