/*
 * numbers.h: header for numbers.c
 *
 * written by michael sandrof
 *
 * copyright(c) 1990 
 *
 *
 * @(#)$Id: numbers.h,v 1.4 1994/07/02 02:38:10 mrg stable $
 * see the copyright file, or do a help ircii copyright 
 */

#ifndef _NUMBERS_H_
#define _NUMBERS_H_

extern	char	*numeric_banner();
extern	void	display_msg();
extern	void	numbered_command();

#endif /* _NUMBERS_H_ */
