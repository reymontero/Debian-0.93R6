extern struct tab cmdtab[];
extern struct tab sitetab[];
