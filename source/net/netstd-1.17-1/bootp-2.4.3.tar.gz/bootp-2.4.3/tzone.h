/* tzone.h */
extern int32 secondswest;
extern void tzone_init();
