/* getether.h */

#ifdef	__STDC__
extern int getether(char *ifname, char *eaptr);
#else
extern int getether();
#endif
