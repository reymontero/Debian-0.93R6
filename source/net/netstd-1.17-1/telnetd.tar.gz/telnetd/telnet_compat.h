/*
 * definitions for the linux libc-4.6.27
 *
 */

#ifndef _TELNET_COMPAT_H
#define _TELNET_COMPAT_H
 
#ifndef TELOPT_ENVIRON
#define TELOPT_ENVIRON TELOPT_OLD_ENVIRON
#endif

#ifndef ENV_VAR
#define ENV_VAR OLD_ENV_VAR
#endif

#ifndef ENV_VALUE
#define ENV_VALUE OLD_ENV_VALUE
#endif

#endif /* _TELNET_COMPAT_H */

