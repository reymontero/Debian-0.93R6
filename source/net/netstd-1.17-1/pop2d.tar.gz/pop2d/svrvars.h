/*
 *	SVRVARS.H  --   this C header file contains the variable
 *			declarations for the POP2 server.
 *
 *      (C) Copyright 1991 Regents of the University of California
 *
 *      Permission to use, copy, modify, and distribute this program
 *      for any purpose and without fee is hereby granted, provided
 *      that this copyright and permission notice appear on all copies
 *      and supporting documentation, the name of University of California
 *      not be used in advertising or publicity pertaining to distribution
 *      of the program without specific prior permission, and notice be
 *      given in supporting documentation that copying and distribution is
 *      by permission of the University of California.
 *      The University of California makes no representations about
 *      the suitability of this software for any purpose.  It is provided
 *      "as is" without express or implied warranty.
 *
 *	REVISIONS:
 *			12-87	[ks]	original implementation
 *		1.000	 5-88	[ks]
 *		1.001	 2-89	[ks]
 *
 */

	/* Variables for command/response storage */
char	from_svr_buf[CMD_BUFSIZ];	/* Buf for replies from server side */
char	from_cli_buf[CMD_BUFSIZ];	/* Buf for replies from client side */


	/* Variables for greeting/HELO handling */
char			*host_i_am;	/* Host name for greeting */
char			*user_name;	/* Usercode of client */

	/* Variables for handling mailbox folders */
char			*fld_orig;	/* Name of mailbox requested */
int			 fld_write_ok;	/* ON=user has write privs for mbox */

int			 fld_current;	/* Current msg index pointer */
char			*fld_fname;	/* Name of working mailbox */
FILE			*fld_fp;	/* File descr for mbox reads */
struct FLD_ENTRIES	*fld_msg;	/* Array for msg handling */

					/* Char buffer for reading msg text */
char			 rfc_buf[CMD_BUFSIZ];


FILE    *log_fp;			/* File for diagnostics if DEBUG on */


	/* Variables for socket handling when standalone server */
int	s_pop2_svr,			/* Socket descr for access control */
	s_active;			/* Socket descr for each client */



	/* Declare these variables as external. Their actual declaration */
	/*   (and compile-time initialization) are in the file tables.c  */

extern char		*host_client;	/* Host name for host pops */
extern char		*smtp_host;	/* Host name from BSMTP HELO */

extern int		 fld_cnt;	/* Actual # of msgs in folder */
extern int		 svr_state;	/* Current state of server */
extern char		*svr_input[];	/* Possible client commands */
					/* Server decision table */
extern int		 svr_table[12][6];
