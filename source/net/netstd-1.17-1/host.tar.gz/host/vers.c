#ifndef lint
static char Version[] = "@(#)vers.c	e07@nikhef.nl (Eric Wassenaar) 950502";
#endif

char *version = "950502";

#if defined(apollo)
int h_errno = 0;
#endif
