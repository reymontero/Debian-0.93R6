/*************************************************************************
 *  TinyFugue - programmable mud client
 *  Copyright (C) 1993, 1994 Ken Keys
 *
 *  TinyFugue (aka "tf") is protected under the terms of the GNU
 *  General Public License.  See the file "COPYING" for details.
 ************************************************************************/
/* $Id: signals.h,v 35004.1 1995/04/30 01:05:45 hawkeye Exp $ */

#ifndef SIGNALS_H
#define SIGNALS_H

extern void NDECL(init_signals);
extern void NDECL(process_signals);
extern int  FDECL(shell_status,(int result));
extern int  FDECL(shell,(CONST char *cmd));
extern int  NDECL(suspend);
extern int  NDECL(interrupted);
extern void FDECL(core,(CONST char *fmt, CONST char *file, int line, long n));

#endif /* SIGNALS_H */
