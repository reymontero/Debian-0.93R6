/*************************************************************************
 *  TinyFugue - programmable mud client
 *  Copyright (C) 1993, 1994 Ken Keys
 *
 *  TinyFugue (aka "tf") is protected under the terms of the GNU
 *  General Public License.  See the file "COPYING" for details.
 ************************************************************************/
/* $Id: expand.h,v 35004.1 1995/04/30 01:05:06 hawkeye Exp $ */

#ifndef EXPAND_H
#define EXPAND_H

/* note: these numbers must agree with enum_subs[] in variable.c. */
#define SUB_LITERAL -1  /* send literally (no command interpretation, even)   */
#define SUB_NONE     0  /* no subs, but execute as tf command if leading '/'  */
#define SUB_KEYWORD  1  /* SUB_NEWLINE if initial keyword, else SUB_NONE      */
#define SUB_NEWLINE  2  /* %; subs and command execution                      */
#define SUB_FULL     3  /* all subs and command execution                     */
#define SUB_MACRO    4  /* all subs and command execution, from macro         */

extern int   FDECL(process_macro,(char *body, CONST char *args, int subs));

#endif /* EXPAND_H */
