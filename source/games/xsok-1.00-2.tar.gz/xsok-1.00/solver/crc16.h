unsigned short CRC16_reset(void);
unsigned short CRC16_add(const void *buffer, size_t n);
