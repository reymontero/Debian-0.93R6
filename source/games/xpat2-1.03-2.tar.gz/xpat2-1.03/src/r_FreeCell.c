/*****************************************************************************/
/*									     */
/*									     */
/*	X patience version 2 -- module r_FreeCell.c			     */
/*									     */
/*	Characteristics of the ``FreeCell'' rules			     */
/*	written by Michael Bischoff					     */
/*	see COPYRIGHT.xpat2 for Copyright details			     */
/*									     */
/*									     */
/*****************************************************************************/
#include "xpatgame.h"

/* this one has been moved to r_Seahaven.c */
