/* 
Copyright notice:

This is mine.  I'm only letting you use it.  Period.  Feel free to rip off
any of the code you see fit, but have the courtesy to give me credit.
Otherwise great hairy beasties will rip your eyes out and eat your flesh
when you least expect it.

Jonny Goldman <jgoldman@parc.xerox.com>

Tue Jul 17 1990
*/

/* score.c -- Print the score. */

#include "vaders.h"

PaintScore()
{
  char scorestring[7];
  XDrawString(dpy, gamewindow, backgc, gamewidth, 10, "Score", 5);
  sprintf(scorestring, "%6d", lastscore);
  XDrawString(dpy, gamewindow, backgc, gamewidth, 20, scorestring, 6);
  lastscore = score;
  sprintf(scorestring, "%6d", lastscore);
  XDrawString(dpy, gamewindow, scoregc, gamewidth, 10, "Score", 5);
  XDrawString(dpy, gamewindow, scoregc, gamewidth, 20, scorestring, 6);
  if (nextbonus && score >= nextbonus) {
    basesleft++;
    ShowBase(basesleft-1, basegc);
    bases = basesleft;
    nextbonus = 0;
  }
  sprintf(scorestring, "%6d", hiscore);
  XDrawString(dpy, gamewindow, backgc, gamewidth, 30, " High", 5);
  XDrawString(dpy, gamewindow, backgc, gamewidth, 40, scorestring, 6);
  if (score > hiscore) hiscore = score;
  sprintf(scorestring, "%6d", hiscore);
  XDrawString(dpy, gamewindow, scoregc, gamewidth, 30, " High", 5);
  XDrawString(dpy, gamewindow, scoregc, gamewidth, 40, scorestring, 6);
}

InitScore()
{
    score = 0;
    basesleft = 3;
    nextbonus = 1500;
}
