/* trim.c  93.12.21
 * Copyright 1983-1992   Albert Davis
 * remove whitespace from the end of strings
 */
#include "ecah.h"
#include "declare.h"
/*--------------------------------------------------------------------------*/
	char	  *trim(char*);
/*--------------------------------------------------------------------------*/
char *trim(char *string)
{
 int index;
 
 index = strlen(string);
 while (index > 0  &&  !isgraph(string[--index]))
    string[index] = '\0' ;
 return string;
}
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
