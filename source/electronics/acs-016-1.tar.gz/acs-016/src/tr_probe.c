/* tr_probe.c  94.03.20
 * Copyright 1983-1992   Albert Davis
 * transient analysis probe
 */
#include "ecah.h"
#include "branch.h"
#include "probh.h"
#include "status.h"
#include "declare.h"
/*--------------------------------------------------------------------------*/
	double	trprobe(probe_t);
/*--------------------------------------------------------------------------*/
extern const struct status stats;
extern const int sim_mode;
/*--------------------------------------------------------------------------*/
double trprobe(probe_t prb)
{
 if (!prb.brh){
    return probe_node(prb);
 }else{
    return probe_branch(prb.brh,prb.what);
 }
}
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
