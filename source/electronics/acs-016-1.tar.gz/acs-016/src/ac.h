/* ac.h  07/26/93
 * Copyright 1983-1992   Albert Davis
 */
#define AC_H

typedef struct {
   double start;	/* sweep start time */
   double stop;		/* sweep stop time */
   double step;		/* printed step size */
   int linswp;		/* flag: use linear sweep (vs log sweep) */
   int echo;		/* flag: echo the input when using input data file */
   int cold;		/* flag: power off.  all DC voltages are 0 */
   int cont;		/* flag: continue.  don't do op first */
   double freq;		/* frequency to analyze at (Hertz) */
   double omega;	/* frequency to analyze at (radians per second) */
} ac_t;
