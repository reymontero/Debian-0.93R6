/* io.h  08/19/93
 * Copyright 1983-1992   Albert Davis
 * i/o stuff
 */
#define ioDEFmstdin	(1)
#define ioDEFmstdout	(2)
#define ioDEFmstderr	(2)
#define ioDEFmpr	(16)
#define ioDEFwhere	(0)
#define ioDEFformaat	(0)
#define ioDEFwhence	(0)
#define ioDEFsuppresserrors (NO)
#define ioDEFechoflag	(NO)
#define ioDEFprintflag	(NO)
#define ioDEFincipher	(NO)
#define ioDEFoutcipher	(NO)
#define ioDEFpack	(NO)
#define ioDEFploton	(NO)
#define ioDEFplotset	(NO)

struct ioctrl{
   int mstdin;
   int mstdout;
   int mstderr;
   int mprint;
   int where;		/* where to send data, multi-format	*/
   int formaat;		/* how to format io.  Basic option.	*/
   FILE *whence;	/* get file from.  std C file.		*/
   int suppresserrors;
   int echoflag;
   int printflag;
   int incipher;	/* decrypt input file			*/
   int outcipher;	/* encrypt output file			*/
   int pack;		/* convert whitespace to tabs on out	*/
   int ploton;
   int plotset;
};
