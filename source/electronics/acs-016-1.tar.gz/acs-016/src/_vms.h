/* _vms.h  94.07.13
 * Copyright 1983-1993  Albert Davis
 */
/* constants related to memory size, word size, etc */
#define SEGSIZ		9000000
#define	BUFLEN		256
#define BIGBUFLEN	2048
#define MAXWIDTH	512
#define PROBECOUNT	500
#define MAXEVENTCOUNT	2000
#define SAVEITERATIONS	2
#define SAVEBACKTIME	4
#define DCNEST		4
#define RECURSE		8
#define LABELEN		8
#define MAXHANDLE	((int)((CHAR_BIT*sizeof(int))-1))

/* file names, etc. */
#define BEGINDIR	"["
#define DIRSEP		"./"
#define	ENDDIR		"]/"
#define PATHSEP		';'
#define SYSTEMSTARTFILE	"acs.rc"
#define SYSTEMSTARTPATH	getenv("PATH")
#define USERSTARTFILE	".acsrc"
#define	USERSTARTPATH	getenv("HOME")
#define EDITFILE   	"EXXXXXX"
#define STEPFILE   	"SXXXXXX"
#define PLOTFILE    	"acs.plot"
#define HELPFILE    	"acs.hlp"
#define HELPPATH	getenv("PATH")

/* standard collection of includes */
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

/* non-standard collection of includes */
#ifndef vaxc
#include <malloc.h>
#else
#include unixlib
#endif

/* to avoid the `conflicting attributes' message from the linker */
#ifdef vaxc
#define const 
#endif

/* to avoid 'multiply defined' message from the linker */
#ifdef vaxc
#define box bbooxx
#endif

/* declarations of library functions not properly declared in header files. */
#ifndef vaxc
typedef int size_t;
#endif
#define MAXDOUBLE 1e37
#define F_OK 00		/* io.h */
#define X_OK 01
#define W_OK 02
#define R_OK 04
#define SEEK_SET 0

/* there's no getrusage.  fake it */
#ifndef vaxc
typedef long time_t;
#endif
#define RUSAGE_SELF	0
struct timeval {
	long	tv_sec;		/* seconds */
	long	tv_usec;	/* and microseconds */
};
struct	rusage {
	struct timeval ru_utime;	/* user time used */
	struct timeval ru_stime;	/* system time used */
};
void getrusage(int,struct rusage*);
