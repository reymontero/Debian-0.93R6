/* ac_fill.c  94.02.18
 * Copyright 1983-1992   Albert Davis
 * Fill working matrix for AC analysis
 */
#include "ecah.h"
#include "branch.h"
#include "status.h"
#include "declare.h"
/*--------------------------------------------------------------------------*/
	void	ac_fill_rl(branch_t*);
/*--------------------------------------------------------------------------*/
extern struct status stats;
/*--------------------------------------------------------------------------*/
void ac_fill_rl(branch_t *brh)
{
 branch_t *stop;
 if (exists(brh)){
    stop = brh;
    do {
       doac_branch(brh);
    } while (brh=nextbranch_dev(brh),  brh != stop);
 }
}
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
