/* skiparg.c  93.12.21
 * Copyright 1983-1992   Albert Davis
 * skip an argument in a string
 */
#include "ecah.h"
#include "declare.h"

void skiparg(const char *cmd, int *cnt)
{
 if (!skipcom(cmd,cnt)){
    if (cmd[*cnt])
       (*cnt)++;
    while (isalnum(cmd[*cnt]) || cmd[*cnt]=='.')
       (*cnt)++;
    skipcom(cmd,cnt);
 }
}
