/* worst  06/02/85-1
 * Copyright 1983-1992   Albert Davis
 * worst case flag definitions
 */
#define wWORST	1
#define wSENS	2
#define wRAND	3
#define wMAXDC	4
#define wMINDC	5
#define wMAXAC	6
#define wMINAC	7
#define wLEAD	8
#define wLAG	9

#define wUP		3
#define wNOCHG	2
#define wDOWN	1
