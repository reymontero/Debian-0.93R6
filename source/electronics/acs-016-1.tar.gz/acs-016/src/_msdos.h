/* _msdos.h  94.07.13
 * Copyright 1983-1993  Albert Davis
 * Special stuff for msdos (640k)
 */
/* constants related to memory size, word size, etc */
#define	SEGSIZ		65511L
#define	BUFLEN		128
#define BIGBUFLEN	2048
#define MAXWIDTH	256
#define PROBECOUNT	200
#define MAXEVENTCOUNT	500
#define SAVEITERATIONS	2
#define SAVEBACKTIME	4
#define DCNEST		4
#define RECURSE		8
#define LABELEN		8
#define MAXHANDLE	((int)((CHAR_BIT*sizeof(int))-1))

/* file names, etc. */
#define BEGINDIR	""
#define DIRSEP		"/\\"
#define	ENDDIR		"/\\"
#define PATHSEP		';'
#define SYSTEMSTARTFILE	"acs.rc"
#define SYSTEMSTARTPATH	getenv("PATH")
#define USERSTARTFILE	"acs.rc"
#define	USERSTARTPATH	getenv("HOME")
#define EDITFILE   	"/tmp/EXXXXXX"
#define STEPFILE   	"/tmp/SXXXXXX"
#define PLOTFILE    	"acs.plt"
#define HELPFILE    	"acs.hlp"
#define HELPPATH	getenv("PATH")

/* standard collection of includes */
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

/* non-standard collection of includes */
#include <conio.h>
#include <direct.h>
#include <fcntl.h>
#include <float.h>
#include <io.h>
#include <malloc.h>
#include <memory.h>

#ifdef __BORLANDC__
#include <values.h>
#endif

/* stuff that seems to be always missing */
#define F_OK 00		/* io.h */
#define X_OK 01
#define W_OK 02
#define R_OK 04

/* there's no getrusage.  fake it */
#define RUSAGE_SELF	0
struct timeval {
	long	tv_sec;		/* seconds */
	long	tv_usec;	/* and microseconds */
};
struct	rusage {
	struct timeval ru_utime;	/* user time used */
	struct timeval ru_stime;	/* system time used */
};
void getrusage(int,struct rusage*);

#ifdef MSC
#define exp(x)		Exp(x)	/* exp() has a bug.  use mine. */
double Exp(double);
#define MAXDOUBLE       1.79769313486231470e+300	/* values.h */
#endif
