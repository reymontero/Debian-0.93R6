/* formats.h  03/07/92
 * Copyright 1983-1992   Albert Davis
 * format flag defines
 */

#define FMTEXP  1
#define FMTSIGN 2
#define FMTFILL 4
#define FMTFIX  8
