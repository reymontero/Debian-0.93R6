/* title.c  93.12.21
 * Copyright 1983-1992   Albert Davis
 * set title on printouts, etc.
 */
#include "ecah.h"
#include "io.h"
#include "declare.h"
/*--------------------------------------------------------------------------*/
	void	  cmd_title(const char*,int*);
/*--------------------------------------------------------------------------*/
extern struct ioctrl io;
extern char head[];
/*--------------------------------------------------------------------------*/
void cmd_title(const char *cmd, int *cnt)
{
 io.where = (cmd[*cnt]) ? 0 : io.mstdout;

 if (cmd[*cnt])
	strcpy(head, &cmd[*cnt]);
 mprintf(io.where,"%s\n",head);
}
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
