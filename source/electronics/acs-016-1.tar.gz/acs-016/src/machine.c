/* version.c  94.03.03
 * Copyright 1983-1992   Albert Davis
 * a dumb selector for portability
 */
#include "ecah.h"
#include "io.h"
#include "declare.h"
/*--------------------------------------------------------------------------*/
#if defined(MSDOS)
#   include "_msdos.c"
#elif defined(UNIX)
#   include "_unix.c"
#elif defined(VMS)
#   include "_vms.c"
#endif
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
