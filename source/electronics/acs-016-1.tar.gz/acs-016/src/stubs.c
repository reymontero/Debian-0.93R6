/* stubs.c  93.12.21
 * Copyright 1983-1992   Albert Davis
 * stubs to satisfy references to Spice commands not supported here
 */
#include "ecah.h"
#include "error.h"
#include "declare.h"
/*--------------------------------------------------------------------------*/
	void	cmd_alter(const char*,int*);
	void	cmd_disto(const char*,int*);
	void	cmd_model(const char*,int*);
	void	cmd_noise(const char*,int*);
	void	cmd_sens(const char*,int*);
	void	cmd_subckt(const char*,int*);
	void	cmd_temp(const char*,int*);
	void	cmd_tf(const char*,int*);
/*--------------------------------------------------------------------------*/
static	char	e_spice[] = "Spice dot-card not implemented: %s\n";
/*--------------------------------------------------------------------------*/
/*ARGSUSED*/
void cmd_alter(const char *cmd, int *cnt)
{
 error(bWARNING, e_spice, cmd);
}
/*--------------------------------------------------------------------------*/
/*ARGSUSED*/
void cmd_disto(const char *cmd, int *cnt)
{
 error(bWARNING, e_spice, cmd);
}
/*--------------------------------------------------------------------------*/
/*ARGSUSED*/
void cmd_model(const char *cmd, int *cnt)
{
 error(bWARNING, e_spice, cmd);
}
/*--------------------------------------------------------------------------*/
/*ARGSUSED*/
void cmd_noise(const char *cmd, int *cnt)
{
 error(bWARNING, e_spice, cmd);
}
/*--------------------------------------------------------------------------*/
/*ARGSUSED*/
void cmd_sens(const char *cmd, int *cnt)
{
 error(bWARNING, e_spice, cmd);
}
/*--------------------------------------------------------------------------*/
/*ARGSUSED*/
void cmd_subckt(const char *cmd, int *cnt)
{
 error(bWARNING, e_spice, cmd);
}
/*--------------------------------------------------------------------------*/
/*ARGSUSED*/
void cmd_temp(const char *cmd, int *cnt)
{
 error(bWARNING, e_spice, cmd);
}
/*--------------------------------------------------------------------------*/
/*ARGSUSED*/
void cmd_tf(const char *cmd, int *cnt)
{
 error(bWARNING, e_spice, cmd);
}
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
