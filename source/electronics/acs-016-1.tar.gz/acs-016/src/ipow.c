/* ipow.c  93.12.19
 * Copyright 1983-1992   Albert Davis
 * like pow() (std function) but y rounded to integer
 * done by repeated multiplication
 * returns zero if x == 0
 */			/* z = pow(x,y) */
#include "ecah.h"
#include "error.h"
#include "declare.h"
/*--------------------------------------------------------------------------*/
	double	ipow(double,int);
/*--------------------------------------------------------------------------*/
extern char e_int[];
/*--------------------------------------------------------------------------*/
double ipow(double x, int y)
{
 double z;
 
 if (y < 0){
    if (x != 0.){
       x = 1./x;
       y = -y;
    }else{	/* zero to negative power */
       error(bERROR, e_int, "ipow");
    }
 }
 
 for ( z=1.;  y>0;  y-- )
    z *= x;
 
 return z;
}
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
