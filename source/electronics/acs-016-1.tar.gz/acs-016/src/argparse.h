/* argparse.h  94.04.20
 * Copyright 1983-1992   Albert Davis
 * defines for "argparse" calls
 */
#define ONEPASS 0	/* NO */
#define REPEAT	1	/* YES */

#define aDOUBLE 1	/* double */
#define aUDOUBLE 2	/* double, force positive */
#define aINT 3		/* int */
#define aUINT 4		/* int, force positive */
#define aENUM 5		/* int, set to next param, do not read */
#define aODOUBLE 6	/* double with offset */
#define a2DOUBLE 7	/* 2 doubles */
#define aORENUM 8	/* int, or to next param, do not read */
#define aANDENUM 9	/* int, and to next param, do not read */
#define aFUNCTION 10	/* call function with params cmd,cnt */
#define a2FUNCTION 11	/* 2 functions, in sequence */
#define aSDOUBLE 12	/* double with scale */
#define	aFINT 13	/* int, but take in double format */
#define aIDOUBLE 14	/* inverted double */
#define aSIDOUBLE 15	/* scaled, inverted double (scaled first) */
#define aOIDOUBLE 16	/* offset, inverted double (offset first) */
#define	aOCTAL 17	/* int in octal */
#define aHEX 18		/* int in hex */
