/*  nodeset.h  03/02/93
 * Copyright 1983-1992   Albert Davis
 *  structures to keep track of nodesets and ICs
 */
#define NODESET_H

typedef struct nodeset{
   struct nodeset *next;
   int    node;
   double voltage;
} nodeset_t;
