/* quit.c  93.12.21
 * Copyright 1983-1992   Albert Davis
 * exits the program
 */
#include "ecah.h"
#include "mode.h"
#include "options.h"
#include "declare.h"
/*--------------------------------------------------------------------------*/
	void	cmd_quit(const char*, int*);
/*--------------------------------------------------------------------------*/
extern const struct options opt;
extern int run_mode;	/* variations on handling of dot cmds		    */
/*--------------------------------------------------------------------------*/
/*ARGSUSED*/
void cmd_quit(const char *cmd, int *cnt)
{
 if (run_mode == rEXECUTE){
    if (match(cmd,"END") && opt.acct)
       cmd_status();
    exit(0);
 }
}
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
