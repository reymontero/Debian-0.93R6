/* isfloat  03/13/84-3  93.12.19
 * Copyright 1983-1992   Albert Davis
 * return 1 if any character that a floating number string can start with
 */
#include "ecah.h"
#include "declare.h"

int isfloat(int chr)
{
 return ( isdigit(chr) || chr=='.' || chr=='-' || chr=='+' );
}
