/* probh.h  94.12.09
 * Copyright 1983-1992   Albert Davis
 * named probe definitions
 */
 
#ifndef PROBH_H		/* BUG: I don't like this */
#define PROBH_H

typedef struct {
   char    what[LABELEN+1];    
   int node;
   struct branch *brh;
   double lo,hi;
} probe_t;

typedef enum {mtNONE, mtMAG, mtPHASE, mtREAL, mtIMAG} mod_t;

typedef struct {
   complex_t value;
   mod_t modifier;
   double dbscale;
   int ok;
} xprobe_t;
#endif
