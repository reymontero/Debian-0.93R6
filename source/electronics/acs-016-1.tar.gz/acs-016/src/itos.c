/* itos.c  93.12.19
 * Copyright 1983-1992   Albert Davis
 * Integer to string (signed).
 * num = number to convert.
 * str = string to put it in.  Must be big enough, or else!!
 *	    Must have length at least len+1.
 * len = number of significant digits.
 *	 If minus, left justify, else right.
 * fmt = format : 0	  = normal : sign if minus.
 *		  FMTSIGN = always sign.
 */
#include "ecah.h"
#include "formats.h"
#include "declare.h"
/*--------------------------------------------------------------------------*/
	char	*itos(int,char*,int,int);
/*--------------------------------------------------------------------------*/
char *itos(int num, char *str, int len, int fmt)
{
 int ii;
 char sign;
 
 if (num < 0){
    sign = '-';
    num = -num;
 }else if (fmt & FMTSIGN){
    sign = '+';
 }else{
    sign = ' ';
 }
 
 (void)utos( (unsigned)num, &str[1], len );
 for ( ii=1; str[ii]==' '; ++ii )
    ;
 str[ii-1] = sign;
 return str;
}
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
