/* dev_subckt.h  94.11.20
 * Copyright 1983-1992   Albert Davis
 * data structures for subcircuits
 */

#define UNUSED 0
#define USED -3
#define NODESPERSUBCKT 1000
#define PORTSPERSUBCKT 100

#define sDEFAULT_modelname	""

struct subckt {
   generic_t	*x;
   size_t	ssize;
   const generic_t *m;
   char		modelname[LABELEN+1];
   node_t	n[PORTSPERSUBCKT+1];
};

struct smod {
   generic_t	*x;
   size_t	ssize;
   const generic_t *m;
   char		modelname[LABELEN+1];
   node_t	n[PORTSPERSUBCKT+1];
};

	int     tr_subckt(branch_t*);
	void    un_subckt(branch_t*);
	void    ac_subckt(branch_t*);
	double	tr_review_subckt(branch_t*);
