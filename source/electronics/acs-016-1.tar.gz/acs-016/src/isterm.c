/* isterm.c  94.07.13
 * Copyright 1983-1992   Albert Davis
 * return 1 if terminator (space, comma, =, or null)
 * else 0
 */
#include "ecah.h"
#include "declare.h"

int isterm(int chr, const char *term)
{
 return (chr=='\0' || isspace(chr) || strchr(term,chr));
}
