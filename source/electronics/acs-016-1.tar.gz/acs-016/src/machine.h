/* version.h  94.03.03
 * Copyright 1983-1992   Albert Davis
 * a dumb include for portability
 */
#if defined(MSDOS)
#   include "_msdos.h"
#elif defined(UNIX)
#   include "_unix.h"
#elif defined(VMS)
#   include "_vms.h"
#endif
