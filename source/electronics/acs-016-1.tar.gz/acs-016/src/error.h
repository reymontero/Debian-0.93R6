/* error.h  02/18/91
 * Copyright 1983-1992   Albert Davis
 * data for error and exception handling
 */

/* arg to error() (badness) to decide severity of exception */
#define	bNOERROR	0
#define bTRACE		1
#define bLOG		2
#define bDEBUG		3
#define bPICKY		4
#define	bWARNING	5
#define bDANGER		6
#define bERROR		7
#define bEXIT		8
#define bDISASTER	9
