/* status.h  02/15/92
 * Copyright 1983-1992   Albert Davis
 * place to store all kinds of statistics
 */
#define STATUS_H

#ifndef iCOUNT
#include "mode.h"
#endif
/* I don't like this!!! */

struct time_s {
   double ref_user;	/* time the clock was started */
   double ref_system;
   double last_user;	/* time of timed operation */
   double last_system;
   double total_user;	/* time since program start */
   double total_system;
   int running;
};

struct status {
   struct time_s get;
   struct time_s op;
   struct time_s dc;
   struct time_s tran;
   struct time_s four;
   struct time_s ac;
   struct time_s setup;
   struct time_s order;
   struct time_s load;
   struct time_s lu;
   struct time_s back;
   struct time_s review;
   struct time_s output;
   struct time_s overhead;
   struct time_s total;
   int user_nodes;
   int subckt_nodes;
   int model_nodes;
   int total_nodes;
   int diodes;
   int bjts;
   int jfets;
   int mosfets;
   int gates;
   int subckts;
   int matrix_terms;
   int matrix_fills;
   int matrix_total;
   int matrix_ops;
   int control[cCOUNT];
   int iter[iCOUNT];
   double density;
};
