/* types.h  94.10.15
 * Copyright 1983-1994   Albert Davis
 * external declarations for device models
 */
extern functions_t dev_admittance;
extern functions_t dev_bjt;
extern functions_t dev_cap;
extern functions_t dev_cccs;
extern functions_t dev_ccvs;
extern functions_t dev_coil;
extern functions_t dev_coil_mutual;
extern functions_t dev_comment;
extern functions_t dev_cs;
extern functions_t dev_cswtch;
extern functions_t dev_diode;
extern functions_t dev_dotcard;
extern functions_t dev_logic;
extern functions_t dev_mos;
extern functions_t dev_resistor;
extern functions_t dev_subckt;
extern functions_t dev_trnlin;
extern functions_t dev_vccs;
extern functions_t dev_vcvs;
extern functions_t dev_vs;
extern functions_t dev_vswtch;
extern functions_t model_bjt;
extern functions_t model_diode;
extern functions_t model_logic;
extern functions_t model_mos;
extern functions_t model_subckt;
extern functions_t model_vswtch;
