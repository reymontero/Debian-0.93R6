/* dc.h  02/06/93
 * Copyright 1983-1992   Albert Davis
 */
#define DC_H

typedef struct {
   double start[DCNEST];
   double stop[DCNEST];
   double step[DCNEST];
   int linswp[DCNEST];
   double *(sweep[DCNEST]);	/* pointer to thing to sweep, dc command */
   branch_t *(zap[DCNEST]);	/* to branch to zap, for re-expand */
   int loop;		/* flag: after sweeping, do it again backwards */
   int reverse;		/* flag: sweep backwards */
   int cont;		/* flag: continue from previous run */
   int trace;		/* enum: show extended diagnostics */
   int printnow;	/* flag: print this step */
} dc_t;
