#include <curses.h>

/*
 * idlok --
 *      Fake idlok.
 */
void
idlok(win, bf)
        WINDOW *win;
        int bf;
{
	return;
}
