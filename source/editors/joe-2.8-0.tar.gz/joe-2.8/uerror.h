#ifndef _Ierr
#define _Ierr 1

#include "config.h"

int unxterr();
int uprverr();
int uparserr();
void inserr();
void delerr();
void abrerr();
void saverr();

#endif
