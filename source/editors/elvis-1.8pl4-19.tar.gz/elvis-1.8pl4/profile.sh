set PATH=.,\bin
set SHELL=shell.ttp
