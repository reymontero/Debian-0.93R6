/* Define this symbol if you are running CX/UX 7.0 or later (7.0 introduced
 * support for ELF files, and while we still build emacs in COFF format, the
 * way it is linked is different for 7.0).
 */
#define USING_CX_UX_7

#include "cxux.h"
