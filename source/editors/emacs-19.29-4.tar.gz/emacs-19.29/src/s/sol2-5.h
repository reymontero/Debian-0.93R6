/* Handle Solaris 2.5.  */

#include "sol2-4.h"

#undef GETTIMEOFDAY_ONE_ARGUMENT
