#define AIX4_1 

#include "aix4.h"

#if 0 /* Tomotake FURUHATA <furuhata@trl.ibm.co.jp> says this is needed
	 in Mule, but we don't know why.  Anyway, it's not needed now.  */
#define SYSTEM_MALLOC
#endif
