
Widget XtWidgetToDispatchTo (XEvent *);
