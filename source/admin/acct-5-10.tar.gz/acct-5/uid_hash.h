/* uid_hash.h
 *
 * ... duh ...
 */

#define NAME_LEN 8		/* length for usernames & devices */
#define TABLE_SIZE 51		/* nice prime table length */

struct uid_entry {
  struct uid_entry *next;  /* yes, Virginia, it is a linked list! */
  char name[NAME_LEN];     /* name of the user */
  int uid;                 /* uid of the user */
};


#define HASH(num) (int)(num % TABLE_SIZE)   /* simple hash fn for a num */

void clear_uid_table (void);
char *uid_name (int);

#ifndef __UID_HASH_H_NO_EXTERNS__

extern struct uid_entry uid_list[TABLE_SIZE]; /* place for the uids to live */

#endif
