/* files.h
 *
 * crunky ifdefs for file locations on various systems */

#ifndef WTMP_FILE
  #if defined(__FreeBSD__) || defined(__linux__)
    #define WTMP_FILE "/var/log/wtmp"
  #elif defined(sun)
    #define WTMP_FILE "/var/adm/wtmp"
  #elif defined(sgi) || defined(SVR4)
    #define WTMP_FILE "/usr/adm/wtmp"
  #else
    #define WTMP_FILE "/usr/adm/wtmp"
  #endif
#endif

#ifndef ACCT_FILE
  #if defined(__FreeBSD__) || defined(__linux__)
    #define ACCT_FILE "/var/account/pacct"
  #elif defined(sun)
    #define ACCT_FILE "/var/adm/pacct"
  #elif defined(sgi) || defined(SVR4)
    #define ACCT_FILE "/usr/adm/pacct"
  #else
    #define ACCT_FILE "/usr/adm/acct"
  #endif
#endif

#ifndef SAVACCT_FILE
  #if defined(__FreeBSD__) || defined(__linux__)
    #define SAVACCT_FILE "/var/account/savacct"
  #elif defined(sun)
    #define SAVACCT_FILE "/var/adm/savacct"
  #elif defined(sgi) || defined(SVR4)
    #define SAVACCT_FILE "/usr/adm/savacct"
  #else
    #define SAVACCT_FILE "/usr/adm/savacct"
  #endif
#endif

#ifndef USRACCT_FILE
  #if defined(__FreeBSD__) || defined(__linux__)
    #define USRACCT_FILE "/var/account/usracct"
  #elif defined(sun)
    #define USRACCT_FILE "/var/adm/usracct"
  #elif defined(sgi) || defined(SVR4)
    #define USRACCT_FILE "/usr/adm/usracct"
  #else
    #define USRACCT_FILE "/usr/adm/usracct"
  #endif
#endif
