/* acconfig.h
 *
 * miscellaneous definitions for autoheader, so that I don't have to
 * create the damn config.h.in file by hand EVERY TIME I CHANGE
 * SOMETHING.  Leave the ^L in on the next line. */


/* does your system have a working version of mktime? */
#undef HAVE_MKTIME

/* does your system have a getpagesize call? */
#undef HAVE_GETPAGESIZE

/* does your system have the ut_host field in utmp? */
#undef HAVE_UT_HOST

/* does your system use System V style utmp records? (uses ut_type field) */
#undef SYSTEM_V_STYLE_RECORDS


/* Hey!  Hey YOU!  Leave that ^L in on the previous line */

