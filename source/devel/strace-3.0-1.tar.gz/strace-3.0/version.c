char version[] = "strace -- version 3.0";
