#! /usr/local/bin/python

import sys
sys.path.append('/ufs/guido/src/www')

import www4inet				# This does all the work
