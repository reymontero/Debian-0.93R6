import sys

def report(args):
	pass

def reportnl(args):
	pass

##def report(args):
##	if type(args) == type(()):
##		for i in args:
##			print i,
##	else:
##		print args,
##	sys.stdout.flush()
##
##def reportnl(args):
##	report(args)
##	print
