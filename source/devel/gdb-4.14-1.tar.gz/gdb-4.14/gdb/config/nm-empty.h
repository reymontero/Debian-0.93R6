/* This is just a dummy file to symlink to when GDB is configured as a
   cross-only debugger.  */
