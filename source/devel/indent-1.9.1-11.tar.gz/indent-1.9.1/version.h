/*  Copyright (c) 1994, Joseph Arceneaux.  All rights reserved.

    GNU indent is originally based on Berkeley indent 5.11 of
    Sept. 15, 1988.

    After some independent changes by kingdon, he then merged in more
    Berkeley code in Sept 1989.  This version extends up to 1.1.3.

    After many changes by jla, including the switch to making "-gnu"
    the default, the version numbering was changed and 1.2 released. */

#define VERSION_STRING "GNU indent 1.9.1"
