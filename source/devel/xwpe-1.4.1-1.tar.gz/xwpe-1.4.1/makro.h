/*
	Allgemeine Makros
*/

#define isalnum1(x) ( isalnum(x) || (x) == '_')
#define isalpha1(x) ( isalpha(x) || (x) == '_')

