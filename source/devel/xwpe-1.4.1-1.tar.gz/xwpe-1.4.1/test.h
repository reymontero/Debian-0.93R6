/* test.h
/* Copyright (C) 1993 Fred Kruse                          */
/* This is free software; you can redistribute it and/or  */
/* modify it under the terms of the                       */
/* GNU General Public License, see the file COPYING.      */

/*
	Diese Datei ist nur zu Testzwecken erstellt
		und hat daher keine tiefere 
			Bedeutung

*/

