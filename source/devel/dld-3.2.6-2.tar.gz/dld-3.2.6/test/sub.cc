#include <iostream.h>

class A {
public:
	A() { cout<<"Hello, this is A"<<endl; }
	~A() { cout<<"Hello, this was A"<<endl; }
};


A a;
