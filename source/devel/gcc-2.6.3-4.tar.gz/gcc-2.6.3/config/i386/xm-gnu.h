/* Configuration for GCC for Intel i386 running GNU as host.  */

#include "i386/xm-i386.h"
#include "xm-gnu.h"
