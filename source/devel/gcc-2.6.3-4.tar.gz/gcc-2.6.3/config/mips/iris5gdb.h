/* Definitions of target machine for GNU compiler.  Irix version 5 with gas
   and gdb.  */

/* Use stabs instead of ECOFF debug format.  */
#define PREFERRED_DEBUGGING_TYPE DBX_DEBUG

#include "mips/iris5gas.h"
