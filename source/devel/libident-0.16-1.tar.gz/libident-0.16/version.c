char _id_version[] = "libident 0.16 Debian 1";
