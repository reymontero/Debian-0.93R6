/*
 * NAME
 *	sections - multisection function comment.
 *
 * DESCRIPTION
 *	Only a mental cripple would be as verbose as this.
 *
 * WARNING
 *	Now here's a legitimate excuse for it.
 */
int sections(
	int fred,	/* Mary's boyfriend */
	int world	/* real crazy */
)
{
	what the heck, all this stuff just gets ignored
}
