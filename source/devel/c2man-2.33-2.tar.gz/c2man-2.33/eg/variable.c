/* a variable, not a function.
 *
 * Note: you'll need to use -v to get this to work.
 */
int variable;
