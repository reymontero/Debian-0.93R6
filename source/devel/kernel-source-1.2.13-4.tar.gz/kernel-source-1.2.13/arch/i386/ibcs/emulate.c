/*
 *  linux/abi/emulate.c
 *
 *  Copyright (C) 1993  Linus Torvalds
 */

/*
 * Yes, sir, this file is completely empty, waiting for some real code..
 * I still copyright it, silly me.
 */
