int main(int argc, char **argv)
{
    int Tcl_Main(int, char **);
    return Tcl_Main(argc, argv);
}
