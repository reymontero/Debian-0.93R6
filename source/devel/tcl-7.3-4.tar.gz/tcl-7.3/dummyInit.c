#include <stdio.h>
#include <stdlib.h>
#include "tcl.h"

int
Tcl_AppInit(interp)
    Tcl_Interp *interp;		/* Interpreter for application. */
{
    return TCL_ERROR;
}
