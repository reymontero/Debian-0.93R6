// -*- C++ -*- backward compatiblity header.
// Copyright (C) 1994 Free Software Foundation

#ifndef __NEW_H__
#define __NEW_H__
#include <new>
#endif
