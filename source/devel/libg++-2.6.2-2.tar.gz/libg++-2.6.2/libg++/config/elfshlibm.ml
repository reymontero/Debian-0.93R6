BUILD_LIBS = $(SHLIB)
SHDEPS     = -lm
LIBS       = -L./$(TOLIBGXX) -lg++ -lcurses
