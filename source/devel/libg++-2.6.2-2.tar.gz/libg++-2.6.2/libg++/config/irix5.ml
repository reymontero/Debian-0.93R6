BUILD_LIBS = $(ARLIB) $(SHLIB)
SHDEPS     = -lcurses
