BUILD_LIBS = $(SHLIB)
LIBS       = -L./$(TOLIBGXX) -lg++ -lcurses -lm
