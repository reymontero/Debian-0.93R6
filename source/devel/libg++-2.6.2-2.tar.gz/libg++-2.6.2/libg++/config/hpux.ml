SHLIB      = libg++.sl
BUILD_LIBS = $(SHLIB)
SHFLAGS    = $(LIBCFLAGS)
