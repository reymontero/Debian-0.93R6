extern struct numeric_info ninfo;
