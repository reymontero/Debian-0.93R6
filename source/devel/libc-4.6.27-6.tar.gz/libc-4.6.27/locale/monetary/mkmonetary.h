extern struct monetary_info minfo;
