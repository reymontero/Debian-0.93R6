extern long md_chars_to_number (unsigned char *p, int nbytes);
extern void md_chars_to_hdr (unsigned char *p, struct exec *hdr);
