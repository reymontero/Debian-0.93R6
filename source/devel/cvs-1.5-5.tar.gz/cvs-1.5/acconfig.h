/* Define if you have MIT Kerberos version 4 available.  */
#undef HAVE_KERBEROS
