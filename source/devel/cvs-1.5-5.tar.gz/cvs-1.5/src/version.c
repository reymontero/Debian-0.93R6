/*
 * Copyright (c) 1994 david d `zoo' zuhn
 * Copyright (c) 1994 Free Software Foundation, Inc.
 * Copyright (c) 1992, Brian Berliner and Jeff Polk
 * Copyright (c) 1989-1992, Brian Berliner
 * 
 * You may distribute under the terms of the GNU General Public License as
 * specified in the README file that comes with this  CVS source distribution.
 * 
 * version.c - the CVS version number
 */

#include "cvs.h"

#ifndef lint
static const char rcsid[] = "$CVSid: @(#)version.c 1.15 94/10/03 $";
USE(rcsid)
#endif

char *version_string = "\nConcurrent Versions System (CVS) 1.5\n";
