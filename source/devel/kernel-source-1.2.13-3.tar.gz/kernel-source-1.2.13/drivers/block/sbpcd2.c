/*
 * duplication of sbpcd.c for multiple interfaces
 */
#define SBPCD_ISSUE 2
#include "sbpcd.c"
