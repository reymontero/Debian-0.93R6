/* The version number for this version of Bison
   Copyright (C) 1984, 1989, 1992 Free Software Foundation, Inc.
   Modified (1993, 1994, 1995) from bison-1.20 ... bison-1.24 by 
		Wilfred J. Hansen (wjh+@cmu.edu) 
		Andrew Consortium, Carnegie Mellon University
 */

char *version_string = "Bison version A2.5 (Andrew Consortium)\n";
