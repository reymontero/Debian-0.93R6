ldflags='-L/usr/ucblib'
