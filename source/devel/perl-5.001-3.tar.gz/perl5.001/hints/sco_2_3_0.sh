yacc='/usr/bin/yacc -Sm25000'
i_dirent=undef
