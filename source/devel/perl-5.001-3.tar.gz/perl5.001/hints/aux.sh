optimize='-O'
ccflags="$ccflags -B/usr/lib/big/ -DPARAM_NEEDS_TYPES"
POSIX_cflags='ccflags="$ccflags -ZP -Du_long=U32"'
