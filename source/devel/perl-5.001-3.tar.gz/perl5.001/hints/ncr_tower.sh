optimize='-O0'
ccflags="$ccflags -W2,-Sl,2000"
d_mkdir=$undef
usemymalloc='y'
