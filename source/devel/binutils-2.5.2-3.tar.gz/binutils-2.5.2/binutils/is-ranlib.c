/* Linked with ar.o to flag that this program is 'ranlib' (not 'ar'). */

int is_ranlib = 1;
