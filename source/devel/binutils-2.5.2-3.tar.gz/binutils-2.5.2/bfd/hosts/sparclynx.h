/* Sparc running LynxOS */

#ifndef hosts_sparclynx_h
#define hosts_sparclynx_h

#include "hosts/lynx.h"

#define	HOST_MACHINE_ARCH	bfd_arch_sparc

#endif /* hosts_sparclynx_h */
