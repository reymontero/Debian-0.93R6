/* RS6000 running LynxOS */

#ifndef hosts_rs6000lynx_h
#define hosts_rs6000lynx_h

#include "hosts/lynx.h"

#define	HOST_MACHINE_ARCH	bfd_arch_rs6000

#endif /* hosts_rs6000lynx_h */
