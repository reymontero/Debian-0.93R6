#ifndef	_NCURSES_INDIRECT_H_
#define	_NCURSES_INDIRECT_H_
#include <ncurses/curses.h>
#endif
