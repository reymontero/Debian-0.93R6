#! /bin/sh

TERMINFO=../runtime-tmp/usr/lib/terminfo;export TERMINFO
rm -fr ../runtime-tmp/usr/lib/terminfo/[0-9A-Za-z]
sed -n <./terminfo.src -e '1,/SPLIT HERE/w tsplit01' -e '/SPLIT HERE/,$w tsplit02' 2>/dev/null
for x in tsplit*; do /aux/packages/base/ncurses-1.9.4/runtime-tmp/usr/bin/tic -v $x; done
rm tsplit*
