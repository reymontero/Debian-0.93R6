
/***************************************************************************
*                            COPYRIGHT NOTICE                              *
****************************************************************************
*                ncurses is copyright (C) 1992-1995                        *
*                          Zeyd M. Ben-Halim                               *
*                          zmbenhal@netcom.com                             *
*                          Eric S. Raymond                                 *
*                          esr@snark.thyrsus.com                           *
*                                                                          *
*        Permission is hereby granted to reproduce and distribute ncurses  *
*        by any means and for any fee, whether alone or as part of a       *
*        larger distribution, in source or in binary form, PROVIDED        *
*        this notice is included with any such distribution, and is not    *
*        removed from any of its header files. Mention of ncurses in any   *
*        applications linked with it is highly appreciated.                *
*                                                                          *
*        ncurses comes AS IS with no warranty, implied or expressed.       *
*                                                                          *
***************************************************************************/



/*
 *	lib_trace.c - Tracing/Debugging routines
 */

#ifndef TRACE
#define TRACE			/* turn on internal defs for this module */
#endif

#include "curses.priv.h"

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <errno.h>

#if !HAVE_EXTERN_ERRNO
extern int errno;
#endif

#if !HAVE_STRERROR
extern char *strerror(int);
#endif

int _nc_tracing = 0;  
char *_nc_tputs_trace;

static int	tracefd = 2;	/* default to writing to stderr */

void trace(const unsigned int tracelevel)
{
static bool	been_here = FALSE;

	if (! been_here) {
	   	been_here = TRUE;

	   	if ((tracefd = creat("trace", 0644)) < 0) {
			write(2, "curses: Can't open 'trace' file: ", 33);
			write(2, strerror(errno), strlen(strerror(errno)));
			write(2, "\n", 1);
			exit(1);
	   	}
	   	_tracef("TRACING NCURSES version %s", NCURSES_VERSION);
	}

   	_nc_tracing = tracelevel;
}

char *_nc_visbuf(const char *buf)
/* visibilize a given string */
{
static char vbuf[BUFSIZ];
char *tp = vbuf;

	if (buf == (char *)NULL)
	    return("(null)");

    	while (*buf) {
		if (is7bits(*buf) && isgraph(*buf))
	    		*tp++ = *buf++;
		else if (*buf == '\n') {
	    		*tp++ = '\\'; *tp++ = 'n';
	    		buf++;
		}
		else if (*buf == '\r') {
	    		*tp++ = '\\'; *tp++ = 'r';
	    		buf++;
		} else if (*buf == '\b') {
	    		*tp++ = '\\'; *tp++ = 'b';
	    		buf++;
		} else if (*buf == '\033') {
	    		*tp++ = '\\'; *tp++ = 'e';
	    		buf++;
		} else if (is7bits(*buf) && iscntrl(*buf)) {
	    		*tp++ = '\\'; *tp++ = '^'; *tp++ = '@' + *buf;
	    		buf++;
		} else {
	    		sprintf(tp, "\\0x%02x", *buf++);
	    		tp += strlen(tp);
		}
    }
    *tp++ = '\0';
    return(vbuf);
}

void
_tracef(char *fmt, ...)
{
va_list ap;
char buffer[BUFSIZ];

	va_start(ap, fmt);
	vsprintf(buffer, fmt, ap);
	write(tracefd, buffer, strlen(buffer));
	write(tracefd, "\n", 1);
}

