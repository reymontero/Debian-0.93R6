:
# Script used by addinput.tcl

cnt=15
while [ $cnt != 0 ]
do
   date
   echo "   T-minus $cnt seconds"
   sleep 1
   cnt=`expr $cnt - 1`
done
exit 0
