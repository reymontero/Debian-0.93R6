%%
%% This file is part of the Standard LaTeX `Graphics Bundle'.
%%
%% It should be distributed *unchanged* and together with all other
%% files in the graphics bundle. The file 00readme.txt contains a list
%% of all of these files.
%%
%% A modified version of this file may be distributed, but it should
%% be distributed with a *different* name. Changed files must be
%% distributed *together with a complete and unchanged* distribution
%% of these files.
%%


The LaTeX Colour and Graphics Packages
========================================
                    1995/06/19

This is a pre-release of LaTeX packages for:
 * producing colour
 * including graphics (eg PostScript) files 
 * rotation and scaling of text
in LaTeX documents.


This is still a test release.


Main Changes in the June 1995  version
======================================

Not much new at the user level 
   - hopefully this will be the last `test' release!

graphicx package defines a couple of new keys for \includegraphics:
  trim and viewport (see grfguide for more info about these).

epsfig no longer forces a default to dvips driver.
  (The default specified in a graphics.cfg file will be used)

Due to internal changes, old `.def' files will *not* work with this
release. The main change is that the `bounding box' coordinates are no
longer stored in TeX dimen registers, but rather in macros. this
allows the exact value to be passed to the driver in `bp' without
introducing rounding errors.

    
David Carlisle 1994/11/29


========================================================================


THIS DIRECTORY CONTAINS 
======================
======================

00readme.txt    This File
changes.txt     Log of changes to the packages.
graphics.ins    Install file for docstrip.

Standard packages
=================
color.dtx       Source for color package
graphics.dtx    Source for graphics package
trig.dtx        Source for trig package (required by graphics)

Non Standard Packages
=====================
graphicx.dtx    Source for graphicx package (extension of graphics)
epsfig.dtx      Source for epsfig package (extension of graphicx)
keyval.dtx      Source for keyval pacakge (required by both the above)
pstcol.sty      Small wrapper for pstricks package.
lscape.sty      Produce landscape pages in a (mainly) portrait document.

Driver Files
============
drivers.dtx     Source for driver files for supported drivers.

User Documentation
==================
grfguide.tex    User Guide to all the packages in this bundle.
                WARNING: 
                This file calls color and graphics packages
                without a driver option. 
                You *must* set up two files 
                                 color.cfg and graphics.cfg
                containing (for example)
                                \ExecuteOptions{dvips}
                Before running this file.

grfguide.ps     PostScript version of the above (Using PostScript fonts)
                You may use this to see examples that your driver may
		not be able to achieve.


=============================================

TO UNPACK THE PACKAGES
======================

latex graphics.ins

This will produce the 

.sty package files
.def driver files.

=============================================

USING THE PACKAGES
==================

Move files ending in .sty .def  to a standard TeX input directory.

Make a default option for your site by creating two files
     color.cfg and graphics.cfg
containing (if dvips is your default driver)
\ExecuteOptions{dvips}

You may then LaTeX the user guide:
latex grfguide.tex.

==============================================


Comments from the previous release.
**********************************


Main Changes in the November/December 1994 version
========================================================================

color.sty
============

   Some code now obsolete code removed as the new LaTeX kernel is more
   colour-aware.

graphics.sty
============
**** Important Note: Change in user-syntax!
*******************************************
    The optional argument to     \DeclareGraphicsExtensions 
    has been removed.
    The new behaviour is equivalent to specifying an argument of []
    in the previous version. ie there is *no longer* a default `.'
    added.

    As a consequence of this, all extensions must now be specified
    including the `.' ie .eps not just eps.

    This change does not lose any functionality, and makes it much
    easier to work with files with no extension.


Main Changes in the July/September/October 1994 version
========================================================================

color.sty
============

1) I separated out the code that converts from `user syntax' to the
   internal version for \special from the code that actually inserts the
   special.
   This means that:
   * It should be easier to work with PSTricks, where the `internal' code
     has to be done *inside* a larger special, so you can not do any
     fancy TeX stuff at that point. A pstcol.sty using pstrics with 
     color.sty based colours is included in this test release.

   * The .def file can be a lot simpler as it no longer has to define a
     a `set' command and a `define' command for each colour model.
     It just defines a single `user spec' to `special syntax' command
     for each model, \color and \definecolor both use this same
     internal interface.

2) \color \textcolor are now robust.
   [although \textcolor turns into \color if used as a robust command.
    That is if you say \textcolor{red}{foo} in a section header, 
    the toc file will have {\color{red}foo}
   ]

3) \textcolor is no longer \long (so it matches \textrm) if you want
   lots of paragraphs use \color or \begin{color}

4) Added \DefineNamedColor command to give an interface for the 'named'
   colour model.


graphics.sty
===============

1) Added a default rule, eg dvips.def now has the equivalent of
   \DeclareGraphicsRule{*}{eps}{*}{}
   Which means that you can include file with arbitrary extensions:
   \includegraphics{a.xyz} 
   will input this as an eps file unless another rule has been decared
   for the extension xyz.

2) More care taken with catcodes so hopefully this version will work
   with language packages that make ! or " active.

3) Add new error
      {Cannot determine size of graphic in ... (no size specifed)}%
   Generated in the case that the file type has no `read file'
   specified, but the user has not given a size argument.

4) New driver loading code.

