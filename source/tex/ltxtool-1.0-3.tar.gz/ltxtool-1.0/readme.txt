
  `tools' bundle
 =================

This `bundle' consists of LaTeX2e packages written and supported by
members of the LaTeX3 project.

The documented source code of each package is in a file with extension
`.dtx'. Running LaTeX on the file tools.ins will produce all the
package files, and some associated TeX files.
So you should first process tools.ins:

latex tools.ins

The files with extensions .sty and .tex (including a file `.tex')
should then be moved to a directory on LaTeX's standard input path.

Documentation for the individual packages may then be
obtained by running LaTeX on the `dtx' file.
For example:

latex array.dtx

will produce array.dvi, documenting the array package.

*NOTE* Copyright is maintained on each of these packages by the
author(s) of the package. 
Unless otherwise mentioned in the package file, all the packages in this
bundle are released under the Copyright restrictions detailed below. 
In particular, the  multicol package is distributed under special terms,
as explained in multicol.dtx. 

The file manifest.txt contains a list of the main files in the
distribution together with a one-or-two line summary of the package.


Reporting Bugs
==============

If you wish to report a problem or bug with any of these packages,
use the latexbug.tex program that comes with the standard LaTeX
distribution.  Please ensure that you enter `1' when prompted with a
menu of categories, so that the message will be automatically forwarded
to the appropriate part of our database.

When reporting bugs, please produce a small test file that shows the
problem, and ensure that you are using current versions of the package,
and the LaTeX software.


Distribution of unchanged versions
==================================
  
  You are NOT ALLOWED to take money for the distribution or use of
  these files except for a nominal charge for copying etc.

  Redistribution of unchanged files is allowed provided that all files
  listed in the corresponding package's manifest.txt file are
  distributed including this readme file.

  If you receive only some of these files from someone, complain!
  
  However, if these files are distributed by established suppliers as
  part of a complete TeX distribution, and the structure of the
  distribution would make it difficult to distribute the whole set of
  files, then *those parties* are allowed to distribute only some of the
  files provided that it is made clear that the user will get a
  complete distribution-set upon request to that supplier (not from
  us).

  Note that this permission is not granted to the end user.

  The individual packages may bear additional copyright notices which
  supersede this general copyright notice.


Generation and distribution of changed versions
===============================================

  The generation of changed versions of the files included in the
  packages is allowed under the following restrictions:

  - You rename the file before you make any changes to it.  

  - You acknowledge the origin of the original version in the file and
    keep the information that it (or a changed version) has to be
    distributed under the restrictions mentioned in this file.

  - You change the ERROR REPORT address so that we don't get error
    reports for files *not* maintained by us.


  The distribution of changed versions of the files included in the
  tools bundle is allowed under the following restrictions:

  - You provide the user with information how to obtain the original
    package or, even better, distribute it with your files.

  - You make sure that the changed versions contain a notice that
    prevents others to take money for distribution or use of your
    files, i.e. they have to be distributed under the restrictions
    mentioned in this file.

  - You inform us that you created a changed version of the files.
    This is only necessary if you want to distribute it to others.
