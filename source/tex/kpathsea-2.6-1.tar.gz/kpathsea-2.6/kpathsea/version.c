char *kpathsea_version_string = (char *) "kpathsea version 2.6";
