% \iffalse meta-comment
%
% Copyright 1994 the LaTeX3 project and the individual authors.
% All rights reserved. For further copyright information see the file
% legal.txt, and any other copyright indicated in this file.
% 
% This file is part of the LaTeX2e system.
% ----------------------------------------
% 
%  This system is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
% 
% 
% IMPORTANT NOTICE:
% 
% For error reports in case of UNCHANGED versions see bugs.txt.
% 
% Please do not request updates from us directly.  Distribution is
% done through Mail-Servers and TeX organizations.
% 
% You are not allowed to change this file.
% 
% You are allowed to distribute this file under the condition that
% it is distributed together with all files mentioned in manifest.txt.
% 
% If you receive only some of these files from someone, complain!
% 
% You are NOT ALLOWED to distribute this file alone.  You are NOT
% ALLOWED to take money for the distribution or use of either this
% file or a changed version, except for a nominal charge for copying
% etc.
% \fi

  `mfnfss' bundle
 =================

This `bundle' consists of LaTeX2e packages written and supported by
members of the LaTeX3 project.

The documented source code of each package is in a file with extension
`.dtx'. Running LaTeX on the various files with extension `.ins' will
produce all the package files, and some associated TeX files.  So you
should first process, e.g., oldgerm.ins:

latex oldgerm.ins

The files with extensions .sty and .fd should then be moved to a
directory on LaTeX's standard input path.

Documentation for the individual packages may then be
obtained by running LaTeX on the `dtx' file.
For example:

latex oldgerm.dtx

will produce oldgerm.dvi, documenting the oldgerm package.

*NOTE* Copyright is maintained on each of these packages by the
author(s) of the package. 
Unless otherwise mentioned in the package file, all the packages in this
bundle are released under the Copyright restrictions detailed below. 


Reporting Bugs
==============

If you wish to report a problem or bug with any of these packages,
use the latexbug.tex program that comes with the standard LaTeX
distribution.  Please ensure that you enter `3' when prompted with a
menu of categories, so that the message will be automatically forwarded
to the appropriate part of our database.

When reporting bugs, please produce a small test file that shows the
problem, and ensure that you are using current versions of the package,
and the LaTeX software.


Distribution of unchanged versions
==================================
  
  You are NOT ALLOWED to take money for the distribution or use of
  these files except for a nominal charge for copying etc.

  Redistribution of unchanged files is allowed provided that all files
  listed in the corresponding package's manifest.txt file are
  distributed including this readme file.

  If you receive only some of these files from someone, complain!
  
  However, if these files are distributed by established suppliers as
  part of a complete TeX distribution, and the structure of the
  distribution would make it difficult to distribute the whole set of
  files, then *those parties* are allowed to distribute only some of the
  files provided that it is made clear that the user will get a
  complete distribution-set upon request to that supplier (not from
  us).

  Note that this permission is not granted to the end user.

  The individual packages may bear additional copyright notices which
  supersede this general copyright notice.


Generation and distribution of changed versions
===============================================

  The generation of changed versions of the files included in the
  packages is allowed under the following restrictions:

  - You rename the file before you make any changes to it.  

  - You acknowledge the origin of the original version in the file and
    keep the information that it (or a changed version) has to be
    distributed under the restrictions mentioned in this file.

  - You change the ERROR REPORT address so that we don't get error
    reports for files *not* maintained by us.


  The distribution of changed versions of the files included in the
  `mfnfss' bundle is allowed under the following restrictions:

  - You provide the user with information how to obtain the original
    package or, even better, distribute it with your files.

  - You make sure that the changed versions contain a notice that
    prevents others to take money for distribution or use of your
    files, i.e. they have to be distributed under the restrictions
    mentioned in this file.

  - You inform us that you created a changed version of the files.
    This is only necessary if you want to distribute it to others.
