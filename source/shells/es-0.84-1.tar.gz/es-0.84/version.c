/* version.c -- version number ($Revision: 1.12 $) */
#include "es.h"
static const char id[] = "@(#)es version 0.84: 29 Apr 1993";
const char * const version = id + (sizeof "@(#)" - 1);
