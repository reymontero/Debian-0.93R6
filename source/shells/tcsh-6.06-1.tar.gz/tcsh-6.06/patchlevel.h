/* $Header: /u/christos/src/tcsh-6.06/RCS/patchlevel.h,v 3.94 1995/05/13 20:23:31 christos Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Cornell"
#define REV 6
#define VERS 6
#define PATCHLEVEL 0
#define DATE "1995-05-13"

#endif /* _h_patchlevel */
