/*
 * value of $KSH_VERSION (or $SH_VERSION)
 */

char ksh_version [] =
	"@(#)PD KSH v5.1.3 94/12/22";
