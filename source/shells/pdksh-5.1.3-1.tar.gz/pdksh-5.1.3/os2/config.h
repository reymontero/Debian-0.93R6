/* Define if on AIX 3.
   System headers sometimes define this.
   We just want to avoid a redefinition error message.  */
#ifndef _ALL_SOURCE
/* #undef _ALL_SOURCE */
#endif

/* Define to empty if the keyword does not work.  */
/* #define const 

/* Define if you have dirent.h.  */
#define DIRENT 1


/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef gid_t */

/* Define if you have a working `mmap' system call.  */
/* #define HAVE_MMAP 1 */

/* Define if your struct stat has st_rdev.  */
#define HAVE_ST_RDEV 1

/* Define if `union wait' is the type of the first arg to wait functions.  */
/* #define HAVE_UNION_WAIT 1 */

/* Define if you have unistd.h.  */
#define HAVE_UNISTD_H 1

/* Define if on MINIX.  */
/* #undef _MINIX */

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef mode_t */

/* Define if you don't have dirent.h, but have ndir.h.  */
/* #undef NDIR */

/* Define to `long' if <sys/types.h> doesn't define.  */
/* #undef off_t */

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef pid_t */
#define pid_t int

/* Define if the system does not provide POSIX.1 features except
   with this defined.  */
/* #undef _POSIX_1_SOURCE */

/* Define if you need to in order for stat and other things to work.  */
#define _POSIX_SOURCE 1

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define if the `S_IS*' macros in <sys/stat.h> do not work properly.  */
/* #undef STAT_MACROS_BROKEN */

/* Define if you don't have dirent.h, but have sys/dir.h.  */
/* #undef SYSDIR */

/* Define if you don't have dirent.h, but have sys/ndir.h.  */
/* #undef SYSNDIR */

/* Define if `sys_siglist' is declared by <signal.h>.  */
/* #undef SYS_SIGLIST_DECLARED */

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef uid_t */

/* Define if the closedir function returns void instead of int.  */
/* #undef VOID_CLOSEDIR */

/* Copyright (C) 1994, Memorial University of Newfoundland.
 * This file is covered by the GNU General Public License, version 2, see
 * the file misc/COPYING for details.
 */
/* Define if your kernal doesn't handle scripts starting with #! */
#define SHARPBANG 1

/* Define if dup2() preserves the close-on-exec flag (ultrix does this) */
/* #undef DUP2_BROKEN */

/* Define if you have posix signal routines (sigaction(), et. al.) */
/* #define POSIX_SIGNALS 1 */

/* Define if you have BSD4.2 signal routines (sigsetmask(), et. al.) */
/* #undef BSD42_SIGNALS */

/* Define if you have BSD4.1 signal routines (sigset(), et. al.) */
/* #undef BSD41_SIGNALS */

/* Define if you have v7 signal routines (signal(), signal reset on delivery) */
/* #undef V7_SIGNALS */

/* Define to use the fake posix signal routines (sigact.[ch]) */
#define USE_FAKE_SIGACT 1

/* Define if you have bsd versions of the setpgrp() and getpgrp() routines */
/* #define BSD_PGRP 1 */

/* Define if you have bsd versions of the setpgid() and getpgrp() routines */
/* #undef POSIX_PGRP */

/* Define if you have sysV versions of the setpgrp() and getpgrp() routines */
/* #undef SYSV_PGRP */

/* Define to char if your compiler doesn't like the void keyword */
/* #undef void */

/* Define to nothing if compiler doesn't like the volatile keyword */
/* #define volatile */

/* Define to 32-bit signed integer type */
#define INT32 long

/* Define to 32-bit signed integer type if <sys/types.h> doesn't define */
/* #undef clock_t */

/* Define to 32-bit signed integer type if <sys/types.h> doesn't define */
/* #undef time_t */

/* Define if time() is declared in <time.h> */
#define TIME_DECLARED 1

/* Define to `unsigned' if <signal.h> doesn't define */
#define sigset_t unsigned

/* Define if sys_errlist[] and sys_nerr are in the C library */
/* #define HAVE_SYS_ERRLIST 1 */

/* Define if sys_errlist[] and sys_nerr are defined in <errno.h> */
/* #undef SYS_ERRLIST_DECLARED */

/* Define if sys_siglist[] is in the C library */
/* #define HAVE_SYS_SIGLIST 1 */

/* Define if sys_siglist[] are defined in <signal.h> or <unistd.h> */
/* #undef SYS_SIGLIST_DECLARED */

/* Define if C compiler groks function prototypes */
#define HAVE_PROTOTYPES 1

/* Define if C compiler groks __attribute__((...)) (const, noreturn, format) */
#define HAVE_GCC_FUNC_ATTR 1

/* Define if you have a sane <unistd.h> header file */
#define HAVE_UNISTD_H 1

/* Define if you have a sane <termios.h> header file */
/* #define HAVE_TERMIOS_H 1 */

/* Define if you don't have times() or if it always returns 0 */
/* #define TIMES_BROKEN 1 */

/* Define if opendir() will open non-directory files */
/* #undef OPENDIR_DOES_NONDIR */

/* Define if the pgrp of setpgrp() can't be the pid of a zombie process */
/* #undef NEED_PGRP_SYNC */

/* Define if you have bcopy.  */
#define HAVE_BCOPY 1

/* Define if you have confstr.  */
/* #undef HAVE_CONFSTR */

/* Define if you have getcwd.  */
#define HAVE_GETCWD 1

/* Define if you have getrusage.  */
#undef HAVE_GETRUSAGE

/* Define if you have killpg.  */
/* #define HAVE_KILLPG 1 */

/* Define if you have memmove.  */
#define HAVE_MEMMOVE 1

/* Define if you have memset.  */
#define HAVE_MEMSET 1

/* Define if you have setrlimit.  */
/* #define HAVE_SETRLIMIT 1 */

/* Define if you have strcasecmp.  */
/* #define HAVE_STRCASECMP 1 */

/* Define if you have strerror.  */
#define HAVE_STRERROR 1

/* Define if you have strstr.  */
#define HAVE_STRSTR 1

/* Define if you have sysconf.  */
/* #define HAVE_SYSCONF 1 */

/* Define if you have tcsetpgrp.  */
/* #define HAVE_TCSETPGRP 1 */

/* Define if you have ulimit.  */
/* #define HAVE_ULIMIT 1

/* Define if you have wait3.  */
/* #define HAVE_WAIT3 1 */

/* Define if you have waitpid.  */
#define HAVE_WAITPID 1

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H 1

/* Define if you have the <limits.h> header file.  */
#define HAVE_LIMITS_H 1

/* Define if you have the <memory.h> header file.  */
#define HAVE_MEMORY_H 1

/* Define if you have the <paths.h> header file.  */
/* #undef HAVE_PATHS_H */

/* Define if you have the <stddef.h> header file.  */
#define HAVE_STDDEF_H 1

/* Define if you have the <stdlib.h> header file.  */
#define HAVE_STDLIB_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <sys/wait.h> header file.  */
#define HAVE_SYS_WAIT_H 1

/* Define if you have the <termio.h> header file.  */
#define HAVE_TERMIO_H 1

/* Define if you have the <ulimit.h> header file.  */
/* #undef HAVE_ULIMIT_H */

/* Define if you have the <values.h> header file.  */
/* #define HAVE_VALUES_H 1 */
