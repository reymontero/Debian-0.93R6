cc='/bin/cc'
test -f $cc || cc='/usr/ccs/bin/cc'
mansrc='/usr/share/man/man1'
libswanted='malloc socket nsl'
d_strchr=define
