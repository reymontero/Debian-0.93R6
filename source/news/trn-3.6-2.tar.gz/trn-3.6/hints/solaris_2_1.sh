#d_vfork=undef
i_dirent=define
i_sysdir=undef
libs='-lmalloc -lsocket -lnls -lnsl -lintl -lucb'
