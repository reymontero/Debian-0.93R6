d_ftime=undef
