cppstdin='/lib/cpp -D_AIX -D_IBMR2 -U__STR__'
cppminus=''
