xlibpth=''
mailer='/usr/lib/mail/execmail'
libc='/lib/libc.a'
