libswanted=`echo $libswanted | sed 's/ x//'`
cppminus=''
d_rename=undef
