cppstdin='/lib/cpp'
libs='-ldgc'
d_strchr='define'
cc='gcc'
