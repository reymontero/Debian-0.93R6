i_sgtty=undef
i_termios=define
ccflags="-D__STDC__ -ext -tm c1"
d_voidsig='define'
signal_t='void'
d_strchr='undef'
libc='/usr/lib/libc.a'
