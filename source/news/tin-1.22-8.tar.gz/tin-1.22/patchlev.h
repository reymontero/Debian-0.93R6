/*
 *  Project   : tin - a Usenet reader
 *  Module    : patchlev.h
 *  Author    : I.Lea
 *  Created   : 01-04-91
 *  Updated   : 14-07-93
 *  Notes     :
 *  Copyright : (c) Copyright 1991-93 by Iain Lea
 *              You may  freely  copy or  redistribute  this software,
 *              so  long as there is no profit made from its use, sale
 *              trade or  reproduction.  You may not change this copy-
 *              right notice, and it must be included in any copy made
 */

#define VERSION		"1.2"			/* Beta versions are "1.n Beta" */
#define PATCHLEVEL	"2"

#ifdef M_AMIGA
#	define	OS	"[AMIGA]"
#endif
#ifdef M_OS2
#	define	OS	"[OS/2]"
#endif
#ifdef M_UNIX
#	define	OS	"[UNIX]"
#endif
#ifdef WIN32
#	define	OS	"[WIN/NT]"
#endif
