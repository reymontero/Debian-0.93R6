#define BC_VERSION  \
"bc 1.03 (Nov 2, 1994)\nCopyright (C) 1991, 1992, 1993, 1994 Free Software Foundation, Inc."

